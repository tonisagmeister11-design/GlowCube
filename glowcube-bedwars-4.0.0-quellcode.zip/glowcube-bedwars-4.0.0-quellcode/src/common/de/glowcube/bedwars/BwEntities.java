package de.glowcube.bedwars;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.entity.projectile.hurtingprojectile.LargeFireball;
import net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Die Wesen hinter den Spezial-Items. Alle tragen das Etikett "bw_entity" und verschwinden am Rundenende. */
public final class BwEntities {
   private BwEntities() {
   }

   /** Ein Wesen, das zu einem Team gehoert (Traumverteidiger, Bettwanze). */
   public interface TeamMob {
      Game.TeamState bwTeam();
   }

   // ====================================================================== Explosion

   /**
    * Eigene Explosion statt der von Minecraft: bricht nur Bloecke, die Spieler gesetzt haben (keine Karte,
    * kein Bett, kein Glas, kein Obsidian), schleudert weit (Feuerball-Springen) und schont Teamkollegen.
    *
    * @param endStone darf Endstein brechen (TNT ja, Feuerball nein)
    */
   public static void explode(ServerLevel level, Vec3 pos, Entity source, LivingEntity owner, float radius, float maxDamage, double knock, boolean endStone) {
      Arena arena = Game.arena();
      level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.x, pos.y, pos.z, 1, 0.0, 0.0, 0.0, 0.0);
      level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 8, radius * 0.4, radius * 0.4, radius * 0.4, 0.0);
      level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 3.0F, 0.9F + level.getRandom().nextFloat() * 0.2F);
      if (arena != null) {
         int r = (int)Math.ceil(radius);
         BlockPos c = BlockPos.containing(pos);
         BlockState air = Blocks.AIR.defaultBlockState();

         for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
               for (int z = -r; z <= r; z++) {
                  double d = Math.sqrt(x * x + y * y + z * z);
                  if (d > radius) {
                     continue;
                  }

                  BlockPos p = c.offset(x, y, z);
                  BlockState st = level.getBlockState(p);
                  if (st.isAir() || arena.isMap(p) || !arena.inBuildArea(p) || !breakable(st, endStone && d < radius * 0.5)) {
                     continue;
                  }

                  if (d < radius * 0.6 || level.getRandom().nextFloat() < 0.7F) {
                     level.setBlock(p, air, 3);
                  }
               }
            }
         }
      }

      DamageSource src = level.damageSources().explosion(source, owner);
      double reach = radius + 1.5;
      BwTeam ownerTeam = owner == null ? null : Game.teamOf(owner);

      for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(reach))) {
         Vec3 mid = e.position().add(0.0, e.getBbHeight() * 0.5, 0.0);
         double d = mid.distanceTo(pos);
         if (d > reach || !e.isAlive() || e instanceof net.minecraft.world.entity.npc.villager.Villager) {
            continue;
         }

         boolean self = e == owner;
         boolean mate = !self && ownerTeam != null && Game.teamOf(e) == ownerTeam;
         if (mate) {
            continue;
         }

         double f = 1.0 - d / reach;
         Vec3 dir = mid.subtract(pos);
         dir = dir.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 1.0, 0.0) : dir.normalize();
         float dmg = (float)(maxDamage * f * (self ? 0.35 : 1.0));
         if (dmg > 0.2F) {
            e.hurtServer(level, src, dmg);
         }

         e.push(dir.x * knock * f, Math.max(0.35, dir.y) * knock * f * 0.9, dir.z * knock * f);
         e.needsSync = true;
      }
   }

   private static boolean breakable(BlockState st, boolean endStone) {
      if (st.getBlock() instanceof BedBlock || st.is(BlockTags.IMPERMEABLE) || st.is(Blocks.OBSIDIAN) || st.is(Blocks.CRYING_OBSIDIAN)) {
         // Glas aller Farben ist explosionsfest, Obsidian sowieso
         return false;
      } else if (st.is(Blocks.END_STONE)) {
         return endStone;
      } else {
         return st.getBlock().getExplosionResistance() < 10.0F && st.getFluidState().isEmpty();
      }
   }

   // ====================================================================== Feuerball

   public static final class Fireball extends LargeFireball {
      public Fireball(Level level, LivingEntity owner, Vec3 dir) {
         super(level, owner, dir, 1);
         this.addTag("bw_entity");
      }

      @Override
      protected void onHit(HitResult hit) {
         if (this.level() instanceof ServerLevel level && this.isAlive()) {
            Entity owner = this.getOwner();
            explode(level, hit.getLocation(), this, owner instanceof LivingEntity le ? le : null, 2.6F, 4.0F, 1.55, false);
            Platform.get().remove(this);
         }
      }

      @Override
      protected void onHitEntity(EntityHitResult hit) {
      }

      @Override
      public void tick() {
         super.tick();
         if (this.tickCount > 200 && this.isAlive()) {
            Platform.get().remove(this);
         }
      }

      @Override
      public boolean shouldBeSaved() {
         return false;
      }
   }

   // ====================================================================== TNT

   public static final class Tnt extends PrimedTnt {
      public Tnt(Level level, double x, double y, double z, LivingEntity owner) {
         super(level, x, y, z, owner);
         this.setFuse(52);
         this.addTag("bw_entity");
      }

      @Override
      public void tick() {
         if (this.getFuse() <= 1 && this.level() instanceof ServerLevel level) {
            explode(level, this.position().add(0.0, 0.1, 0.0), this, this.getOwner(), 3.6F, 9.0F, 1.25, true);
            Platform.get().remove(this);
         } else {
            super.tick();
            if (this.getY() < Arena.VOID_Y) {
               Platform.get().remove(this);
            }
         }
      }

      @Override
      public boolean shouldBeSaved() {
         return false;
      }
   }

   // ====================================================================== Wurfgeschosse: Bruecken-Ei und Bettwanze

   public static final class Thrown extends Snowball {
      public enum Kind {
         BRIDGE_EGG,
         BEDBUG
      }

      private final Kind kind;
      private final Game.TeamState team;
      private int placed;

      public Thrown(Level level, LivingEntity owner, Kind kind, Game.TeamState team) {
         super(level, owner, new ItemStack(kind == Kind.BRIDGE_EGG ? Items.EGG : Items.SNOWBALL));
         this.kind = kind;
         this.team = team;
         this.addTag("bw_entity");
      }

      @Override
      public void tick() {
         super.tick();
         if (!(this.level() instanceof ServerLevel level) || !this.isAlive()) {
            return;
         }

         if (this.kind == Kind.BRIDGE_EGG && this.tickCount > 2 && this.team != null) {
            // die Bruecke entsteht zwei Bloecke unter der Flugbahn
            BlockPos at = BlockPos.containing(this.getX(), this.getY() - 2.2, this.getZ());
            Arena arena = Game.arena();
            for (BlockPos p : List.of(at, at.relative(this.getDirection().getClockWise()))) {
               if (arena != null && arena.inBuildArea(p) && level.getBlockState(p).isAir() && this.placed < 48
                  && level.getEntitiesOfClass(LivingEntity.class, new AABB(p)).isEmpty()) {
                  level.setBlock(p, this.team.team.wool.defaultBlockState(), 3);
                  this.placed++;
               }
            }

            if (this.tickCount % 3 == 0) {
               level.playSound(null, at, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 0.6F, 1.0F);
            }
         }

         if (this.tickCount > 45 || this.getY() < Arena.VOID_Y) {
            Platform.get().remove(this);
         }
      }

      @Override
      protected void onHitEntity(EntityHitResult hit) {
      }

      @Override
      protected void onHit(HitResult hit) {
         if (this.level() instanceof ServerLevel level && this.isAlive()) {
            if (this.kind == Kind.BEDBUG && this.team != null) {
               Vec3 at = hit.getLocation();
               Bedbug bug = new Bedbug(level, this.team);
               bug.setPos(at.x, at.y + 0.1, at.z);
               level.addFreshEntity(bug);
               level.playSound(null, BlockPos.containing(at), SoundEvents.SILVERFISH_AMBIENT, SoundSource.HOSTILE, 1.0F, 1.0F);
            }

            Platform.get().remove(this);
         }
      }

      @Override
      public boolean shouldBeSaved() {
         return false;
      }
   }

   // ====================================================================== Mobs mit Team

   private static String timeLeft(int ticks) {
      int s = Math.max(0, ticks / 20);
      return s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60;
   }

   /** Sucht das naechste feindliche Ziel in Reichweite (keine Teamkollegen, keine Zuschauer). */
   static LivingEntity nearestEnemy(Game.TeamState team, Entity from, double range) {
      LivingEntity best = null;
      double bd = range * range;

      for (LivingEntity e : Game.enemiesOf(team)) {
         if (!Game.isProtected(e) && e.level() == from.level()) {
            double d = e.distanceToSqr(from);
            if (d < bd) {
               bd = d;
               best = e;
            }
         }
      }

      return best;
   }

   /** Traumverteidiger: ein Eisengolem, der 4 Minuten lang die Insel seines Teams beschuetzt. */
   public static final class Golem extends IronGolem implements TeamMob {
      private static final int LIFE = 20 * 240;
      private final Game.TeamState team;
      private final Vec3 home;

      public Golem(Level level, Game.TeamState team, Vec3 home) {
         super(EntityTypes.IRON_GOLEM, level);
         this.team = team;
         this.home = home;
         this.setPlayerCreated(true);
         this.setPersistenceRequired();
         this.addTag("bw_entity");
         this.addTag("bw_team_" + team.team.ordinal());
         if (this.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(5.0);
         }

         if (this.getAttribute(Attributes.MAX_HEALTH) != null) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(60.0);
            this.setHealth(60.0F);
         }

         this.setCustomNameVisible(true);
      }

      @Override
      public Game.TeamState bwTeam() {
         return this.team;
      }

      @Override
      protected void registerGoals() {
         this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
         this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6));
         this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
      }

      @Override
      public void tick() {
         super.tick();
         if (this.level().isClientSide() || this.team == null) {
            return;
         }

         Platform.get().keepTicking(this);
         if (!Game.running() || this.tickCount > LIFE || this.getY() < Arena.VOID_Y) {
            Platform.get().remove(this);
            return;
         }

         if (this.tickCount % 20 == 1) {
            this.setCustomName(Component.literal("[" + this.team.team.label + "] Traumverteidiger " + timeLeft(LIFE - this.tickCount)).withStyle(this.team.team.format));
            LivingEntity t = this.getTarget();
            if (t == null || !t.isAlive() || !Game.isEnemy(this.team, t) || t.distanceToSqr(this.home) > 22 * 22) {
               LivingEntity n = nearestEnemy(this.team, this, 14.0);
               this.setTarget(n != null && n.distanceToSqr(this.home) < 22 * 22 ? n : null);
            }

            if (this.getTarget() == null && this.position().distanceTo(this.home) > 7.0) {
               this.getNavigation().moveTo(this.home.x, this.home.y, this.home.z, 0.8);
            }
         }
      }

      @Override
      public void setTarget(LivingEntity target) {
         // nie die eigenen Leute angreifen
         super.setTarget(target != null && Game.isEnemy(this.team, target) ? target : null);
      }

      @Override
      protected boolean shouldDropLoot(ServerLevel level) {
         return false;
      }

      @Override
      public boolean shouldDropExperience() {
         return false;
      }

      @Override
      public boolean shouldBeSaved() {
         return false;
      }
   }

   /** Bettwanze: ein Silberfischchen, das 15 Sekunden lang Gegner zwickt. */
   public static final class Bedbug extends Silverfish implements TeamMob {
      private static final int LIFE = 20 * 15;
      private final Game.TeamState team;

      public Bedbug(Level level, Game.TeamState team) {
         super(EntityTypes.SILVERFISH, level);
         this.team = team;
         this.setPersistenceRequired();
         this.addTag("bw_entity");
         this.addTag("bw_team_" + team.team.ordinal());
         this.setCustomNameVisible(true);
      }

      @Override
      public Game.TeamState bwTeam() {
         return this.team;
      }

      @Override
      protected void registerGoals() {
         // nur zwicken - nicht in Steinbloecke kriechen (das wuerde die Karte veraendern)
         this.goalSelector.addGoal(1, new FloatGoal(this));
         this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
      }

      @Override
      public void tick() {
         super.tick();
         if (this.level().isClientSide() || this.team == null) {
            return;
         }

         Platform.get().keepTicking(this);
         if (!Game.running() || this.tickCount > LIFE || this.getY() < Arena.VOID_Y) {
            Platform.get().remove(this);
            return;
         }

         if (this.tickCount % 10 == 1) {
            this.setCustomName(Component.literal("[" + this.team.team.label + "] Bettwanze " + timeLeft(LIFE - this.tickCount)).withStyle(this.team.team.format));
            LivingEntity t = this.getTarget();
            if (t == null || !t.isAlive() || !Game.isEnemy(this.team, t)) {
               this.setTarget(nearestEnemy(this.team, this, 12.0));
            }
         }
      }

      @Override
      public void setTarget(LivingEntity target) {
         super.setTarget(target != null && Game.isEnemy(this.team, target) ? target : null);
      }

      @Override
      protected boolean shouldDropLoot(ServerLevel level) {
         return false;
      }

      @Override
      public boolean shouldDropExperience() {
         return false;
      }

      @Override
      public boolean shouldBeSaved() {
         return false;
      }
   }
}
