package de.glowcube.bedwars;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Die Karte: fuenf Team-Inseln, fuenf Diamant-Inseln und eine Mitte mit den Smaragd-Spawnern.
 * Wie sie aussieht (Rom, Kirschbluetental, Wuestentempel ...), bestimmt das {@link MapTheme}.
 * Die Spielgeometrie (Inselform, Bett, Spawner, Shop) ist auf allen Karten gleich - darauf verlassen
 * sich die Bots.
 */
public final class Arena {
   public static final int Y = 180;
   public static final int VOID_Y = 150;
   public static final int ISLAND_RADIUS = 8;
   /** Bis hierhin (Abstand zur Mitte) wird beim Start und Ende aufgeraeumt. */
   public static final int EXTENT = 64;
   public static final int MIN_BUILD_Y = Y - 12;
   public static final int MAX_BUILD_Y = Y + 20;
   private static final int FLAGS = 2 | 16 | 32;

   public final ServerLevel level;
   public final BlockPos center;
   public final MapTheme theme;
   public final int teamRing;
   public final int diamondRing;
   public final int midRadius;
   /** Bloecke der Karte - die kann niemand abbauen. */
   public final Long2ObjectOpenHashMap<BlockState> map = new Long2ObjectOpenHashMap<>();
   private final LongArrayList mapOrder = new LongArrayList();
   private int repairCursor;
   public final Island[] islands = new Island[BwTeam.values().length];
   public final List<BlockPos> diamondGens = new ArrayList<>();
   public final List<BlockPos> emeraldGens = new ArrayList<>();
   public final List<BlockPos> diamondIslands = new ArrayList<>();
   /** Fuer zufaellige Verzierungen - pro Karte fest, damit sie jedes Mal gleich aussieht. */
   public final Random deco;

   public Arena(ServerLevel level, BlockPos near, MapTheme theme) {
      this.level = level;
      this.theme = theme;
      this.teamRing = theme.teamRing;
      this.diamondRing = theme.diamondRing;
      this.midRadius = theme.midRadius;
      this.deco = new Random(theme.name.hashCode());
      this.center = new BlockPos(near.getX() & -16, Y, near.getZ() & -16);

      for (BwTeam team : BwTeam.values()) {
         double angle = Math.toRadians(-90.0 + 72.0 * team.ordinal());
         BlockPos origin = this.center.offset((int)Math.round(Math.cos(angle) * this.teamRing), 0, (int)Math.round(Math.sin(angle) * this.teamRing));
         this.islands[team.ordinal()] = new Island(team, origin, towards(origin, this.center));
         double dAngle = angle + Math.toRadians(36.0);
         BlockPos d = this.center.offset((int)Math.round(Math.cos(dAngle) * this.diamondRing), 0, (int)Math.round(Math.sin(dAngle) * this.diamondRing));
         this.diamondIslands.add(d);
         this.diamondGens.add(d.above());
      }

      this.emeraldGens.add(this.center.offset(2, 2, 0));
      this.emeraldGens.add(this.center.offset(-2, 2, 0));
   }

   static Direction towards(BlockPos from, BlockPos to) {
      int dx = to.getX() - from.getX();
      int dz = to.getZ() - from.getZ();
      if (Math.abs(dx) >= Math.abs(dz)) {
         return dx > 0 ? Direction.EAST : Direction.WEST;
      } else {
         return dz > 0 ? Direction.SOUTH : Direction.NORTH;
      }
   }

   public Island island(BwTeam team) {
      return this.islands[team.ordinal()];
   }

   // ------------------------------------------------------------------ Bereich

   public void forceLoad(boolean load) {
      int r = EXTENT + 8;

      for (int cx = this.center.getX() - r >> 4; cx <= this.center.getX() + r >> 4; cx++) {
         for (int cz = this.center.getZ() - r >> 4; cz <= this.center.getZ() + r >> 4; cz++) {
            this.level.setChunkForced(cx, cz, load);
         }
      }
   }

   public boolean inside(Vec3 pos) {
      return Math.abs(pos.x - this.center.getX()) < EXTENT + 10
         && Math.abs(pos.z - this.center.getZ()) < EXTENT + 10
         && pos.y > Y - 60
         && pos.y < Y + 60;
   }

   public boolean inBuildArea(BlockPos pos) {
      return Math.abs(pos.getX() - this.center.getX()) <= EXTENT
         && Math.abs(pos.getZ() - this.center.getZ()) <= EXTENT
         && pos.getY() >= MIN_BUILD_Y
         && pos.getY() <= MAX_BUILD_Y;
   }

   public AABB bounds() {
      return new AABB(
         this.center.getX() - EXTENT - 8, Y - 70, this.center.getZ() - EXTENT - 8, this.center.getX() + EXTENT + 8, Y + 60, this.center.getZ() + EXTENT + 8
      );
   }

   public boolean isMap(BlockPos pos) {
      return this.map.containsKey(pos.asLong());
   }

   public void build() {
      this.clear();
      this.theme.buildMid(this, this.center);

      for (BlockPos d : this.diamondIslands) {
         this.theme.buildDiamondIsland(this, d, outward(d));
      }

      for (Island island : this.islands) {
         this.theme.buildTeamIsland(this, island);
      }

      this.mapOrder.clear();
      this.mapOrder.addAll(this.map.keySet());
   }

   /** Richtung von der Mitte weg (fuer Verzierungen auf der Aussenseite). */
   public Direction outward(BlockPos p) {
      return towards(this.center, p);
   }

   public void clear() {
      this.map.clear();
      this.mapOrder.clear();
      int r = EXTENT + 4;

      for (int cx = this.center.getX() - r >> 4; cx <= this.center.getX() + r >> 4; cx++) {
         for (int cz = this.center.getZ() - r >> 4; cz <= this.center.getZ() + r >> 4; cz++) {
            this.level.getChunk(cx, cz);
         }
      }

      BlockState air = Blocks.AIR.defaultBlockState();
      MutableBlockPos pos = new MutableBlockPos();

      for (int x = this.center.getX() - r; x <= this.center.getX() + r; x++) {
         for (int z = this.center.getZ() - r; z <= this.center.getZ() + r; z++) {
            for (int y = MIN_BUILD_Y - 8; y <= MAX_BUILD_Y + 6; y++) {
               pos.set(x, y, z);
               if (!this.level.getBlockState(pos).isAir()) {
                  this.level.setBlock(pos, air, FLAGS);
               }
            }
         }
      }
   }

   /** Prueft jeden Tick einen Teil der Karte und setzt zerstoerte Kartenbloecke zurueck (Explosionen, Wasser ...). */
   public void repairStep(int budget) {
      int size = this.mapOrder.size();
      if (size == 0) {
         return;
      }

      MutableBlockPos pos = new MutableBlockPos();

      for (int i = 0; i < budget && i < size; i++) {
         if (this.repairCursor >= size) {
            this.repairCursor = 0;
         }

         long key = this.mapOrder.getLong(this.repairCursor++);
         pos.set(key);
         BlockState want = this.map.get(key);
         if (want != null && this.level.getBlockState(pos) != want) {
            this.level.setBlock(pos, want, FLAGS);

            for (ItemEntity item : this.level.getEntitiesOfClass(ItemEntity.class, new AABB(pos).inflate(3.0))) {
               if (item.getItem().is(want.getBlock().asItem())) {
                  item.discard();
               }
            }
         }
      }
   }

   // ------------------------------------------------------------------ Bauwerkzeuge fuer die Themen

   public void put(BlockPos pos, BlockState state) {
      if (state.hasProperty(LeavesBlock.PERSISTENT)) {
         // Laub der Karte darf nicht verwelken
         state = state.setValue(LeavesBlock.PERSISTENT, true);
      }

      this.level.setBlock(pos, state, FLAGS);
      this.map.put(pos.asLong(), state);
   }

   public void put(BlockPos pos, Block block) {
      this.put(pos, block.defaultBlockState());
   }

   /** Nur setzen, wenn dort noch nichts von der Karte steht. */
   public void putIfFree(BlockPos pos, BlockState state) {
      if (!this.map.containsKey(pos.asLong())) {
         this.put(pos, state);
      }
   }

   public void putIfFree(BlockPos pos, Block block) {
      this.putIfFree(pos, block.defaultBlockState());
   }

   public static boolean octagon(int a, int b, int r) {
      return Math.abs(a) <= r && Math.abs(b) <= r && Math.abs(a) + Math.abs(b) <= r + r / 2;
   }

   /** Haengende Unterseite, damit die Inseln wie schwebende Felsen aussehen. */
   public void underside(BlockPos origin, int radius, boolean round, Block top, Block... rocks) {
      for (int depth = 1; depth <= radius + 2; depth++) {
         int r = radius - (depth * 3 + 1) / 2;
         if (r < 0) {
            break;
         }

         for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
               boolean in = round ? a * a + b * b <= r * r + r : octagon(a, b, r);
               if (in) {
                  int hash = (a * 31 + b * 17 + depth * 7) & 7;
                  Block block = depth == 1 ? top : rocks[hash % rocks.length];
                  this.put(origin.offset(a, -depth, b), block);
               }
            }
         }
      }

      // ein paar Zapfen haengen tiefer
      for (int i = 0; i < radius / 2 + 1; i++) {
         int a = this.deco.nextInt(radius) - radius / 2;
         int b = this.deco.nextInt(radius) - radius / 2;
         int depth = (radius * 2) / 3 + 1 + this.deco.nextInt(3);

         for (int d = 2; d <= depth; d++) {
            BlockPos p = origin.offset(a, -d, b);
            if (!this.map.containsKey(p.asLong())) {
               this.put(p, rocks[(d + i) % rocks.length]);
            }
         }
      }
   }

   /** Senkrechte Saeule aus Fuss, Schaft und Kapitell (optional mit Licht obendrauf). */
   public void column(BlockPos base, int height, Block foot, Block shaft, Block cap, BlockState light) {
      this.put(base, foot);

      for (int i = 1; i < height - 1; i++) {
         this.put(base.above(i), shaft);
      }

      this.put(base.above(height - 1), cap);
      if (light != null) {
         this.put(base.above(height), light);
      }
   }

   /** Ein kleiner Baum (Stamm + rundliche Krone), Laub bleibt stehen. */
   public void tree(BlockPos base, int trunk, Block log, Block leaves, int crown) {
      for (int i = 0; i < trunk; i++) {
         this.put(base.above(i), log);
      }

      BlockPos top = base.above(trunk);

      for (int a = -crown; a <= crown; a++) {
         for (int b = -crown; b <= crown; b++) {
            for (int c = -1; c <= crown; c++) {
               double d = a * a + b * b + (c - 0.3) * (c - 0.3) * 1.4;
               if (d <= crown * crown + 0.6 && this.deco.nextInt(9) != 0) {
                  this.putIfFree(top.offset(a, c, b), leaves);
               }
            }
         }
      }

      this.put(top.below(), log);
   }

   public static BlockState lantern(Block lantern, boolean hanging) {
      BlockState s = lantern.defaultBlockState();
      return s.hasProperty(BlockStateProperties.HANGING) ? s.setValue(BlockStateProperties.HANGING, hanging) : s;
   }

   // ------------------------------------------------------------------ Betten

   public void placeBed(BwTeam team) {
      Island is = this.island(team);
      BlockState bed = team.bed.defaultBlockState().setValue(BedBlock.FACING, is.forward);
      this.level.setBlock(is.bedFoot(), bed.setValue(BedBlock.PART, BedPart.FOOT), 3);
      this.level.setBlock(is.bedHead(), bed.setValue(BedBlock.PART, BedPart.HEAD), 3);
   }

   public List<BlockPos> bedBlocks(BwTeam team) {
      Island is = this.island(team);
      List<BlockPos> list = new ArrayList<>(2);

      for (int r = -3; r <= 3; r++) {
         for (int f = 0; f <= 7; f++) {
            for (int u = 1; u <= 3; u++) {
               BlockPos pos = is.at(r, u, f);
               if (this.level.getBlockState(pos).getBlock() == team.bed) {
                  list.add(pos);
               }
            }
         }
      }

      return list;
   }

   public void removeBed(BwTeam team) {
      BlockState air = Blocks.AIR.defaultBlockState();

      for (BlockPos pos : this.bedBlocks(team)) {
         this.level.setBlock(pos, air, FLAGS);
      }
   }

   public boolean hasBed(BwTeam team) {
      return !this.bedBlocks(team).isEmpty();
   }

   public BwTeam bedOwner(BlockPos pos) {
      for (Island is : this.islands) {
         if (Math.abs(pos.getX() - is.origin.getX()) <= ISLAND_RADIUS + 1
            && Math.abs(pos.getZ() - is.origin.getZ()) <= ISLAND_RADIUS + 1
            && Math.abs(pos.getY() - is.origin.getY()) <= 5) {
            return is.team;
         }
      }

      return null;
   }

   /** Steht man hier auf (oder ueber) irgendeiner Insel der Karte? */
   public boolean onAnyIsland(Vec3 pos) {
      if (pos.y < Y - 3 || pos.y > Y + 12) {
         return false;
      } else if (this.islandAt(pos, 1.0) != null) {
         return true;
      } else if (Math.hypot(pos.x - this.center.getX() - 0.5, pos.z - this.center.getZ() - 0.5) < this.midRadius + 1) {
         return true;
      } else {
         for (BlockPos d : this.diamondIslands) {
            if (Math.hypot(pos.x - d.getX() - 0.5, pos.z - d.getZ() - 0.5) < 5.5) {
               return true;
            }
         }

         return false;
      }
   }

   /** Zu welcher Team-Insel gehoert diese Stelle (mit etwas Rand)? */
   public BwTeam islandAt(Vec3 pos, double margin) {
      for (Island is : this.islands) {
         double dx = pos.x - (is.origin.getX() + 0.5);
         double dz = pos.z - (is.origin.getZ() + 0.5);
         if (dx * dx + dz * dz <= (ISLAND_RADIUS + margin) * (ISLAND_RADIUS + margin) && pos.y > Y - 8 && pos.y < Y + 20) {
            return is.team;
         }
      }

      return null;
   }

   /** Eine Team-Insel mit eigenem Koordinatensystem: f zeigt zur Mitte, r nach rechts. */
   public static final class Island {
      /** Die Spawner-Flaeche: r von -GEN_HALF_WIDTH bis +GEN_HALF_WIDTH, f von -7 bis -5. */
      public static final int GEN_HALF_WIDTH = 2;
      public final BwTeam team;
      public final BlockPos origin;
      public final Direction forward;
      public final Direction right;

      Island(BwTeam team, BlockPos origin, Direction forward) {
         this.team = team;
         this.origin = origin;
         this.forward = forward;
         this.right = forward.getClockWise();
      }

      public BlockPos at(int r, int u, int f) {
         return this.origin
            .offset(this.right.getStepX() * r + this.forward.getStepX() * f, u, this.right.getStepZ() * r + this.forward.getStepZ() * f);
      }

      public Vec3 atVec(double r, double u, double f) {
         return new Vec3(
            this.origin.getX() + 0.5 + this.right.getStepX() * r + this.forward.getStepX() * f,
            this.origin.getY() + u,
            this.origin.getZ() + 0.5 + this.right.getStepZ() * r + this.forward.getStepZ() * f
         );
      }

      public BlockPos bedFoot() {
         return this.at(0, 1, 3);
      }

      public BlockPos bedHead() {
         return this.at(0, 1, 4);
      }

      public Vec3 bedCenter() {
         return this.atVec(0.0, 1.3, 3.5);
      }

      /** Mitte der Spawner-Flaeche (eine Ebene ueber dem Boden). */
      public BlockPos generator() {
         return this.at(0, 1, -6);
      }

      /** Ein zufaelliges Feld auf der (grossen) Spawner-Flaeche, auf das ein Barren faellt. */
      public BlockPos generatorCell(Random rnd) {
         return this.at(rnd.nextInt(GEN_HALF_WIDTH * 2 + 1) - GEN_HALF_WIDTH, 1, -7 + rnd.nextInt(3));
      }

      /** Die ganze Spawner-Flaeche als Box. */
      public AABB generatorArea() {
         BlockPos a = this.at(-GEN_HALF_WIDTH, 1, -7);
         BlockPos b = this.at(GEN_HALF_WIDTH, 1, -5);
         return new AABB(
            Math.min(a.getX(), b.getX()), a.getY() - 0.5, Math.min(a.getZ(), b.getZ()),
            Math.max(a.getX(), b.getX()) + 1, a.getY() + 2.0, Math.max(a.getZ(), b.getZ()) + 1
         );
      }

      public Vec3 spawn() {
         return this.atVec(0.0, 1.0, -3.0);
      }

      public Vec3 shop() {
         return this.atVec(-6.0, 1.0, -2.0);
      }

      /** Stelle vor dem Shop, an der ein Bot einkauft. */
      public BlockPos shopFront() {
         return this.at(-4, 1, -2);
      }

      public Vec3 centerVec() {
         return new Vec3(this.origin.getX() + 0.5, this.origin.getY() + 1.0, this.origin.getZ() + 0.5);
      }
   }
}
