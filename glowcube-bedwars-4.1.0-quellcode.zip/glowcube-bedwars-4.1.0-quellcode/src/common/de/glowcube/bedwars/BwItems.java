package de.glowcube.bedwars;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.LodestoneTracker;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Die Spezial-Items (wie auf Hypixel): Pop-Up-Turm, Bruecken-Ei, TNT, Feuerball, Bettwanze,
 * Traumverteidiger, Magische Milch, Spieler-Tracker, Rettungsplattform - und die Fallen der Teams.
 * Erkannt werden sie an einem unsichtbaren Etikett ("bw") in den Item-Daten.
 */
public final class BwItems {
   public static final String FIREBALL = "fireball";
   public static final String TNT = "tnt";
   public static final String POPUP_TOWER = "popup_tower";
   public static final String BRIDGE_EGG = "bridge_egg";
   public static final String BEDBUG = "bedbug";
   public static final String GOLEM = "dream_defender";
   public static final String MAGIC_MILK = "magic_milk";
   public static final String TRACKER = "tracker";
   public static final String RESCUE = "rescue_platform";

   /** Fallen, die ein Team kaufen kann (Reihenfolge = Ausloesereihenfolge). */
   public enum Trap {
      BLIND("Es ist eine Falle!", "Blindheit und Langsamkeit fuer den Eindringling"),
      COUNTER("Gegenangriff", "Tempo und Sprungkraft fuer euch"),
      ALARM("Alarm", "macht Unsichtbare sichtbar und warnt euch"),
      FATIGUE("Bergbau-Muedigkeit", "Abbaulaehmung fuer den Eindringling");

      public final String label;
      public final String effect;

      Trap(String label, String effect) {
         this.label = label;
         this.effect = effect;
      }
   }

   private static final Deque<Placement> building = new ArrayDeque<>();
   private static final List<TempBlock> temp = new ArrayList<>();
   private static final Map<UUID, Integer> lastUse = new HashMap<>();
   private static final Map<UUID, Integer> milkUntil = new HashMap<>();

   private record Placement(BlockPos pos, BlockState state) {
   }

   private record TempBlock(BlockPos pos, BlockState state, int until) {
   }

   private BwItems() {
   }

   public static void reset() {
      building.clear();
      temp.clear();
      lastUse.clear();
      milkUntil.clear();
   }

   // ====================================================================== Items herstellen und erkennen

   public static ItemStack make(Item item, int count, String id, String name, ChatFormatting color, String... lore) {
      ItemStack s = new ItemStack(item, count);
      if (id != null) {
         CompoundTag tag = new CompoundTag();
         tag.putString("bw", id);
         s.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
      }

      if (name != null) {
         s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(s2 -> s2.withColor(color).withItalic(false)));
      }

      if (lore.length > 0) {
         List<Component> lines = new ArrayList<>();
         for (String l : lore) {
            lines.add(Component.literal(l).withStyle(s2 -> s2.withColor(ChatFormatting.GRAY).withItalic(false)));
         }

         s.set(DataComponents.LORE, new ItemLore(lines));
      }

      return s;
   }

   public static String idOf(ItemStack s) {
      if (s == null || s.isEmpty()) {
         return null;
      }

      CustomData data = s.get(DataComponents.CUSTOM_DATA);
      return data == null ? null : data.copyTag().getString("bw").orElse(null);
   }

   // ====================================================================== Benutzen

   /** Doppelte Ausloesung (Block-Klick und Luft-Klick im selben Moment) verhindern. */
   private static boolean debounce(ServerPlayer p) {
      int now = Game.tick();
      Integer last = lastUse.get(p.getUUID());
      if (last != null && now - last < 4 && now >= last) {
         return true;
      }

      lastUse.put(p.getUUID(), now);
      return false;
   }

   /**
    * Rechtsklick auf einen Block mit einem Item. Fuer Items, die sonst einen Block oder ein Wesen setzen
    * wuerden (TNT, Pop-Up-Turm, Golem-Ei).
    *
    * @return true = erledigt, Minecraft soll nichts mehr tun
    */
   public static boolean onUseOnBlock(ServerPlayer p, InteractionHand hand, BlockPos clicked, Direction face) {
      if (!Game.running() || !Game.isHuman(p)) {
         return false;
      }

      ItemStack stack = p.getItemInHand(hand);
      String id = idOf(stack);
      if (id == null && stack.is(net.minecraft.world.item.Items.FIRE_CHARGE)) {
         // jede Feuerkugel ist in der Runde ein Feuerball - nie eine Flamme auf dem Boden
         id = FIREBALL;
      }

      if (id == null) {
         return false;
      }

      switch (id) {
         case TNT, POPUP_TOWER, GOLEM -> {
         }
         default -> {
            // alles andere (Feuerball, Eier, Milch ...) wie ein Rechtsklick in die Luft - sonst legt z.B. der Feuerball Feuer
            return onUse(p, hand);
         }
      }

      if (debounce(p)) {
         return true;
      }

      ServerLevel level = (ServerLevel)p.level();
      BlockPos at = clicked.relative(face);
      boolean used = switch (id) {
         case TNT -> placeTnt(p, level, at);
         case POPUP_TOWER -> popupTower(p, level);
         default -> spawnGolem(p, level, at);
      };
      if (used) {
         consume(p, stack);
      }

      p.containerMenu.broadcastFullState();
      return true;
   }

   /** Rechtsklick in die Luft (oder auf einen Block, wenn dort nichts passiert ist). */
   public static boolean onUse(ServerPlayer p, InteractionHand hand) {
      if (!Game.running() || !Game.isHuman(p)) {
         return false;
      }

      ItemStack stack = p.getItemInHand(hand);
      String id = idOf(stack);
      if (id == null && stack.is(net.minecraft.world.item.Items.FIRE_CHARGE)) {
         // jede Feuerkugel ist in der Runde ein Feuerball - nie eine Flamme auf dem Boden
         id = FIREBALL;
      }

      if (id == null) {
         return false;
      }

      ServerLevel level = (ServerLevel)p.level();
      if (debounce(p)) {
         return true;
      }

      boolean used;
      switch (id) {
         case FIREBALL -> {
            Vec3 look = p.getLookAngle();
            BlockHitResult below = p.getXRot() > 50.0F ? rayBlock(p, 3.2) : null;
            if (below != null) {
               // auf den Boden unter sich: sofort explodieren und hochschleudern (Feuerball-Springen)
               Vec3 at = below.getLocation();
               BwEntities.explode(level, at, p, p, 2.6F, 4.0F, 1.55, false);
               level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
               p.getCooldowns().addCooldown(stack, 10);
               used = true;
               break;
            }

            BwEntities.Fireball fb = new BwEntities.Fireball(level, p, look.scale(0.1));
            fb.setPos(p.getX() + look.x * 1.5, p.getEyeY() + look.y * 1.5, p.getZ() + look.z * 1.5);
            level.addFreshEntity(fb);
            level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
            p.getCooldowns().addCooldown(stack, 10);
            used = true;
         }
         case BRIDGE_EGG -> {
            used = throwIt(p, level, BwEntities.Thrown.Kind.BRIDGE_EGG, 1.5F);
         }
         case BEDBUG -> {
            used = throwIt(p, level, BwEntities.Thrown.Kind.BEDBUG, 1.4F);
         }
         case POPUP_TOWER -> used = popupTower(p, level);
         case TNT -> {
            BlockHitResult hit = rayBlock(p, 4.5);
            used = hit != null && placeTnt(p, level, hit.getBlockPos().relative(hit.getDirection()));
         }
         case GOLEM -> {
            BlockHitResult hit = rayBlock(p, 5.0);
            used = hit != null && spawnGolem(p, level, hit.getBlockPos().relative(hit.getDirection()));
            if (hit == null) {
               p.sendSystemMessage(Component.literal("Schau auf den Boden, wo der Traumverteidiger erscheinen soll.").withStyle(ChatFormatting.RED));
            }
         }
         case MAGIC_MILK -> {
            drinkMilk(p);
            level.playSound(null, p.blockPosition(), SoundEvents.GENERIC_DRINK.value(), SoundSource.PLAYERS, 1.0F, 1.0F);
            p.sendSystemMessage(Component.literal("Magische Milch: 30 Sekunden lang loest du keine Fallen aus.").withStyle(ChatFormatting.AQUA));
            used = true;
         }
         case TRACKER -> {
            used = false;
            track(p, true);
         }
         case RESCUE -> used = rescuePlatform(p, level);
         default -> {
            return false;
         }
      }

      if (used) {
         consume(p, stack);
      }

      p.containerMenu.broadcastFullState();
      return true;
   }

   private static void consume(ServerPlayer p, ItemStack stack) {
      if (!p.isCreative()) {
         stack.shrink(1);
      }
   }

   private static BlockHitResult rayBlock(ServerPlayer p, double range) {
      Vec3 eye = p.getEyePosition();
      Vec3 end = eye.add(p.getLookAngle().scale(range));
      BlockHitResult hit = p.level().clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
      return hit.getType() == HitResult.Type.BLOCK ? hit : null;
   }

   private static boolean canPlace(ServerLevel level, BlockPos pos) {
      Arena a = Game.arena();
      return a != null && a.inBuildArea(pos) && !a.isMap(pos) && level.getBlockState(pos).canBeReplaced();
   }

   private static boolean placeTnt(ServerPlayer p, ServerLevel level, BlockPos at) {
      if (!canPlace(level, at)) {
         return false;
      }

      BwEntities.Tnt tnt = new BwEntities.Tnt(level, at.getX() + 0.5, at.getY(), at.getZ() + 0.5, p);
      level.addFreshEntity(tnt);
      level.playSound(null, at, SoundEvents.TNT_PRIMED, SoundSource.BLOCKS, 1.0F, 1.0F);
      return true;
   }

   private static boolean throwIt(ServerPlayer p, ServerLevel level, BwEntities.Thrown.Kind kind, float speed) {
      Game.TeamState t = Game.teamOfPlayer(p);
      if (t == null) {
         return false;
      }

      BwEntities.Thrown thrown = new BwEntities.Thrown(level, p, kind, t);
      thrown.shootFromRotation(p, p.getXRot(), p.getYRot(), 0.0F, speed, 0.6F);
      level.addFreshEntity(thrown);
      level.playSound(null, p.blockPosition(), kind == BwEntities.Thrown.Kind.BRIDGE_EGG ? SoundEvents.EGG_THROW : SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.6F, 0.8F);
      return true;
   }

   /** Traumverteidiger fuer ein Team rufen (auch fuer Bots). */
   public static void summonGolem(ServerLevel level, Game.TeamState t, BlockPos at, String by) {
      BwEntities.Golem g = new BwEntities.Golem(level, t, Vec3.atBottomCenterOf(at));
      g.setPos(at.getX() + 0.5, at.getY(), at.getZ() + 0.5);
      level.addFreshEntity(g);
      level.playSound(null, at, SoundEvents.IRON_GOLEM_REPAIR, SoundSource.NEUTRAL, 1.0F, 1.0F);
      Game.tell(Component.literal(by).withStyle(t.team.format).append(Component.literal(" hat einen Traumverteidiger gerufen!").withStyle(ChatFormatting.GRAY)));
   }

   private static boolean spawnGolem(ServerPlayer p, ServerLevel level, BlockPos at) {
      Game.TeamState t = Game.teamOfPlayer(p);
      if (t == null || !Game.arena().inBuildArea(at)) {
         return false;
      }

      BwEntities.Golem g = new BwEntities.Golem(level, t, Vec3.atBottomCenterOf(at));
      g.setPos(at.getX() + 0.5, at.getY(), at.getZ() + 0.5);
      g.setYRot(p.getYRot());
      level.addFreshEntity(g);
      level.playSound(null, at, SoundEvents.IRON_GOLEM_REPAIR, SoundSource.NEUTRAL, 1.0F, 1.0F);
      Game.tell(Component.literal(p.getName().getString()).withStyle(t.team.format)
         .append(Component.literal(" hat einen Traumverteidiger gerufen!").withStyle(ChatFormatting.GRAY)));
      return true;
   }

   /**
    * Pop-Up-Turm: ein 5x5-Wollturm mit Leiter, Plattform und Zinnen, der sich vor dem Spieler
    * Block fuer Block aufbaut. Die offene Seite zeigt zum Spieler.
    */
   private static boolean popupTower(ServerPlayer p, ServerLevel level) {
      Game.TeamState t = Game.teamOfPlayer(p);
      if (t == null) {
         return false;
      }

      if (!buildTower(level, p.blockPosition(), p.getDirection(), t)) {
         p.sendSystemMessage(Component.literal("Hier ist kein Platz fuer einen Pop-Up-Turm.").withStyle(ChatFormatting.RED));
         return false;
      }

      return true;
   }

   /** Baut einen Pop-Up-Turm 3 Bloecke vor {@code feet} in Richtung {@code d} (auch fuer Bots). */
   public static boolean buildTower(ServerLevel level, BlockPos feet, Direction d, Game.TeamState t) {
      Direction side = d.getClockWise();
      BlockPos c = feet.relative(d, 3);
      BlockState wool = t.team.wool.defaultBlockState();
      BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, d.getOpposite());
      List<Placement> list = new ArrayList<>();

      for (int y = 0; y <= 4; y++) {
         for (int a = -2; a <= 2; a++) {
            for (int b = -2; b <= 2; b++) {
               boolean wall = Math.abs(a) == 2 || Math.abs(b) == 2;
               boolean door = b == -2 && a == 0 && y <= 1;
               if (wall && !door && !(Math.abs(a) == 2 && Math.abs(b) == 2 && y > 3)) {
                  list.add(new Placement(c.relative(side, a).relative(d, b).above(y), wool));
               }
            }
         }

         list.add(new Placement(c.relative(d, 1).above(y), ladder));
      }

      // Plattform oben (mit Loch fuer die Leiter) und Zinnen
      for (int a = -2; a <= 2; a++) {
         for (int b = -2; b <= 2; b++) {
            if (!(a == 0 && b == 1)) {
               list.add(new Placement(c.relative(side, a).relative(d, b).above(5), wool));
            }

            boolean rim = Math.abs(a) == 2 || Math.abs(b) == 2;
            if (rim && (a + b & 1) == 0) {
               list.add(new Placement(c.relative(side, a).relative(d, b).above(6), wool));
            }
         }
      }

      list.add(new Placement(c.relative(d, 1).above(5), ladder));
      int ok = 0;

      for (Placement pl : list) {
         if (canPlace(level, pl.pos)) {
            ok++;
         }
      }

      if (ok < list.size() / 2) {
         return false;
      }

      building.addAll(list);
      return true;
   }

   /** Rettungsplattform: fuer 10 Sekunden ein Schleimteppich unter den Fuessen - faengt jeden Sturz. */
   private static boolean rescuePlatform(ServerPlayer p, ServerLevel level) {
      if (!rescueAt(level, p.blockPosition().below(2))) {
         p.sendSystemMessage(Component.literal("Unter dir ist kein Platz fuer die Plattform.").withStyle(ChatFormatting.RED));
         return false;
      }

      p.fallDistance = 0.0;
      level.playSound(null, p.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.0F, 1.0F);
      return true;
   }

   /** Schleimplattform fuer 10 Sekunden um {@code c} (auch fuer Bots). */
   public static boolean rescueAt(ServerLevel level, BlockPos c) {
      int placed = 0;

      for (int a = -2; a <= 2; a++) {
         for (int b = -2; b <= 2; b++) {
            if (Math.abs(a) + Math.abs(b) <= 3) {
               BlockPos pos = c.offset(a, 0, b);
               if (canPlace(level, pos)) {
                  BlockState slime = Blocks.SLIME_BLOCK.defaultBlockState();
                  level.setBlock(pos, slime, 3);
                  temp.add(new TempBlock(pos, slime, Game.tick() + 200));
                  placed++;
               }
            }
         }
      }

      return placed > 0;
   }

   /** Magische Milch: 30 Sekunden keine Fallen (auch fuer Bots). */
   public static void drinkMilk(LivingEntity e) {
      milkUntil.put(e.getUUID(), Game.tick() + 20 * 30);
      e.removeEffect(MobEffects.BLINDNESS);
      e.removeEffect(MobEffects.SLOWNESS);
      e.removeEffect(MobEffects.MINING_FATIGUE);
      e.removeEffect(MobEffects.GLOWING);
   }

   /** Der Kompass zeigt auf den naechsten Gegner; mit Rechtsklick sagt er die Entfernung. */
   private static void track(ServerPlayer p, boolean tellDistance) {
      Game.TeamState t = Game.teamOfPlayer(p);
      if (t == null) {
         return;
      }

      LivingEntity best = null;
      double bd = Double.MAX_VALUE;

      for (LivingEntity e : Game.enemiesOf(t)) {
         if (e instanceof BwEntities.TeamMob) {
            continue;
         }

         double d = e.distanceToSqr(p);
         if (d < bd) {
            bd = d;
            best = e;
         }
      }

      for (InteractionHand hand : InteractionHand.values()) {
         ItemStack s = p.getItemInHand(hand);
         if (TRACKER.equals(idOf(s))) {
            s.set(DataComponents.LODESTONE_TRACKER, new LodestoneTracker(
               best == null ? Optional.empty() : Optional.of(GlobalPos.of(best.level().dimension(), best.blockPosition())), false));
         }
      }

      if (tellDistance || best != null) {
         Component msg = best == null
            ? Component.literal("Kein Gegner gefunden").withStyle(ChatFormatting.GRAY)
            : Component.literal("Ziel: ").withStyle(ChatFormatting.GRAY)
               .append(best.getDisplayName().copy())
               .append(Component.literal(" - " + (int)Math.sqrt(bd) + " Bloecke").withStyle(ChatFormatting.YELLOW));
         p.sendOverlayMessage(msg);
      }
   }

   // ====================================================================== Jeden Tick

   public static void tick(ServerLevel level) {
      // Pop-Up-Tuerme bauen sich auf: 3 Bloecke pro Tick
      for (int i = 0; i < 3 && !building.isEmpty(); i++) {
         Placement pl = building.poll();
         if (canPlace(level, pl.pos) && level.getEntitiesOfClass(LivingEntity.class, new AABB(pl.pos)).isEmpty()) {
            level.setBlock(pl.pos, pl.state, 3);
            if (i == 0) {
               level.playSound(null, pl.pos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 0.7F, 1.0F + level.getRandom().nextFloat() * 0.3F);
            }
         }
      }

      if (!temp.isEmpty()) {
         int now = Game.tick();
         for (Iterator<TempBlock> it = temp.iterator(); it.hasNext(); ) {
            TempBlock tb = it.next();
            if (now >= tb.until) {
               if (level.getBlockState(tb.pos) == tb.state) {
                  level.setBlock(tb.pos, Blocks.AIR.defaultBlockState(), 3);
               }

               it.remove();
            }
         }
      }
   }

   // ====================================================================== Jede Sekunde

   public static void second() {
      for (Game.Human h : Game.humans()) {
         if (!h.active()) {
            continue;
         }

         ServerPlayer p = h.p;
         Game.TeamState t = h.team;
         if (t.haste > 0) {
            p.addEffect(new MobEffectInstance(MobEffects.HASTE, 50, t.haste - 1, true, false));
         }

         if (TRACKER.equals(idOf(p.getMainHandItem())) || TRACKER.equals(idOf(p.getOffhandItem()))) {
            track(p, false);
         }
      }

      checkTraps();
   }

   private static boolean milked(LivingEntity e) {
      Integer until = milkUntil.get(e.getUUID());
      return until != null && until > Game.tick();
   }

   /** Betritt ein Gegner eine Insel mit Falle, schnappt die erste Falle zu. */
   private static void checkTraps() {
      Arena arena = Game.arena();
      for (Game.TeamState t : Game.teams()) {
         if (t.traps.isEmpty() || Game.tick() < t.trapReadyAt || !t.alive()) {
            continue;
         }

         Vec3 home = t.island().centerVec();
         for (LivingEntity e : Game.enemiesOf(t)) {
            if (e instanceof BwEntities.TeamMob || milked(e)) {
               continue;
            }

            if (arena.islandAt(e.position(), 2.0) == t.team && e.position().distanceTo(home) < Arena.ISLAND_RADIUS + 2) {
               trigger(t, t.traps.remove(0), e);
               t.trapReadyAt = Game.tick() + 20 * 15;
               break;
            }
         }
      }
   }

   private static void trigger(Game.TeamState t, Trap trap, LivingEntity intruder) {
      switch (trap) {
         case BLIND -> {
            intruder.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 160, 0));
            intruder.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 160, 1));
         }
         case COUNTER -> {
            for (LivingEntity m : Game.membersOf(t)) {
               if (m.position().distanceTo(t.island().centerVec()) < 20.0) {
                  m.addEffect(new MobEffectInstance(MobEffects.SPEED, 300, 1));
                  m.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, 300, 1));
               }
            }
         }
         case ALARM -> {
            intruder.removeEffect(MobEffects.INVISIBILITY);
            intruder.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
         }
         case FATIGUE -> intruder.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, 200, 1));
      }

      Component who = intruder.getDisplayName();
      for (Game.Human h : t.humans) {
         if (h.online()) {
            Game.title(h.p, Component.literal("FALLE AUSGELOEST!").withStyle(ChatFormatting.RED, ChatFormatting.BOLD),
               Component.literal(trap.label + ": ").withStyle(ChatFormatting.GRAY).append(who.copy()));
            h.p.level().playSound(null, h.p.blockPosition(), SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 0.6F);
         }
      }

      if (intruder instanceof ServerPlayer sp) {
         Game.title(sp, Component.literal("FALLE!").withStyle(ChatFormatting.RED, ChatFormatting.BOLD),
            Component.literal("Du hast \"" + trap.label + "\" von Team " + t.team.label + " ausgeloest").withStyle(ChatFormatting.GRAY));
      }

      TeamBrain.requestThink(t);
   }
}
