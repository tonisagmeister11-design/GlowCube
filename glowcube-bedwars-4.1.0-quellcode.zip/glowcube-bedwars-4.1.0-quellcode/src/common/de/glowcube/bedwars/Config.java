package de.glowcube.bedwars;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/** Einstellungen in glowcube_bedwars.properties (Fabric: config/, Paper: plugins/GlowCubeBedwars/). */
public final class Config {
   public static final String[] DIFFICULTIES = new String[]{"leicht", "normal", "schwer", "profi"};
   /** 0 leicht, 1 normal, 2 schwer, 3 profi */
   public static int difficulty = 1;
   /** So lange hat man Zeit, die Einladung anzuklicken. */
   public static int inviteSeconds = 5;
   /** So lange darf der Gastgeber Teams einteilen, danach wird zufaellig verteilt. */
   public static int teamSelectSeconds = 60;
   /** Hoechstens so viele echte Spieler pro Runde. */
   public static int maxPlayers = 20;
   /** Die zuletzt gespielten Karten (neueste zuerst), damit nicht dauernd dieselbe kommt. */
   public static final List<Integer> recentMaps = new ArrayList<>();

   private Config() {
   }

   private static Path file() {
      return Platform.get().configDir().resolve("glowcube_bedwars.properties");
   }

   private static Properties read() {
      Properties p = new Properties();

      try {
         Path f = file();
         if (Files.exists(f)) {
            try (Reader r = Files.newBufferedReader(f)) {
               p.load(r);
            }
         }
      } catch (Exception e) {
         System.err.println("[Bedwars] Einstellungen unlesbar: " + e);
      }

      return p;
   }

   private static int intProp(Properties p, String key, int def, int min, int max) {
      try {
         return Math.max(min, Math.min(max, Integer.parseInt(p.getProperty(key, String.valueOf(def)).trim())));
      } catch (Exception e) {
         return def;
      }
   }

   public static void load() {
      Properties p = read();
      String d = p.getProperty("schwierigkeit", "normal").trim().toLowerCase();

      for (int i = 0; i < DIFFICULTIES.length; i++) {
         if (DIFFICULTIES[i].equals(d)) {
            difficulty = i;
         }
      }

      inviteSeconds = intProp(p, "einladung_sekunden", 5, 3, 120);
      teamSelectSeconds = intProp(p, "teamwahl_sekunden", 60, 10, 600);
      maxPlayers = intProp(p, "max_spieler", 20, 2, Game.TEAM_SIZE * BwTeam.values().length);
      recentMaps.clear();

      for (String s : p.getProperty("letzte_karten", "").split(",")) {
         try {
            if (!s.isBlank()) {
               recentMaps.add(Integer.parseInt(s.trim()));
            }
         } catch (NumberFormatException ignored) {
         }
      }

      save(p);
   }

   public static void save() {
      save(read());
   }

   private static void save(Properties p) {
      p.setProperty("schwierigkeit", DIFFICULTIES[difficulty]);
      p.setProperty("einladung_sekunden", String.valueOf(inviteSeconds));
      p.setProperty("teamwahl_sekunden", String.valueOf(teamSelectSeconds));
      p.setProperty("max_spieler", String.valueOf(maxPlayers));
      StringBuilder sb = new StringBuilder();

      for (int i = 0; i < recentMaps.size(); i++) {
         sb.append(i == 0 ? "" : ",").append(recentMaps.get(i));
      }

      p.setProperty("letzte_karten", sb.toString());

      try {
         Files.createDirectories(file().getParent());

         try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "GlowCube Bedwars - schwierigkeit: leicht|normal|schwer|profi");
         }
      } catch (Exception e) {
         System.err.println("[Bedwars] Einstellungen nicht gespeichert: " + e);
      }
   }
}
