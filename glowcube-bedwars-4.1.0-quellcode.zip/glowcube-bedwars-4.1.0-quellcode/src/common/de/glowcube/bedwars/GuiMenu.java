package de.glowcube.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/**
 * Eine Kisten-Oberflaeche (Shop, Teamwahl, Gluecksrad), aus der man nichts herausnehmen kann.
 * Alle Klicks oben landen beim {@link Handler}; das eigene Inventar unten ist je nach Menue frei oder gesperrt.
 */
public final class GuiMenu extends ChestMenu {
   public interface Handler {
      /** Klick in ein Feld oben (0 .. rows*9-1). */
      void click(GuiMenu menu, ServerPlayer p, int slot, ContainerInput input, int button);

      /** Das Menue wurde geschlossen. */
      default void closed(GuiMenu menu, ServerPlayer p) {
      }

      /** Darf man unten im eigenen Inventar Sachen verschieben? */
      default boolean ownInventory() {
         return false;
      }
   }

   public final SimpleContainer box;
   public final int size;
   private final Handler handler;

   private GuiMenu(int id, Inventory inv, int rows, SimpleContainer box, Handler handler) {
      super(type(rows), id, inv, box, rows);
      this.box = box;
      this.size = rows * 9;
      this.handler = handler;
   }

   private static MenuType<ChestMenu> type(int rows) {
      return switch (rows) {
         case 1 -> MenuType.GENERIC_9x1;
         case 2 -> MenuType.GENERIC_9x2;
         case 3 -> MenuType.GENERIC_9x3;
         case 4 -> MenuType.GENERIC_9x4;
         case 5 -> MenuType.GENERIC_9x5;
         default -> MenuType.GENERIC_9x6;
      };
   }

   /** Oeffnet ein Menue; der Aufbau steht vorher schon in {@code box}. */
   public static GuiMenu open(ServerPlayer p, Component title, int rows, SimpleContainer box, Handler handler) {
      GuiMenu[] made = new GuiMenu[1];
      p.openMenu(new SimpleMenuProvider((id, inv, pl) -> made[0] = new GuiMenu(id, inv, rows, box, handler), title));
      return made[0];
   }

   public static SimpleContainer box(int rows) {
      return new SimpleContainer(rows * 9);
   }

   @Override
   public void clicked(int slot, int button, ContainerInput input, Player pl) {
      if (!(pl instanceof ServerPlayer sp)) {
         return;
      }

      if (slot >= 0 && slot < this.size) {
         this.handler.click(this, sp, slot, input, button);
      } else if (input == ContainerInput.QUICK_CRAFT) {
         this.handler.click(this, sp, -1, input, button);
      } else if (this.handler.ownInventory() && slot >= this.size && (input == ContainerInput.PICKUP || input == ContainerInput.SWAP)) {
         super.clicked(slot, button, input, pl);
      }

      this.broadcastFullState();
   }

   @Override
   public ItemStack quickMoveStack(Player player, int slot) {
      return ItemStack.EMPTY;
   }

   @Override
   public boolean stillValid(Player player) {
      return true;
   }

   @Override
   public void removed(Player pl) {
      if (pl instanceof ServerPlayer sp) {
         this.handler.closed(this, sp);
      }

      // nichts vom Mauszeiger ins Inventar fallen lassen (z.B. einen Spielerkopf aus der Teamwahl)
      if (!this.handler.ownInventory()) {
         this.setCarried(ItemStack.EMPTY);
      }

      super.removed(pl);
   }
}
