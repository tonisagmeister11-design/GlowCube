package de.glowcube.bedwars;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.RotationSegment;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * Wie eine Karte aussieht. Die Spielgeometrie (Inselform, Bett, Spawner-Flaeche, Shop, Spawn) baut die
 * Grundklasse fuer alle Karten gleich; die Themen liefern Materialien und Verzierungen.
 *
 * Verzierungen stehen nur am Rand der Inseln (|r| >= 6), damit Wege, Bett-Verteidigung und
 * Spawner frei bleiben. Kein Sand/Kies (faellt), kein lebendes Laub/Korallen (verwelken), kein Eis
 * auf begehbarem Boden (rutschig), keine Teppiche auf Wegen (Bots stolpern).
 */
public abstract class MapTheme {
   public final String key;
   public final String name;
   public final String description;
   public final Item icon;
   public final ChatFormatting color;
   public int teamRing = 42;
   public int diamondRing = 29;
   public int midRadius = 11;

   // Grundmaterialien
   protected Block floorA = Blocks.SMOOTH_QUARTZ;
   protected Block floorB = Blocks.QUARTZ_BRICKS;
   protected Block ring = Blocks.POLISHED_ANDESITE;
   protected Block edge = Blocks.STONE_BRICKS;
   protected Block edgeAccent = Blocks.CHISELED_STONE_BRICKS;
   protected Block underTop = Blocks.STONE_BRICKS;
   protected Block[] rocks = {Blocks.ANDESITE, Blocks.STONE, Blocks.COBBLESTONE};
   protected Block genFloor = Blocks.SMOOTH_STONE;
   protected Block genLight = Blocks.SEA_LANTERN;
   protected Block light = Blocks.LANTERN;
   protected Block roof = Blocks.SMOOTH_QUARTZ_SLAB;
   protected Block shopPost = Blocks.STONE_BRICK_WALL;
   protected Block midA = Blocks.SMOOTH_STONE;
   protected Block midB = Blocks.POLISHED_ANDESITE;
   protected Block midInner = Blocks.QUARTZ_BRICKS;
   protected Block midAccent = Blocks.CHISELED_QUARTZ_BLOCK;
   protected Block podium = Blocks.SMOOTH_QUARTZ;

   protected MapTheme(String key, String name, String description, Item icon, ChatFormatting color) {
      this.key = key;
      this.name = name;
      this.description = description;
      this.icon = icon;
      this.color = color;
   }

   public static final List<MapTheme> ALL = List.of(
      new Rome(), new Sakura(), new Desert(), new Frost(), new Nether(), new Jungle(), new Ocean(), new EndCity()
   );

   // ====================================================================== Team-Insel

   public void buildTeamIsland(Arena a, Arena.Island is) {
      BwTeam team = is.team;
      int R = Arena.ISLAND_RADIUS;

      for (int r = -R; r <= R; r++) {
         for (int f = -R; f <= R; f++) {
            if (Arena.octagon(r, f, R)) {
               Block block;
               if (!Arena.octagon(r, f, R - 1)) {
                  block = (r + f & 3) == 0 ? this.edgeAccent : this.edge;
               } else if (!Arena.octagon(r, f, R - 2)) {
                  block = this.ring;
               } else if (r == 0 && f >= -4 && f <= 1) {
                  block = team.concrete;
               } else if (Math.abs(r) <= 2 && f >= 2 && f <= 5 && (Math.abs(r) == 2 || f == 2 || f == 5)) {
                  block = team.terracotta;
               } else {
                  block = this.floor(r, f);
               }

               a.put(is.at(r, 0, f), block);
            }
         }
      }

      a.underside(is.origin, R, false, this.underTop, this.rocks);
      this.generatorPad(a, is);
      this.corner(a, is, -6, -6, true);
      this.corner(a, is, 6, -6, true);
      this.corner(a, is, -6, 5, false);
      this.corner(a, is, 6, 5, false);
      this.feature(a, is);
      this.shop(a, is);
   }

   protected Block floor(int r, int f) {
      return (r + f & 1) == 0 ? this.floorA : this.floorB;
   }

   /** Grosse Spawner-Flaeche (5 x 3): Eisen in der Mitte, Gold aussen - Platz fuer alle. */
   protected void generatorPad(Arena a, Arena.Island is) {
      int w = Arena.Island.GEN_HALF_WIDTH;

      for (int r = -w; r <= w; r++) {
         for (int f = -7; f <= -5; f++) {
            Block b;
            if (f == -6 && Math.abs(r) <= 1) {
               b = Blocks.IRON_BLOCK;
            } else if (f == -6) {
               b = Blocks.GOLD_BLOCK;
            } else if (Math.abs(r) == w) {
               b = is.team.terracotta;
            } else {
               b = this.genFloor;
            }

            a.put(is.at(r, 0, f), b);
         }
      }

      a.put(is.at(0, 0, -8), this.genLight);
   }

   /** Ecke der Insel (r = +-6, f = -6 hinten oder 5 vorne). */
   protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
      a.column(is.at(r, 1, f), back ? 5 : 4, Blocks.QUARTZ_BRICKS, Blocks.QUARTZ_PILLAR, Blocks.CHISELED_QUARTZ_BLOCK, Arena.lantern(this.light, false));
   }

   /** Das Schmuckstueck rechts vom Spawn (r = 6, f = -3 .. -1). */
   protected void feature(Arena a, Arena.Island is) {
   }

   /** Der Shop-Pavillon links vom Spawn (Haendler bei r = -6, f = -2). */
   protected void shop(Arena a, Arena.Island is) {
      for (int f = -3; f <= -1; f += 2) {
         for (int u = 1; u <= 3; u++) {
            a.put(is.at(-7, u, f), this.shopPost);
         }
      }

      for (int r = -7; r <= -5; r++) {
         for (int f = -3; f <= -1; f++) {
            a.put(is.at(r, 4, f), r == -5 || f != -2 ? is.team.wool : this.roof);
         }
      }

      a.put(is.at(-6, 4, -2), this.roofCenter());
      a.put(is.at(-6, 3, -2), Arena.lantern(this.light, true));
   }

   protected Block roofCenter() {
      return this.floorA;
   }

   protected static BlockState banner(BwTeam team, Direction facing) {
      return Blocks.BANNER.pick(team.dye).defaultBlockState().setValue(BannerBlock.ROTATION, RotationSegment.convertToSegment(facing));
   }

   protected static BlockState slabTop(Block slab) {
      return slab.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP);
   }

   protected static BlockState stair(Block stair, Direction facing, boolean top) {
      return stair.defaultBlockState().setValue(StairBlock.FACING, facing).setValue(StairBlock.HALF, top ? Half.TOP : Half.BOTTOM);
   }

   protected static BlockState skull(Block head, Direction facing) {
      return head.defaultBlockState().setValue(SkullBlock.ROTATION, RotationSegment.convertToSegment(facing));
   }

   // ====================================================================== Diamant-Insel

   public void buildDiamondIsland(Arena a, BlockPos c, Direction out) {
      int R = 4;

      for (int x = -R; x <= R; x++) {
         for (int z = -R; z <= R; z++) {
            int d = x * x + z * z;
            if (d <= R * R + 1) {
               Block block = d > (R - 1) * (R - 1) + 1 ? this.edge : ((x + z & 1) == 0 ? this.midB : this.midA);
               a.put(c.offset(x, 0, z), block);
            }
         }
      }

      a.underside(c, R, true, this.underTop, this.rocks);
      a.put(c, Blocks.DIAMOND_BLOCK);
      a.put(c.offset(1, 0, 1), this.genLight);
      a.put(c.offset(-1, 0, -1), this.genLight);
      a.put(c.offset(1, 0, -1), this.edgeAccent);
      a.put(c.offset(-1, 0, 1), this.edgeAccent);
      Direction side = out.getClockWise();
      this.diamondDecor(a, c.relative(out, 3).relative(side, 2).above(), out);
      this.diamondDecor(a, c.relative(out, 3).relative(side, -2).above(), out);
   }

   protected void diamondDecor(Arena a, BlockPos base, Direction out) {
      a.column(base, 4, Blocks.QUARTZ_BRICKS, Blocks.QUARTZ_PILLAR, Blocks.CHISELED_QUARTZ_BLOCK, Arena.lantern(this.light, false));
   }

   // ====================================================================== Mitte

   public void buildMid(Arena a, BlockPos c) {
      int R = this.midRadius;

      for (int x = -R; x <= R; x++) {
         for (int z = -R; z <= R; z++) {
            int d2 = x * x + z * z;
            if (d2 <= R * R + R) {
               double d = Math.sqrt(d2);
               Block block;
               if (d > R - 1) {
                  block = ((x * 7 + z * 3) & 3) == 0 ? this.edgeAccent : this.edge;
               } else if (d <= 4.6) {
                  block = this.midInner;
               } else if (Math.abs(d - 6.5) < 0.6) {
                  block = this.midAccent;
               } else if (x == 0 || z == 0 || Math.abs(x) == Math.abs(z)) {
                  block = this.midB;
               } else {
                  block = this.midA;
               }

               a.put(c.offset(x, 0, z), block);
            }
         }
      }

      a.underside(c, R, true, this.underTop, this.rocks);

      // Podest (eine Stufe hoch) mit den Smaragd-Spawnern
      for (int x = -3; x <= 3; x++) {
         for (int z = -3; z <= 3; z++) {
            if (x * x + z * z <= 10) {
               a.put(c.offset(x, 1, z), x * x + z * z <= 2 ? this.midAccent : this.podium);
            }
         }
      }

      a.put(c.offset(2, 1, 0), Blocks.EMERALD_BLOCK);
      a.put(c.offset(-2, 1, 0), Blocks.EMERALD_BLOCK);
      a.put(c.offset(0, 1, 3), this.genLight);
      a.put(c.offset(0, 1, -3), this.genLight);
      this.midCenter(a, c);
      this.midRing(a, c);
   }

   /** Das Herzstueck auf dem Podest (Mitte, bei 0/2/0 und darueber). */
   protected void midCenter(Arena a, BlockPos c) {
   }

   /** Verzierung rund um die Mitte (Radius etwa 8.5). */
   protected void midRing(Arena a, BlockPos c) {
   }

   /** Punkte auf einem Kreis um die Mitte. */
   protected static BlockPos onCircle(BlockPos c, double radius, double degrees, int y) {
      double ang = Math.toRadians(degrees);
      return c.offset((int)Math.round(Math.cos(ang) * radius), y, (int)Math.round(Math.sin(ang) * radius));
   }

   // ######################################################################
   // Die Karten
   // ######################################################################

   /** 1. Rom - die alte Karte, aufgehuebscht: Banner, Blumen, Brunnen. */
   static final class Rome extends MapTheme {
      Rome() {
         super("rom", "Rom", "Marmor-Inseln, Saeulen und ein Rundtempel mit Leuchtfeuer", Items.QUARTZ_PILLAR, ChatFormatting.WHITE);
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         BlockPos base = is.at(r, 1, f);
         a.column(base, back ? 5 : 4, Blocks.QUARTZ_BRICKS, Blocks.QUARTZ_PILLAR, Blocks.CHISELED_QUARTZ_BLOCK, null);
         a.put(base.above(back ? 5 : 4), back ? banner(is.team, is.forward) : Arena.lantern(Blocks.LANTERN, false));
         a.put(is.at(r > 0 ? r + 1 : r - 1, 1, f), Blocks.POTTED_RED_TULIP.defaultBlockState());
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         statue(a, is.at(6, 1, -2), is.forward, is.right.getOpposite(), Blocks.CHISELED_QUARTZ_BLOCK, false);
         a.put(is.at(6, 1, -1), Blocks.LANTERN);
         a.put(is.at(6, 1, -3), Blocks.LANTERN);
      }

      static void statue(Arena a, BlockPos base, Direction right, Direction facing, Block torso, boolean big) {
         a.put(base, Blocks.CHISELED_STONE_BRICKS);
         int y = 1;
         if (big) {
            a.put(base.above(y++), Blocks.CHISELED_QUARTZ_BLOCK);
         }

         a.put(base.above(y++), Blocks.QUARTZ_PILLAR);
         a.put(base.above(y++), Blocks.QUARTZ_PILLAR);
         BlockPos chest = base.above(y);
         a.put(chest, torso);
         BlockState arm = slabTop(Blocks.QUARTZ_SLAB);
         a.put(chest.relative(right), arm);
         a.put(chest.relative(right.getOpposite()), arm);
         a.put(chest.relative(right).above(), Blocks.END_ROD);
         a.put(chest.relative(right).above(2), Blocks.END_ROD);
         a.put(chest.relative(right).below(), Blocks.END_ROD);
         a.put(chest.above(), skull(Blocks.PLAYER_HEAD, facing));
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         a.column(base, 4, Blocks.QUARTZ_BRICKS, Blocks.QUARTZ_PILLAR, Blocks.CHISELED_QUARTZ_BLOCK, Arena.lantern(Blocks.LANTERN, false));
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // Leuchtfeuer: der Strahl geht durch die offene Kuppel in den Himmel
         for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
               a.put(c.offset(x, 0, z), (x + z & 1) == 0 ? Blocks.GOLD_BLOCK : Blocks.EMERALD_BLOCK);
            }
         }

         a.put(c.offset(0, 1, 0), Blocks.BEACON);
         statue(a, c.offset(4, 1, 4), Direction.EAST, Direction.NORTH, Blocks.GOLD_BLOCK, true);
         statue(a, c.offset(-4, 1, -4), Direction.WEST, Direction.SOUTH, Blocks.GOLD_BLOCK, true);
         statue(a, c.offset(4, 1, -4), Direction.NORTH, Direction.WEST, Blocks.GOLD_BLOCK, true);
         statue(a, c.offset(-4, 1, 4), Direction.SOUTH, Direction.EAST, Blocks.GOLD_BLOCK, true);
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         for (int i = 0; i < 10; i++) {
            BlockPos base = onCircle(c, 8.5, i * 36.0 + 18.0, 1);
            a.column(base, 7, Blocks.QUARTZ_BRICKS, Blocks.QUARTZ_PILLAR, Blocks.CHISELED_QUARTZ_BLOCK, null);
            a.put(base.above(7), Blocks.CHISELED_QUARTZ_BLOCK);
         }

         for (int x = -10; x <= 10; x++) {
            for (int z = -10; z <= 10; z++) {
               double d = Math.sqrt(x * x + z * z);
               if (d >= 7.5 && d <= 9.6) {
                  a.putIfFree(c.offset(x, 8, z), Blocks.SMOOTH_QUARTZ_SLAB);
               }
            }
         }

         for (int i = 0; i < 10; i += 2) {
            a.putIfFree(onCircle(c, 8.5, i * 36.0, 7), Arena.lantern(Blocks.LANTERN, true));
         }

         // Team-Banner auf dem Ring
         for (BwTeam t : BwTeam.values()) {
            BlockPos p = onCircle(c, 8.5, -90.0 + 72.0 * t.ordinal(), 9);
            a.put(p, banner(t, Arena.towards(c, p)));
         }
      }
   }

   /** 2. Kirschbluetental - Japanischer Garten mit Kirschbaeumen, Torii und Pagode. */
   static final class Sakura extends MapTheme {
      Sakura() {
         super("sakura", "Kirschbluetental", "Japanischer Garten mit Kirschbaeumen, Torii-Toren und einer Pagode", Items.CHERRY_SAPLING, ChatFormatting.LIGHT_PURPLE);
         this.teamRing = 43;
         this.diamondRing = 30;
         this.floorA = Blocks.GRASS_BLOCK;
         this.floorB = Blocks.MOSS_BLOCK;
         this.ring = Blocks.MOSSY_STONE_BRICKS;
         this.edge = Blocks.STONE_BRICKS;
         this.edgeAccent = Blocks.MOSSY_COBBLESTONE;
         this.underTop = Blocks.DIRT;
         this.rocks = new Block[]{Blocks.STONE, Blocks.ANDESITE, Blocks.TUFF, Blocks.ROOTED_DIRT};
         this.genFloor = Blocks.POLISHED_ANDESITE;
         this.genLight = Blocks.OCHRE_FROGLIGHT;
         this.light = Blocks.LANTERN;
         this.roof = Blocks.DARK_OAK_SLAB;
         this.shopPost = Blocks.STRIPPED_CHERRY_LOG;
         this.midA = Blocks.CHERRY_PLANKS;
         this.midB = Blocks.STRIPPED_CHERRY_WOOD;
         this.midInner = Blocks.POLISHED_ANDESITE;
         this.midAccent = Blocks.DYED_TERRACOTTA.pick(net.minecraft.world.item.DyeColor.PINK);
         this.podium = Blocks.SMOOTH_STONE;
      }

      @Override
      protected Block floor(int r, int f) {
         // Trittsteine im Gras
         return (r * 5 + f * 3 & 7) == 0 ? Blocks.SMOOTH_STONE : ((r + f & 1) == 0 ? this.floorA : this.floorB);
      }

      @Override
      protected Block roofCenter() {
         return Blocks.CHERRY_PLANKS;
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         if (back) {
            a.tree(is.at(r, 1, f), 4, Blocks.CHERRY_LOG, Blocks.CHERRY_LEAVES, 2);
         } else {
            // Steinlaterne (Toro)
            BlockPos b = is.at(r, 1, f);
            a.put(b, Blocks.STONE_BRICK_WALL);
            a.put(b.above(), Blocks.CHISELED_STONE_BRICKS);
            a.put(b.above(2), Arena.lantern(Blocks.LANTERN, false));
            a.put(b.above(3), Blocks.STONE_BRICK_SLAB);
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         // kleines Torii-Tor neben dem Spawn
         Block post = Blocks.STRIPPED_MANGROVE_LOG;
         for (int u = 1; u <= 3; u++) {
            a.put(is.at(6, u, -3), post);
            a.put(is.at(6, u, -1), post);
         }

         for (int f = -4; f <= 0; f++) {
            a.put(is.at(6, 4, f), Blocks.MANGROVE_PLANKS);
         }

         a.put(is.at(6, 5, -4), Blocks.DARK_OAK_SLAB);
         a.put(is.at(6, 5, 0), Blocks.DARK_OAK_SLAB);
         a.put(is.at(6, 3, -2), Arena.lantern(Blocks.LANTERN, true));
         a.put(is.at(7, 1, -2), Blocks.POTTED_CHERRY_SAPLING.defaultBlockState());
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         a.tree(base, 3, Blocks.CHERRY_LOG, Blocks.CHERRY_LEAVES, 1);
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // Pagode: drei Daecher uebereinander, unten offen
         for (int x = -1; x <= 1; x += 2) {
            for (int z = -1; z <= 1; z += 2) {
               for (int u = 2; u <= 4; u++) {
                  a.put(c.offset(x, u, z), Blocks.STRIPPED_CHERRY_LOG);
               }
            }
         }

         int[] radius = {3, 2, 1};
         for (int level = 0; level < 3; level++) {
            int y = 5 + level * 3;
            int rr = radius[level];
            for (int x = -rr; x <= rr; x++) {
               for (int z = -rr; z <= rr; z++) {
                  a.put(c.offset(x, y, z), Math.abs(x) == rr || Math.abs(z) == rr ? Blocks.DARK_OAK_SLAB.defaultBlockState() : Blocks.CHERRY_PLANKS.defaultBlockState());
               }
            }

            if (level < 2) {
               for (int u = 1; u <= 2; u++) {
                  a.put(c.offset(0, y + u, 0), Blocks.STRIPPED_CHERRY_LOG);
               }
            }

            a.put(c.offset(0, y - 1, 0), Arena.lantern(Blocks.LANTERN, true));
         }

         a.put(c.offset(0, 12, 0), Blocks.END_ROD);
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         for (int i = 0; i < 5; i++) {
            BlockPos base = onCircle(c, 8.5, i * 72.0 - 54.0, 1);
            a.tree(base, 4, Blocks.CHERRY_LOG, Blocks.CHERRY_LEAVES, 2);
         }

         for (int i = 0; i < 5; i++) {
            BlockPos b = onCircle(c, 9.0, i * 72.0 - 18.0, 1);
            a.putIfFree(b, Blocks.STONE_BRICK_WALL);
            a.putIfFree(b.above(), Arena.lantern(Blocks.LANTERN, false));
         }
      }
   }

   /** 3. Wuestentempel - Sandstein, Obelisken, Palmen und eine Stufenpyramide. */
   static final class Desert extends MapTheme {
      Desert() {
         super("wueste", "Wuestentempel", "Sandstein-Tempel mit Obelisken, Palmen und einer Stufenpyramide", Items.CHISELED_SANDSTONE, ChatFormatting.GOLD);
         this.teamRing = 44;
         this.diamondRing = 30;
         this.midRadius = 12;
         this.floorA = Blocks.SMOOTH_SANDSTONE;
         this.floorB = Blocks.CUT_SANDSTONE;
         this.ring = Blocks.SANDSTONE;
         this.edge = Blocks.CUT_RED_SANDSTONE;
         this.edgeAccent = Blocks.CHISELED_RED_SANDSTONE;
         this.underTop = Blocks.SANDSTONE;
         this.rocks = new Block[]{Blocks.SANDSTONE, Blocks.RED_SANDSTONE, Blocks.TERRACOTTA, Blocks.DYED_TERRACOTTA.pick(net.minecraft.world.item.DyeColor.ORANGE)};
         this.genFloor = Blocks.SMOOTH_RED_SANDSTONE;
         this.genLight = Blocks.PEARLESCENT_FROGLIGHT;
         this.roof = Blocks.SMOOTH_SANDSTONE_SLAB;
         this.shopPost = Blocks.SANDSTONE_WALL;
         this.midA = Blocks.SMOOTH_SANDSTONE;
         this.midB = Blocks.CUT_SANDSTONE;
         this.midInner = Blocks.CHISELED_SANDSTONE;
         this.midAccent = Blocks.DYED_TERRACOTTA.pick(net.minecraft.world.item.DyeColor.BLUE);
         this.podium = Blocks.SMOOTH_RED_SANDSTONE;
      }

      @Override
      protected Block floor(int r, int f) {
         return Math.abs(r) == 4 && (f & 1) == 0 ? Blocks.DYED_TERRACOTTA.pick(net.minecraft.world.item.DyeColor.BLUE) : super.floor(r, f);
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         if (back) {
            // Obelisk
            BlockPos b = is.at(r, 1, f);
            a.put(b, Blocks.CHISELED_SANDSTONE);
            for (int u = 1; u <= 4; u++) {
               a.put(b.above(u), Blocks.CUT_SANDSTONE);
            }

            a.put(b.above(5), Blocks.GOLD_BLOCK);
            a.put(b.above(6), Blocks.END_ROD);
         } else {
            palm(a, is.at(r, 1, f));
         }
      }

      static void palm(Arena a, BlockPos base) {
         for (int u = 0; u < 5; u++) {
            a.put(base.above(u), Blocks.JUNGLE_LOG);
         }

         BlockPos top = base.above(5);
         a.put(top, Blocks.JUNGLE_LEAVES);
         for (Direction d : Direction.Plane.HORIZONTAL) {
            a.putIfFree(top.relative(d), Blocks.JUNGLE_LEAVES);
            a.putIfFree(top.relative(d, 2).below(), Blocks.JUNGLE_LEAVES);
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         // Sphinx-Waechter: Sandstein-Sockel mit Kopf
         BlockPos b = is.at(6, 1, -2);
         a.put(b, Blocks.CHISELED_SANDSTONE);
         a.put(b.above(), Blocks.CUT_SANDSTONE);
         a.put(b.above(2), skull(Blocks.CREEPER_HEAD, is.right.getOpposite()));
         a.put(is.at(6, 1, -1), stair(Blocks.SANDSTONE_STAIRS, is.forward.getOpposite(), false));
         a.put(is.at(6, 1, -3), stair(Blocks.SANDSTONE_STAIRS, is.forward, false));
         a.put(is.at(7, 1, -2), Blocks.POTTED_CACTUS.defaultBlockState());
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         palm(a, base);
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // Obelisk mit Goldspitze in der Mitte
         a.put(c.offset(0, 2, 0), Blocks.CHISELED_SANDSTONE);
         for (int u = 3; u <= 8; u++) {
            a.put(c.offset(0, u, 0), Blocks.CUT_SANDSTONE);
         }

         a.put(c.offset(0, 9, 0), Blocks.GOLD_BLOCK);
         a.put(c.offset(0, 10, 0), Blocks.END_ROD);
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         // Stufenpyramiden-Ecken (am Rand, begehbar wie Treppen) und Saeulen
         for (int i = 0; i < 8; i++) {
            BlockPos base = onCircle(c, 9.5, i * 45.0 + 22.5, 1);
            a.column(base, 5, Blocks.CHISELED_SANDSTONE, Blocks.CUT_SANDSTONE, Blocks.CHISELED_RED_SANDSTONE, Arena.lantern(Blocks.LANTERN, false));
         }

         for (int x = -10; x <= 10; x++) {
            for (int z = -10; z <= 10; z++) {
               double d = Math.sqrt(x * x + z * z);
               if (d >= 8.5 && d <= 10.5) {
                  a.putIfFree(c.offset(x, 6, z), Blocks.SMOOTH_SANDSTONE_SLAB);
               }
            }
         }
      }
   }

   /** 4. Frostgipfel - verschneite Inseln mit Tannen, Eiszacken und Schneemaennern. */
   static final class Frost extends MapTheme {
      Frost() {
         super("frost", "Frostgipfel", "Verschneite Inseln mit Tannen, Eiszacken und einem gefrorenen Brunnen", Items.SNOW_BLOCK, ChatFormatting.AQUA);
         this.teamRing = 41;
         this.diamondRing = 28;
         this.floorA = Blocks.SNOW_BLOCK;
         this.floorB = Blocks.POLISHED_DIORITE;
         this.ring = Blocks.CALCITE;
         this.edge = Blocks.STONE_BRICKS;
         this.edgeAccent = Blocks.POLISHED_DIORITE;
         this.underTop = Blocks.SNOW_BLOCK;
         this.rocks = new Block[]{Blocks.PACKED_ICE, Blocks.STONE, Blocks.BLUE_ICE, Blocks.DIORITE};
         this.genFloor = Blocks.POLISHED_DIORITE;
         this.genLight = Blocks.SEA_LANTERN;
         this.light = Blocks.SOUL_LANTERN;
         this.roof = Blocks.SPRUCE_SLAB;
         this.shopPost = Blocks.SPRUCE_LOG;
         this.midA = Blocks.SNOW_BLOCK;
         this.midB = Blocks.POLISHED_DIORITE;
         this.midInner = Blocks.CALCITE;
         this.midAccent = Blocks.DYED_TERRACOTTA.pick(net.minecraft.world.item.DyeColor.LIGHT_BLUE);
         this.podium = Blocks.POLISHED_DIORITE;
      }

      @Override
      protected Block roofCenter() {
         return Blocks.SNOW_BLOCK;
      }

      static void spruce(Arena a, BlockPos base, int height) {
         for (int u = 0; u < height; u++) {
            a.put(base.above(u), Blocks.SPRUCE_LOG);
         }

         for (int layer = 0; layer < height - 1; layer++) {
            int y = 2 + layer;
            int rr = Math.max(0, (height - 1 - layer) / 2);
            for (int x = -rr; x <= rr; x++) {
               for (int z = -rr; z <= rr; z++) {
                  if (Math.abs(x) + Math.abs(z) <= rr + 1) {
                     a.putIfFree(base.offset(x, y, z), Blocks.SPRUCE_LEAVES);
                  }
               }
            }
         }

         a.putIfFree(base.above(height), Blocks.SPRUCE_LEAVES);
         a.putIfFree(base.above(height + 1), Blocks.SNOW.defaultBlockState());
      }

      static void spike(Arena a, BlockPos base, int height) {
         for (int u = 0; u < height; u++) {
            a.put(base.above(u), u < height - 2 ? Blocks.PACKED_ICE : Blocks.BLUE_ICE);
         }
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         if (back) {
            spruce(a, is.at(r, 1, f), 6);
         } else {
            spike(a, is.at(r, 1, f), 4);
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         // Schneemann
         BlockPos b = is.at(6, 1, -2);
         a.put(b, Blocks.SNOW_BLOCK);
         a.put(b.above(), Blocks.SNOW_BLOCK);
         a.put(b.above(2), Blocks.CARVED_PUMPKIN.defaultBlockState().setValue(net.minecraft.world.level.block.CarvedPumpkinBlock.FACING, is.right.getOpposite()));
         a.put(is.at(6, 1, -1), Arena.lantern(Blocks.SOUL_LANTERN, false));
         a.put(is.at(6, 1, -3), Arena.lantern(Blocks.SOUL_LANTERN, false));
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         spike(a, base, 3 + (base.getX() & 1));
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // gefrorener Brunnen
         for (int u = 2; u <= 5; u++) {
            a.put(c.offset(0, u, 0), u == 5 ? Blocks.BLUE_ICE : Blocks.PACKED_ICE);
         }

         for (Direction d : Direction.Plane.HORIZONTAL) {
            a.put(c.relative(d).above(5), Blocks.PACKED_ICE);
            a.put(c.relative(d).above(4), Blocks.PACKED_ICE);
         }

         a.put(c.offset(0, 6, 0), Blocks.SEA_LANTERN);
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         for (int i = 0; i < 10; i++) {
            BlockPos base = onCircle(c, 9.0, i * 36.0 + 18.0, 1);
            if ((i & 1) == 0) {
               spruce(a, base, 5);
            } else {
               spike(a, base, 5 + (i % 3));
            }
         }
      }
   }

   /** 5. Hoellenfestung - Schwarzstein, Basaltsaeulen, Pilzbaeume und Seelenlaternen. */
   static final class Nether extends MapTheme {
      Nether() {
         super("nether", "Hoellenfestung", "Schwarzstein-Festungen mit Basaltsaeulen, Pilzbaeumen und Seelenfeuer", Items.NETHER_BRICKS, ChatFormatting.RED);
         this.teamRing = 43;
         this.diamondRing = 29;
         this.midRadius = 12;
         this.floorA = Blocks.POLISHED_BLACKSTONE_BRICKS;
         this.floorB = Blocks.NETHER_BRICKS;
         this.ring = Blocks.POLISHED_BLACKSTONE;
         this.edge = Blocks.RED_NETHER_BRICKS;
         this.edgeAccent = Blocks.GILDED_BLACKSTONE;
         this.underTop = Blocks.CRIMSON_NYLIUM;
         this.rocks = new Block[]{Blocks.NETHERRACK, Blocks.BLACKSTONE, Blocks.BASALT, Blocks.NETHER_WART_BLOCK};
         this.genFloor = Blocks.POLISHED_BLACKSTONE;
         this.genLight = Blocks.SHROOMLIGHT;
         this.light = Blocks.SOUL_LANTERN;
         this.roof = Blocks.NETHER_BRICK_SLAB;
         this.shopPost = Blocks.NETHER_BRICK_FENCE;
         this.midA = Blocks.POLISHED_BLACKSTONE_BRICKS;
         this.midB = Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS;
         this.midInner = Blocks.CHISELED_POLISHED_BLACKSTONE;
         this.midAccent = Blocks.GILDED_BLACKSTONE;
         this.podium = Blocks.POLISHED_BLACKSTONE;
      }

      @Override
      protected Block roofCenter() {
         return Blocks.SHROOMLIGHT;
      }

      static void fungus(Arena a, BlockPos base, boolean warped) {
         Block stem = warped ? Blocks.WARPED_STEM : Blocks.CRIMSON_STEM;
         Block cap = warped ? Blocks.WARPED_WART_BLOCK : Blocks.NETHER_WART_BLOCK;
         for (int u = 0; u < 4; u++) {
            a.put(base.above(u), stem);
         }

         for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
               a.putIfFree(base.offset(x, 4, z), cap);
               if (x != 0 && z != 0) {
                  a.putIfFree(base.offset(x, 3, z), cap);
               }
            }
         }

         a.put(base.above(5), cap);
         a.putIfFree(base.offset(1, 3, 0), Blocks.SHROOMLIGHT);
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         if (back) {
            BlockPos b = is.at(r, 1, f);
            a.column(b, 5, Blocks.POLISHED_BLACKSTONE, Blocks.POLISHED_BASALT, Blocks.CHISELED_POLISHED_BLACKSTONE, Arena.lantern(Blocks.SOUL_LANTERN, false));
         } else {
            fungus(a, is.at(r, 1, f), r > 0);
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         // Wither-Skelett-Schrein
         BlockPos b = is.at(6, 1, -2);
         a.put(b, Blocks.CHISELED_POLISHED_BLACKSTONE);
         a.put(b.above(), Blocks.SOUL_SOIL);
         a.put(b.above(2), skull(Blocks.WITHER_SKELETON_SKULL, is.right.getOpposite()));
         a.put(is.at(6, 1, -1), Blocks.POLISHED_BLACKSTONE_WALL);
         a.put(is.at(6, 2, -1), Arena.lantern(Blocks.SOUL_LANTERN, false));
         a.put(is.at(6, 1, -3), Blocks.POLISHED_BLACKSTONE_WALL);
         a.put(is.at(6, 2, -3), Arena.lantern(Blocks.SOUL_LANTERN, false));
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         a.column(base, 4, Blocks.POLISHED_BLACKSTONE, Blocks.POLISHED_BASALT, Blocks.SHROOMLIGHT, null);
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // Thron aus Gold und Schwarzstein mit Leuchtpilz
         a.put(c.offset(0, 1, 0), Blocks.GOLD_BLOCK);
         for (int u = 2; u <= 4; u++) {
            a.put(c.offset(0, u, 0), Blocks.CRYING_OBSIDIAN);
         }

         a.put(c.offset(0, 5, 0), Blocks.SHROOMLIGHT);
         a.put(c.offset(0, 6, 0), skull(Blocks.WITHER_SKELETON_SKULL, Direction.SOUTH));
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         // Festungsmauer mit Zinnen und Seelenlaternen
         for (int i = 0; i < 10; i++) {
            BlockPos base = onCircle(c, 9.5, i * 36.0 + 18.0, 1);
            a.column(base, 6, Blocks.NETHER_BRICKS, Blocks.NETHER_BRICKS, Blocks.CHISELED_NETHER_BRICKS, Arena.lantern(Blocks.SOUL_LANTERN, false));
         }

         for (int x = -11; x <= 11; x++) {
            for (int z = -11; z <= 11; z++) {
               double d = Math.sqrt(x * x + z * z);
               if (d >= 8.6 && d <= 10.4) {
                  BlockPos p = c.offset(x, 6, z);
                  a.putIfFree(p, Blocks.NETHER_BRICKS);
                  if (((x + z) & 1) == 0) {
                     a.putIfFree(p.above(), Blocks.NETHER_BRICK_FENCE);
                  }
               }
            }
         }
      }
   }

   /** 6. Dschungelruinen - bemooste Tempel, Urwaldbaeume und steinerne Totems. */
   static final class Jungle extends MapTheme {
      Jungle() {
         super("dschungel", "Dschungelruinen", "Bemooste Tempelruinen zwischen Urwaldriesen und alten Totems", Items.JUNGLE_SAPLING, ChatFormatting.GREEN);
         this.teamRing = 44;
         this.diamondRing = 31;
         this.floorA = Blocks.MOSSY_STONE_BRICKS;
         this.floorB = Blocks.STONE_BRICKS;
         this.ring = Blocks.MOSS_BLOCK;
         this.edge = Blocks.MOSSY_COBBLESTONE;
         this.edgeAccent = Blocks.CHISELED_STONE_BRICKS;
         this.underTop = Blocks.ROOTED_DIRT;
         this.rocks = new Block[]{Blocks.DIRT, Blocks.MOSSY_COBBLESTONE, Blocks.STONE, Blocks.MUD_BRICKS};
         this.genFloor = Blocks.CRACKED_STONE_BRICKS;
         this.genLight = Blocks.VERDANT_FROGLIGHT;
         this.roof = Blocks.JUNGLE_SLAB;
         this.shopPost = Blocks.JUNGLE_LOG;
         this.midA = Blocks.MOSSY_STONE_BRICKS;
         this.midB = Blocks.CRACKED_STONE_BRICKS;
         this.midInner = Blocks.CHISELED_STONE_BRICKS;
         this.midAccent = Blocks.MOSSY_COBBLESTONE;
         this.podium = Blocks.STONE_BRICKS;
      }

      @Override
      protected Block floor(int r, int f) {
         return (r * 3 + f * 7 & 7) == 1 ? Blocks.CRACKED_STONE_BRICKS : super.floor(r, f);
      }

      @Override
      protected Block roofCenter() {
         return Blocks.JUNGLE_LEAVES;
      }

      static void totem(Arena a, BlockPos b, Direction facing) {
         a.put(b, Blocks.MOSSY_STONE_BRICKS);
         a.put(b.above(), Blocks.CHISELED_STONE_BRICKS);
         a.put(b.above(2), Blocks.CARVED_PUMPKIN.defaultBlockState().setValue(net.minecraft.world.level.block.CarvedPumpkinBlock.FACING, facing));
         a.put(b.above(3), Blocks.MOSSY_STONE_BRICK_SLAB);
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         if (back) {
            a.tree(is.at(r, 1, f), 5, Blocks.JUNGLE_LOG, Blocks.JUNGLE_LEAVES, 2);
         } else {
            totem(a, is.at(r, 1, f), is.forward);
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         totem(a, is.at(6, 1, -2), is.right.getOpposite());
         a.put(is.at(6, 1, -1), Blocks.MOSSY_COBBLESTONE_WALL);
         a.put(is.at(6, 2, -1), Blocks.LANTERN);
         a.put(is.at(6, 1, -3), Blocks.POTTED_FERN.defaultBlockState());
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         a.tree(base, 3, Blocks.JUNGLE_LOG, Blocks.JUNGLE_LEAVES, 1);
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // kleiner Stufentempel mit Smaragd-Auge
         a.put(c.offset(0, 2, 0), Blocks.CHISELED_STONE_BRICKS);
         a.put(c.offset(0, 3, 0), Blocks.MOSSY_STONE_BRICKS);
         a.put(c.offset(0, 4, 0), Blocks.EMERALD_BLOCK);
         a.put(c.offset(0, 5, 0), Blocks.MOSSY_STONE_BRICK_SLAB);
         for (Direction d : Direction.Plane.HORIZONTAL) {
            a.put(c.relative(d).above(2), stair(Blocks.MOSSY_STONE_BRICK_STAIRS, d.getOpposite(), false));
         }
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         for (int i = 0; i < 6; i++) {
            BlockPos base = onCircle(c, 9.0, i * 60.0 + 30.0, 1);
            if ((i & 1) == 0) {
               a.tree(base, 6, Blocks.JUNGLE_LOG, Blocks.JUNGLE_LEAVES, 3);
            } else {
               // eingestuerzte Saeule
               a.column(base, 3 + i % 3, Blocks.MOSSY_STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS, null);
            }
         }
      }
   }

   /** 7. Ozeanpalast - Prismarin, Meereslaternen und Kuppeln aus Meerglas. */
   static final class Ocean extends MapTheme {
      Ocean() {
         super("ozean", "Ozeanpalast", "Prismarin-Palast mit Meereslaternen, Korallen und Glaskuppeln", Items.PRISMARINE_SHARD, ChatFormatting.DARK_AQUA);
         this.teamRing = 42;
         this.diamondRing = 28;
         this.floorA = Blocks.PRISMARINE_BRICKS;
         this.floorB = Blocks.DARK_PRISMARINE;
         this.ring = Blocks.PRISMARINE;
         this.edge = Blocks.DARK_PRISMARINE;
         this.edgeAccent = Blocks.SEA_LANTERN;
         this.underTop = Blocks.PRISMARINE;
         this.rocks = new Block[]{Blocks.PRISMARINE, Blocks.DARK_PRISMARINE, Blocks.DEAD_TUBE_CORAL_BLOCK, Blocks.DEAD_BRAIN_CORAL_BLOCK, Blocks.SANDSTONE};
         this.genFloor = Blocks.PRISMARINE;
         this.genLight = Blocks.SEA_LANTERN;
         this.light = Blocks.SEA_LANTERN;
         this.roof = Blocks.PRISMARINE_BRICK_SLAB;
         this.shopPost = Blocks.PRISMARINE_WALL;
         this.midA = Blocks.PRISMARINE_BRICKS;
         this.midB = Blocks.PRISMARINE;
         this.midInner = Blocks.DARK_PRISMARINE;
         this.midAccent = Blocks.SEA_LANTERN;
         this.podium = Blocks.PRISMARINE_BRICKS;
      }

      @Override
      protected Block roofCenter() {
         return Blocks.SEA_LANTERN;
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         BlockPos b = is.at(r, 1, f);
         a.column(b, back ? 5 : 4, Blocks.DARK_PRISMARINE, Blocks.PRISMARINE_BRICKS, Blocks.SEA_LANTERN, null);
         if (back) {
            a.put(b.above(5), banner(is.team, is.forward));
         } else {
            a.put(b.above(4), Blocks.STAINED_GLASS.pick(net.minecraft.world.item.DyeColor.LIGHT_BLUE));
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         // Conduit auf einem Sockel
         BlockPos b = is.at(6, 1, -2);
         a.put(b, Blocks.DARK_PRISMARINE);
         a.put(b.above(), Blocks.PRISMARINE_WALL);
         a.put(b.above(2), Blocks.CONDUIT);
         a.put(is.at(6, 1, -1), Blocks.DEAD_FIRE_CORAL_BLOCK);
         a.put(is.at(6, 1, -3), Blocks.DEAD_HORN_CORAL_BLOCK);
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         a.column(base, 3, Blocks.DARK_PRISMARINE, Blocks.PRISMARINE_BRICKS, Blocks.SEA_LANTERN, null);
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         // Glaskugel mit Leuchtkern
         for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
               for (int u = 2; u <= 4; u++) {
                  if (Math.abs(x) + Math.abs(z) + Math.abs(u - 3) <= 2) {
                     a.put(c.offset(x, u, z), Blocks.STAINED_GLASS.pick(net.minecraft.world.item.DyeColor.LIGHT_BLUE));
                  }
               }
            }
         }

         a.put(c.offset(0, 3, 0), Blocks.SEA_LANTERN);
         a.put(c.offset(0, 5, 0), Blocks.CONDUIT);
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         // Saeulen mit einer Glaskuppel darueber
         for (int i = 0; i < 10; i++) {
            BlockPos base = onCircle(c, 8.5, i * 36.0 + 18.0, 1);
            a.column(base, 7, Blocks.DARK_PRISMARINE, Blocks.PRISMARINE_BRICKS, Blocks.SEA_LANTERN, null);
         }

         for (int x = -10; x <= 10; x++) {
            for (int z = -10; z <= 10; z++) {
               double d = Math.sqrt(x * x + z * z);
               if (d <= 9.6) {
                  int y = 8 + (int)Math.round(Math.sqrt(Math.max(0.0, 9.6 * 9.6 - d * d)) / 3.2);
                  a.putIfFree(c.offset(x, y, z), d > 7.5 ? Blocks.PRISMARINE_BRICKS : Blocks.STAINED_GLASS.pick(net.minecraft.world.item.DyeColor.LIGHT_BLUE));
               }
            }
         }
      }
   }

   /** 8. Endstadt - Purpur-Tuerme, Endstab-Lichter und Obsidian-Saeulen. */
   static final class EndCity extends MapTheme {
      EndCity() {
         super("endstadt", "Endstadt", "Purpur-Tuerme ueber dem Nichts mit Obsidian-Saeulen und Drachenkopf", Items.PURPUR_BLOCK, ChatFormatting.DARK_PURPLE);
         this.teamRing = 45;
         this.diamondRing = 30;
         this.midRadius = 12;
         this.floorA = Blocks.PURPUR_BLOCK;
         this.floorB = Blocks.END_STONE_BRICKS;
         this.ring = Blocks.PURPUR_PILLAR;
         this.edge = Blocks.END_STONE_BRICKS;
         this.edgeAccent = Blocks.PURPUR_PILLAR;
         this.underTop = Blocks.END_STONE;
         this.rocks = new Block[]{Blocks.END_STONE, Blocks.END_STONE, Blocks.OBSIDIAN, Blocks.PURPUR_BLOCK};
         this.genFloor = Blocks.END_STONE_BRICKS;
         this.genLight = Blocks.PEARLESCENT_FROGLIGHT;
         this.light = Blocks.END_ROD;
         this.roof = Blocks.PURPUR_SLAB;
         this.shopPost = Blocks.PURPUR_PILLAR;
         this.midA = Blocks.PURPUR_BLOCK;
         this.midB = Blocks.END_STONE_BRICKS;
         this.midInner = Blocks.PURPUR_PILLAR;
         this.midAccent = Blocks.STAINED_GLASS.pick(net.minecraft.world.item.DyeColor.MAGENTA);
         this.podium = Blocks.END_STONE_BRICKS;
      }

      @Override
      protected Block roofCenter() {
         return Blocks.STAINED_GLASS.pick(net.minecraft.world.item.DyeColor.MAGENTA);
      }

      @Override
      protected void corner(Arena a, Arena.Island is, int r, int f, boolean back) {
         BlockPos b = is.at(r, 1, f);
         int h = back ? 6 : 4;
         a.column(b, h, Blocks.PURPUR_BLOCK, Blocks.PURPUR_PILLAR, Blocks.PURPUR_BLOCK, null);
         a.put(b.above(h), Blocks.END_ROD);
         if (back) {
            a.put(b.above(h - 2).relative(is.forward), Blocks.STAINED_GLASS.pick(net.minecraft.world.item.DyeColor.MAGENTA));
         }
      }

      @Override
      protected void feature(Arena a, Arena.Island is) {
         BlockPos b = is.at(6, 1, -2);
         a.put(b, Blocks.PURPUR_BLOCK);
         a.put(b.above(), Blocks.PURPUR_PILLAR);
         a.put(b.above(2), skull(Blocks.DRAGON_HEAD, is.right.getOpposite()));
         a.put(is.at(6, 1, -1), Blocks.END_ROD);
         a.put(is.at(6, 1, -3), Blocks.END_ROD);
      }

      @Override
      protected void diamondDecor(Arena a, BlockPos base, Direction out) {
         a.column(base, 4, Blocks.OBSIDIAN, Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN, Blocks.END_ROD.defaultBlockState());
      }

      @Override
      protected void midCenter(Arena a, BlockPos c) {
         a.put(c.offset(0, 1, 0), Blocks.CRYING_OBSIDIAN);
         for (int u = 2; u <= 6; u++) {
            a.put(c.offset(0, u, 0), Blocks.END_ROD);
         }

         a.put(c.offset(0, 7, 0), skull(Blocks.DRAGON_HEAD, Direction.SOUTH));
      }

      @Override
      protected void midRing(Arena a, BlockPos c) {
         // Obsidian-Saeulen wie auf der End-Insel, unterschiedlich hoch
         for (int i = 0; i < 10; i++) {
            BlockPos base = onCircle(c, 9.5, i * 36.0 + 18.0, 1);
            int h = 6 + (i * 7 % 5);
            for (int u = 0; u < h; u++) {
               a.put(base.above(u), u % 4 == 3 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
            }

            a.put(base.above(h), Blocks.END_ROD);
         }
      }
   }
}
