package de.glowcube.bedwars;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.IntConsumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Das Gluecksrad vor jeder Runde: in der mittleren Reihe einer Kiste laufen alle Karten durch, werden
 * langsamer und bleiben unter dem Zeiger stehen. Die Karte wird zufaellig gewaehlt - aber die zuletzt
 * gespielten kommen deutlich seltener dran (die letzte gar nicht), damit es keine Doppel gibt.
 */
public final class MapWheel {
   private static final Random RND = new Random();
   private static final int STEPS = 34;

   private static final List<ServerPlayer> viewers = new ArrayList<>();
   private static final List<GuiMenu> menus = new ArrayList<>();
   private static int[] strip;
   private static int step;
   private static int nextAt;
   private static int doneAt = -1;
   private static int chosen;
   private static IntConsumer onDone;
   private static int clock;

   private MapWheel() {
   }

   /**
    * Waehlt die Karte: die letzte Karte nie, die vorletzte selten, ... alle anderen gleich oft.
    * Bei 8 Karten heisst das: dieselbe Karte zweimal hintereinander gibt es nicht.
    */
   public static int pick() {
      int n = MapTheme.ALL.size();
      double[] w = new double[n];
      double[] recentWeight = {0.0, 0.15, 0.4, 0.7};
      double sum = 0.0;

      for (int i = 0; i < n; i++) {
         int pos = Config.recentMaps.indexOf(i);
         w[i] = pos >= 0 && pos < recentWeight.length ? recentWeight[pos] : 1.0;
         sum += w[i];
      }

      if (sum <= 0.0) {
         return RND.nextInt(n);
      }

      double x = RND.nextDouble() * sum;
      for (int i = 0; i < n; i++) {
         x -= w[i];
         if (x < 0.0) {
            return i;
         }
      }

      return n - 1;
   }

   public static void remember(int map) {
      Config.recentMaps.remove(Integer.valueOf(map));
      Config.recentMaps.add(0, map);
      while (Config.recentMaps.size() > 4) {
         Config.recentMaps.remove(Config.recentMaps.size() - 1);
      }

      Config.save();
   }

   public static void start(List<ServerPlayer> players, IntConsumer done) {
      int n = MapTheme.ALL.size();
      chosen = pick();
      onDone = done;
      strip = new int[STEPS + 9];
      int start = RND.nextInt(n);
      for (int i = 0; i < strip.length; i++) {
         strip[i] = (start + i) % n;
      }

      // so drehen, dass am Ende die gewaehlte Karte unter dem Zeiger (Mitte) steht
      int shift = Math.floorMod(chosen - strip[STEPS + 4], n);
      for (int i = 0; i < strip.length; i++) {
         strip[i] = (strip[i] + shift) % n;
      }

      step = 0;
      clock = 0;
      nextAt = 10;
      doneAt = -1;
      viewers.clear();
      menus.clear();

      for (ServerPlayer p : players) {
         viewers.add(p);
         SimpleContainer box = GuiMenu.box(3);
         render(box, false);
         GuiMenu m = GuiMenu.open(p, Component.literal("Gluecksrad - welche Karte?").withStyle(ChatFormatting.DARK_PURPLE), 3, box, new GuiMenu.Handler() {
            @Override
            public void click(GuiMenu menu, ServerPlayer pl, int slot, ContainerInput input, int button) {
            }
         });
         if (m != null) {
            menus.add(m);
         }
      }
   }

   private static ItemStack icon(int map, boolean winner) {
      MapTheme t = MapTheme.ALL.get(map);
      ItemStack s = BwItems.make(t.icon, 1, null, t.name, t.color, t.description);
      if (winner) {
         s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
      }

      return s;
   }

   private static void render(SimpleContainer box, boolean finished) {
      ItemStack black = BwItems.make(Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.BLACK), 1, null, " ", ChatFormatting.GRAY);
      ItemStack frame = BwItems.make(finished ? Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.LIME) : Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.YELLOW), 1, null, " ", ChatFormatting.GRAY);
      for (int i = 0; i < 27; i++) {
         box.setItem(i, (i == 3 || i == 5 || i == 21 || i == 23) ? frame.copy() : black.copy());
      }

      box.setItem(4, BwItems.make(Items.HOPPER, 1, null, "▼", ChatFormatting.GOLD));
      box.setItem(22, BwItems.make(Items.ARROW, 1, null, "▲", ChatFormatting.GOLD));

      for (int k = 0; k < 9; k++) {
         int map = strip[Math.min(strip.length - 1, step + k)];
         box.setItem(9 + k, icon(map, finished && k == 4));
      }
   }

   private static int delay(int s) {
      // schnell anfangen, immer langsamer werden
      return 1 + s * s / 150;
   }

   static void tick() {
      clock++;
      if (doneAt >= 0) {
         if (clock >= doneAt) {
            doneAt = -1;
            for (ServerPlayer p : viewers) {
               if (p.containerMenu instanceof GuiMenu gm && menus.contains(gm)) {
                  p.closeContainer();
               }
            }

            viewers.clear();
            menus.clear();
            IntConsumer d = onDone;
            onDone = null;
            if (d != null) {
               d.accept(chosen);
            }
         }

         return;
      }

      if (clock < nextAt) {
         return;
      }

      if (step < STEPS) {
         step++;
         nextAt = clock + delay(step);
         for (GuiMenu m : menus) {
            render(m.box, false);
         }

         float pitch = 0.6F + 1.2F * step / STEPS;
         for (ServerPlayer p : viewers) {
            p.level().playSound(null, p.blockPosition(), SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 0.8F, pitch);
         }
      }

      if (step >= STEPS) {
         remember(chosen);
         MapTheme t = MapTheme.ALL.get(chosen);
         for (GuiMenu m : menus) {
            render(m.box, true);
         }

         for (ServerPlayer p : viewers) {
            p.level().playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.MASTER, 1.0F, 1.0F);
            Game.title(p, Component.literal(t.name.toUpperCase()).withStyle(t.color, ChatFormatting.BOLD),
               Component.literal(t.description).withStyle(ChatFormatting.GRAY));
            p.sendSystemMessage(Component.literal("Gluecksrad: ").withStyle(ChatFormatting.LIGHT_PURPLE)
               .append(Component.literal(t.name).withStyle(t.color, ChatFormatting.BOLD))
               .append(Component.literal(" - " + t.description).withStyle(ChatFormatting.GRAY)));
         }

         doneAt = clock + 50;
      }
   }

   /** Fuer den Selbsttest: 200 Runden auslosen - nie zweimal dieselbe Karte hintereinander, alle kommen vor. */
   public static List<String> selfTest() {
      List<String> fails = new ArrayList<>();
      List<Integer> saved = new ArrayList<>(Config.recentMaps);
      int[] seen = new int[MapTheme.ALL.size()];
      int last = -1;
      for (int i = 0; i < 200; i++) {
         int m = pick();
         if (m == last) {
            fails.add("Doppel bei Runde " + i);
            break;
         }

         seen[m]++;
         last = m;
         Config.recentMaps.remove(Integer.valueOf(m));
         Config.recentMaps.add(0, m);
         while (Config.recentMaps.size() > 4) {
            Config.recentMaps.remove(Config.recentMaps.size() - 1);
         }
      }

      for (int i = 0; i < seen.length; i++) {
         if (seen[i] < 10) {
            fails.add("Karte " + MapTheme.ALL.get(i).name + " zu selten (" + seen[i] + ")");
         }
      }

      Config.recentMaps.clear();
      Config.recentMaps.addAll(saved);
      return fails;
   }
}
