package de.glowcube.bedwars;

import java.nio.file.Path;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;

/**
 * Alles, was sich zwischen der Fabric-Mod und dem Paper-Plugin unterscheidet.
 * Der Spielcode selbst (Karte, Bots, Shop, Lobby ...) ist fuer beide derselbe.
 */
public interface Platform {
   /** Ordner fuer Einstellungen. */
   Path configDir();

   /** Paper-Server (SMP): nur Multiplayer, eigene Arena-Welt. */
   boolean isServerPlugin();

   /** Welt, in der die Arena gebaut wird. */
   ServerLevel arenaLevel(MinecraftServer server, ServerPlayer host);

   /** Mitte der Arena (y wird ignoriert). */
   BlockPos arenaCenter(ServerLevel level, ServerPlayer host);

   /** Spieler (auch in eine andere Welt) teleportieren. */
   void teleport(ServerPlayer p, ServerLevel level, double x, double y, double z, float yaw, float pitch);

   Difficulty difficulty(ServerLevel level);

   void setDifficulty(ServerLevel level, Difficulty d);

   /** Paper friert weit entfernte Wesen ein (Activation Range) - Bots, Golems usw. sollen immer laufen. */
   default void keepTicking(Entity e) {
   }

   /** Ziel eines Mobs setzen (Paper will einen Grund wissen). */
   default void setTarget(net.minecraft.world.entity.Mob mob, net.minecraft.world.entity.LivingEntity target) {
      mob.setTarget(target);
   }

   /** Wesen entfernen (Paper will einen Grund wissen). */
   default void remove(Entity e) {
      e.discard();
   }

   /** Ist dieser Spieler Operator / darf er Admin-Befehle nutzen? */
   boolean isAdmin(ServerPlayer p);

   /** Spieler, der gerade nicht in der Runde ist, darf nichts in der Arena-Welt (Paper). */
   default boolean isArenaWorld(ServerLevel level) {
      return false;
   }

   /** Fallback-Ort, falls keine Sicherung da ist (Paper: Spawn der Hauptwelt). */
   default void sendHome(ServerPlayer p) {
   }

   void log(String msg);

   final class Holder {
      private static Platform instance;

      private Holder() {
      }
   }

   static Platform get() {
      return Holder.instance;
   }

   static void set(Platform p) {
      Holder.instance = p;
   }
}
