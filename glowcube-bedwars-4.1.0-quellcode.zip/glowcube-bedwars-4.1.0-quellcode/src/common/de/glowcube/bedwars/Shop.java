package de.glowcube.bedwars;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ItemLike;

/**
 * Der Shop wie auf Hypixel: oben Reiter (Schnellkauf, Bloecke, Nahkampf, Ruestung, Werkzeuge, Fernkampf,
 * Traenke, Extras, Team-Upgrades), darunter die Angebote. Bezahlt wird mit Eisen, Gold, Diamanten
 * (Team-Upgrades) und Smaragden aus dem eigenen Inventar.
 */
public final class Shop {
   private static final int ROWS = 6;
   private static final int SIZE = ROWS * 9;
   public static final Item[] PICKAXES = {Items.WOODEN_PICKAXE, Items.IRON_PICKAXE, Items.GOLDEN_PICKAXE, Items.DIAMOND_PICKAXE};
   public static final Item[] AXES = {Items.WOODEN_AXE, Items.STONE_AXE, Items.IRON_AXE, Items.DIAMOND_AXE};
   private static final Item[] SWORDS = {Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD, Items.DIAMOND_SWORD};

   public enum Cat {
      QUICK("Schnellkauf", Items.NETHER_STAR),
      BLOCKS("Bloecke", Items.TERRACOTTA),
      MELEE("Nahkampf", Items.GOLDEN_SWORD),
      ARMOR("Ruestung", Items.CHAINMAIL_BOOTS),
      TOOLS("Werkzeuge", Items.STONE_PICKAXE),
      RANGED("Fernkampf", Items.BOW),
      POTIONS("Traenke", Items.BREWING_STAND),
      UTILITY("Extras", Items.TNT),
      UPGRADES("Team-Upgrades & Fallen", Items.DIAMOND);

      final String label;
      final Item icon;

      Cat(String label, Item icon) {
         this.label = label;
         this.icon = icon;
      }
   }

   /** Ein Angebot. Preis und Bild koennen vom Team abhaengen (Fallen werden teurer). */
   private record Offer(String key, Cat cat, Item currency, ToIntFunction<Game.TeamState> price, java.util.function.Function<Game.TeamState, ItemStack> icon,
      String name, String desc, Give give) {
   }

   private interface Give {
      boolean give(ServerPlayer p, Game.TeamState t);
   }

   private static final Map<String, Offer> OFFERS = new LinkedHashMap<>();
   private static final List<String> QUICK = List.of(
      "wool", "stone_sword", "chain_armor", "pickaxe1", "axe1", "gapple", "fireball",
      "terracotta", "iron_sword", "iron_armor", "shears", "arrows", "bow", "tnt",
      "endstone", "kb_stick", "diamond_armor", "speed", "invis", "popup_tower", "bridge_egg",
      "planks", "ladder", "glass", "pearl", "water", "golem", "milk"
   );
   private static final Map<UUID, Cat> open = new HashMap<>();

   private Shop() {
   }

   // ====================================================================== Oeffnen und Aufbau

   public static void open(ServerPlayer p) {
      open(p, open.getOrDefault(p.getUUID(), Cat.QUICK));
   }

   private static void open(ServerPlayer p, Cat cat) {
      Game.TeamState t = Game.teamOfPlayer(p);
      if (!Game.running() || t == null) {
         p.sendSystemMessage(Component.literal("Den Shop gibt es nur, waehrend du Bedwars spielst.").withStyle(ChatFormatting.RED));
         return;
      }

      open.put(p.getUUID(), cat);
      SimpleContainer box = GuiMenu.box(ROWS);
      fill(box, t, cat);
      GuiMenu.open(p, Component.literal("Shop - " + cat.label).withStyle(ChatFormatting.DARK_GRAY), ROWS, box, new Handler(cat));
   }

   private static void refresh(GuiMenu menu, Game.TeamState t, Cat cat) {
      fill(menu.box, t, cat);
   }

   private static void fill(SimpleContainer box, Game.TeamState t, Cat cat) {
      ItemStack filler = BwItems.make(Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.GRAY), 1, null, " ", ChatFormatting.GRAY);

      for (int i = 0; i < SIZE; i++) {
         box.setItem(i, filler.copy());
      }

      for (Cat c : Cat.values()) {
         ItemStack tab = BwItems.make(c.icon, 1, null, c.label, c == cat ? ChatFormatting.GREEN : ChatFormatting.YELLOW,
            c == cat ? "Ausgewaehlt" : "Klicken zum Anzeigen");
         if (c == cat) {
            tab.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
         }

         box.setItem(c.ordinal(), tab);
         box.setItem(9 + c.ordinal(), BwItems.make(c == cat ? Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.LIME) : Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.BLACK), 1, null, " ", ChatFormatting.GRAY));
      }

      List<Offer> list = offers(cat);
      for (int i = 0; i < list.size() && i < 28; i++) {
         box.setItem(contentSlot(i), display(list.get(i), t));
      }

      if (cat == Cat.UPGRADES) {
         StringBuilder q = new StringBuilder();
         for (BwItems.Trap trap : t.traps) {
            q.append(q.length() == 0 ? "" : ", ").append(trap.label);
         }

         box.setItem(49, BwItems.make(Items.LEATHER, 1, null, "Fallen-Warteschlange", ChatFormatting.YELLOW,
            t.traps.isEmpty() ? "Keine Fallen gekauft" : q.toString(), "Hoechstens 3 Fallen, jede weitere kostet mehr"));
      }
   }

   private static int contentSlot(int i) {
      return (2 + i / 7) * 9 + 1 + i % 7;
   }

   private static int contentIndex(int slot) {
      int row = slot / 9;
      int col = slot % 9;
      return row >= 2 && col >= 1 && col <= 7 ? (row - 2) * 7 + col - 1 : -1;
   }

   private static List<Offer> offers(Cat cat) {
      List<Offer> list = new ArrayList<>();
      if (cat == Cat.QUICK) {
         for (String k : QUICK) {
            if (OFFERS.containsKey(k)) {
               list.add(OFFERS.get(k));
            }
         }
      } else {
         for (Offer o : OFFERS.values()) {
            if (o.cat == cat) {
               list.add(o);
            }
         }
      }

      return list;
   }

   private static ItemStack display(Offer o, Game.TeamState t) {
      ItemStack icon = o.icon.apply(t).copy();
      int price = o.price.applyAsInt(t);
      icon.set(DataComponents.CUSTOM_NAME, Component.literal(o.name).withStyle(s -> s.withColor(ChatFormatting.WHITE).withItalic(false).withBold(true)));
      List<Component> lore = new ArrayList<>();
      lore.add(Component.literal("Preis: ").withStyle(s -> s.withColor(ChatFormatting.GRAY).withItalic(false))
         .append(Component.literal(price < 0 ? "-" : price + " " + currencyName(o.currency)).withStyle(s -> s.withColor(currencyColor(o.currency)).withItalic(false))));
      if (o.desc != null) {
         for (String line : o.desc.split("\n")) {
            lore.add(Component.literal(line).withStyle(s -> s.withColor(ChatFormatting.DARK_AQUA).withItalic(false)));
         }
      }

      lore.add(Component.literal(price < 0 ? "Nicht mehr verfuegbar" : "Klicken zum Kaufen").withStyle(s -> s.withColor(ChatFormatting.YELLOW).withItalic(false)));
      icon.set(DataComponents.LORE, new ItemLore(lore));
      return icon;
   }

   // ====================================================================== Kaufen

   private static final class Handler implements GuiMenu.Handler {
      private Cat cat;

      Handler(Cat cat) {
         this.cat = cat;
      }

      @Override
      public boolean ownInventory() {
         return true;
      }

      @Override
      public void click(GuiMenu menu, ServerPlayer p, int slot, ContainerInput input, int button) {
         Game.TeamState t = Game.teamOfPlayer(p);
         if (t == null || slot < 0 || input != ContainerInput.PICKUP && input != ContainerInput.QUICK_MOVE) {
            return;
         }

         if (slot < Cat.values().length) {
            this.cat = Cat.values()[slot];
            open.put(p.getUUID(), this.cat);
            refresh(menu, t, this.cat);
            p.level().playSound(null, p.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.MASTER, 0.4F, 1.2F);
            return;
         }

         int idx = contentIndex(slot);
         List<Offer> list = offers(this.cat);
         if (idx >= 0 && idx < list.size()) {
            buy(p, t, list.get(idx));
            refresh(menu, t, this.cat);
         }
      }
   }

   /** Fuer den Selbsttest: ein Angebot per Schluessel kaufen. */
   public static boolean debugBuy(ServerPlayer p, String key) {
      Game.TeamState t = Game.teamOfPlayer(p);
      Offer o = OFFERS.get(key);
      if (t == null || o == null) {
         return false;
      }

      int before = count(p.getInventory(), o.currency);
      buy(p, t, o);
      return count(p.getInventory(), o.currency) < before;
   }

   private static void buy(ServerPlayer p, Game.TeamState t, Offer o) {
      Inventory inv = p.getInventory();
      int price = o.price.applyAsInt(t);
      if (price < 0) {
         fail(p, "Das gibt es nicht mehr zu kaufen.");
         return;
      }

      if (count(inv, o.currency) < price) {
         fail(p, "Dir fehlen " + (price - count(inv, o.currency)) + " " + currencyName(o.currency) + ".");
         return;
      }

      if (o.give.give(p, t)) {
         take(inv, o.currency, price);
         p.sendSystemMessage(Component.literal("Gekauft: ").withStyle(ChatFormatting.GREEN).append(Component.literal(o.name).withStyle(ChatFormatting.GOLD)));
         p.level().playSound(null, p.blockPosition(), SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 0.6F, 1.6F);
         p.inventoryMenu.broadcastChanges();
      } else {
         p.level().playSound(null, p.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.MASTER, 0.6F, 1.0F);
      }
   }

   private static void fail(ServerPlayer p, String why) {
      p.sendSystemMessage(Component.literal(why).withStyle(ChatFormatting.RED));
      p.level().playSound(null, p.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.MASTER, 0.6F, 1.0F);
   }

   private static String currencyName(Item item) {
      if (item == Items.IRON_INGOT) {
         return "Eisen";
      } else if (item == Items.GOLD_INGOT) {
         return "Gold";
      } else {
         return item == Items.EMERALD ? "Smaragde" : "Diamanten";
      }
   }

   private static ChatFormatting currencyColor(Item item) {
      if (item == Items.IRON_INGOT) {
         return ChatFormatting.WHITE;
      } else if (item == Items.GOLD_INGOT) {
         return ChatFormatting.GOLD;
      } else {
         return item == Items.EMERALD ? ChatFormatting.DARK_GREEN : ChatFormatting.AQUA;
      }
   }

   public static int count(Inventory inv, Item item) {
      int n = 0;

      for (int i = 0; i < inv.getContainerSize(); i++) {
         ItemStack s = inv.getItem(i);
         if (s.is(item)) {
            n += s.getCount();
         }
      }

      return n;
   }

   private static void take(Inventory inv, Item item, int amount) {
      for (int i = 0; i < inv.getContainerSize() && amount > 0; i++) {
         ItemStack s = inv.getItem(i);
         if (s.is(item)) {
            int n = Math.min(amount, s.getCount());
            s.shrink(n);
            if (s.isEmpty()) {
               inv.setItem(i, ItemStack.EMPTY);
            }

            amount -= n;
         }
      }
   }

   /** Hoechste Stufe (1..n) eines Werkzeugs im Inventar, 0 = keins. */
   public static int toolTier(Inventory inv, Item[] tiers) {
      int tier = 0;

      for (int i = 0; i < inv.getContainerSize(); i++) {
         for (int k = 0; k < tiers.length; k++) {
            if (inv.getItem(i).is(tiers[k])) {
               tier = Math.max(tier, k + 1);
            }
         }
      }

      return tier;
   }

   private static void removeAll(Inventory inv, Item[] items) {
      for (int i = 0; i < inv.getContainerSize(); i++) {
         for (Item it : items) {
            if (inv.getItem(i).is(it)) {
               inv.setItem(i, ItemStack.EMPTY);
            }
         }
      }
   }

   private static void giveStack(ServerPlayer p, ItemStack s) {
      if (!p.getInventory().add(s)) {
         p.spawnAtLocation((net.minecraft.server.level.ServerLevel)p.level(), s);
      }
   }

   // ====================================================================== Kauf-Regeln

   private static boolean sword(ServerPlayer p, int tier) {
      if (Game.playerSwordTier(p) >= tier) {
         p.sendSystemMessage(Component.literal("Du hast schon ein gleich gutes oder besseres Schwert.").withStyle(ChatFormatting.RED));
         return false;
      }

      // altes Schwert ersetzen (am selben Platz, wenn moeglich)
      Inventory inv = p.getInventory();
      int at = -1;
      for (int i = 0; i < inv.getContainerSize(); i++) {
         for (int k = 0; k < tier; k++) {
            if (inv.getItem(i).is(SWORDS[k])) {
               if (at < 0) {
                  at = i;
               }

               inv.setItem(i, ItemStack.EMPTY);
            }
         }
      }

      ItemStack s = new ItemStack(SWORDS[tier]);
      Game.TeamState t = Game.teamOfPlayer(p);
      if (t != null && t.sharpness) {
         Game.enchant(s, Enchantments.SHARPNESS, 1);
      }

      if (at >= 0) {
         inv.setItem(at, s);
      } else {
         giveStack(p, s);
      }

      return true;
   }

   private static boolean armor(ServerPlayer p, Game.TeamState t, int tier) {
      if (Game.armorTier(p) >= tier) {
         p.sendSystemMessage(Component.literal("Du hast schon diese oder eine bessere Ruestung.").withStyle(ChatFormatting.RED));
         return false;
      }

      Game.setArmorTier(p, tier);
      Game.equipPlayerArmor(p, t);
      return true;
   }

   private static boolean tool(ServerPlayer p, Item[] tiers, int tier, String what) {
      Inventory inv = p.getInventory();
      int have = toolTier(inv, tiers);
      if (have >= tier) {
         p.sendSystemMessage(Component.literal("Du hast schon diese oder eine bessere " + what + ".").withStyle(ChatFormatting.RED));
         return false;
      } else if (have < tier - 1) {
         p.sendSystemMessage(Component.literal("Kauf zuerst die Stufe davor.").withStyle(ChatFormatting.RED));
         return false;
      }

      removeAll(inv, tiers);
      ItemStack s = new ItemStack(tiers[tier - 1]);
      Game.enchant(s, Enchantments.EFFICIENCY, tier >= 3 ? tier - 1 : 0);
      giveStack(p, s);
      return true;
   }

   private static Give stack(java.util.function.Function<Game.TeamState, ItemStack> make) {
      return (p, t) -> {
         giveStack(p, make.apply(t));
         return true;
      };
   }

   private static ItemStack enchanted(Item item, Object... enchLevels) {
      ItemStack s = new ItemStack(item);
      for (int i = 0; i + 1 < enchLevels.length; i += 2) {
         @SuppressWarnings("unchecked")
         ResourceKey<Enchantment> key = (ResourceKey<Enchantment>)enchLevels[i];
         Game.enchant(s, key, (Integer)enchLevels[i + 1]);
      }

      return s;
   }

   private static ItemStack potion(String name, int color, MobEffectInstance effect) {
      ItemStack s = BwItems.make(Items.POTION, 1, null, name, ChatFormatting.AQUA);
      s.set(DataComponents.POTION_CONTENTS, new PotionContents(Optional.empty(), Optional.of(color), List.of(effect), Optional.empty()));
      return s;
   }

   private static Give upgrade(String name, Predicate<Game.TeamState> can, Consumer<Game.TeamState> apply, String why) {
      return (p, t) -> {
         if (!can.test(t)) {
            p.sendSystemMessage(Component.literal(why).withStyle(ChatFormatting.RED));
            return false;
         }

         apply.accept(t);
         Game.upgradeBought(t, name, null, p);
         return true;
      };
   }

   private static int trapPrice(Game.TeamState t) {
      return t.traps.size() >= 3 ? -1 : 1 << t.traps.size();
   }

   private static Give trap(BwItems.Trap trap) {
      return (p, t) -> {
         if (t.traps.size() >= 3) {
            p.sendSystemMessage(Component.literal("Ihr habt schon 3 Fallen in der Warteschlange.").withStyle(ChatFormatting.RED));
            return false;
         }

         t.traps.add(trap);
         Game.upgradeBought(t, "Falle: " + trap.label, null, p);
         return true;
      };
   }

   private static void add(String key, Cat cat, Item currency, int price, ItemStack icon, String name, String desc, Give give) {
      OFFERS.put(key, new Offer(key, cat, currency, t -> price, t -> icon, name, desc, give));
   }

   private static void addDyn(String key, Cat cat, Item currency, ToIntFunction<Game.TeamState> price, java.util.function.Function<Game.TeamState, ItemStack> icon,
      String name, String desc, Give give) {
      OFFERS.put(key, new Offer(key, cat, currency, price, icon, name, desc, give));
   }

   private static ItemStack it(ItemLike item, int n) {
      return new ItemStack(item, n);
   }

   static {
      Item IRON = Items.IRON_INGOT;
      Item GOLD = Items.GOLD_INGOT;
      Item DIA = Items.DIAMOND;
      Item EM = Items.EMERALD;

      // ---------------------------------------------------------------- Bloecke
      addDyn("wool", Cat.BLOCKS, IRON, t -> 4, t -> it(t.team.wool, 16), "Wolle x16", "Zum Bruecken bauen", stack(t -> it(t.team.wool, 16)));
      addDyn("terracotta", Cat.BLOCKS, IRON, t -> 12, t -> it(t.team.terracotta, 16), "Terrakotta x16", "Fester als Wolle", stack(t -> it(t.team.terracotta, 16)));
      addDyn("glass", Cat.BLOCKS, IRON, t -> 12, t -> it(t.team.glass, 4), "Explosionsfestes Glas x4", "Haelt Feuerbaellen und TNT stand", stack(t -> it(t.team.glass, 4)));
      add("endstone", Cat.BLOCKS, IRON, 24, it(Items.END_STONE, 12), "Endstein x12", "Gut fuer die Bett-Verteidigung", stack(t -> it(Items.END_STONE, 12)));
      add("ladder", Cat.BLOCKS, IRON, 4, it(Items.LADDER, 16), "Leiter x16", "Hoch hinaus", stack(t -> it(Items.LADDER, 16)));
      add("planks", Cat.BLOCKS, GOLD, 4, it(Items.OAK_PLANKS, 16), "Holz x16", "Schnell zu setzen, robust gegen Scheren", stack(t -> it(Items.OAK_PLANKS, 16)));
      add("obsidian", Cat.BLOCKS, EM, 4, it(Items.OBSIDIAN, 4), "Obsidian x4", "Der haerteste Block - schuetzt dein Bett", stack(t -> it(Items.OBSIDIAN, 4)));

      // ---------------------------------------------------------------- Nahkampf
      add("stone_sword", Cat.MELEE, IRON, 10, it(Items.STONE_SWORD, 1), "Steinschwert", null, (p, t) -> sword(p, 1));
      add("iron_sword", Cat.MELEE, GOLD, 7, it(Items.IRON_SWORD, 1), "Eisenschwert", null, (p, t) -> sword(p, 2));
      add("diamond_sword", Cat.MELEE, EM, 4, it(Items.DIAMOND_SWORD, 1), "Diamantschwert", null, (p, t) -> sword(p, 3));
      add("kb_stick", Cat.MELEE, GOLD, 5, enchanted(Items.STICK, Enchantments.KNOCKBACK, 1), "Rueckstoss-Stock", "Schubst Gegner von der Kante",
         stack(t -> {
            ItemStack s = enchanted(Items.STICK, Enchantments.KNOCKBACK, 1);
            s.set(DataComponents.CUSTOM_NAME, Component.literal("Rueckstoss-Stock").withStyle(ChatFormatting.LIGHT_PURPLE));
            return s;
         }));
      add("shield", Cat.MELEE, GOLD, 6, it(Items.SHIELD, 1), "Schild", "Blockt Schlaege und Pfeile (rechte Maustaste)", stack(t -> it(Items.SHIELD, 1)));

      // ---------------------------------------------------------------- Ruestung
      add("chain_armor", Cat.ARMOR, IRON, 40, it(Items.CHAINMAIL_BOOTS, 1), "Kettenruestung", "Hose und Stiefel, bleibt nach dem Tod", (p, t) -> armor(p, t, 1));
      add("iron_armor", Cat.ARMOR, GOLD, 12, it(Items.IRON_BOOTS, 1), "Eisenruestung", "Hose und Stiefel, bleibt nach dem Tod", (p, t) -> armor(p, t, 2));
      add("diamond_armor", Cat.ARMOR, EM, 6, it(Items.DIAMOND_BOOTS, 1), "Diamantruestung", "Hose und Stiefel, bleibt nach dem Tod", (p, t) -> armor(p, t, 3));

      // ---------------------------------------------------------------- Werkzeuge
      add("shears", Cat.TOOLS, IRON, 20, it(Items.SHEARS, 1), "Schere", "Schneidet Wolle blitzschnell, bleibt nach dem Tod", (p, t) -> {
         if (count(p.getInventory(), Items.SHEARS) > 0) {
            p.sendSystemMessage(Component.literal("Du hast schon eine Schere.").withStyle(ChatFormatting.RED));
            return false;
         }

         giveStack(p, it(Items.SHEARS, 1));
         return true;
      });
      int[] pickPrice = {10, 10, 3, 6};
      Item[] pickCur = {IRON, IRON, GOLD, GOLD};
      String[] pickName = {"Holzspitzhacke", "Eisenspitzhacke", "Goldspitzhacke (Effizienz II)", "Diamantspitzhacke (Effizienz III)"};
      for (int i = 0; i < 4; i++) {
         int tier = i + 1;
         add("pickaxe" + tier, Cat.TOOLS, pickCur[i], pickPrice[i], it(PICKAXES[i], 1), pickName[i], "Stufe " + tier + " - nach dem Tod eine Stufe weniger",
            (p, t) -> tool(p, PICKAXES, tier, "Spitzhacke"));
      }

      int[] axePrice = {10, 10, 3, 6};
      Item[] axeCur = {IRON, IRON, GOLD, GOLD};
      String[] axeName = {"Holzaxt", "Steinaxt", "Eisenaxt (Effizienz II)", "Diamantaxt (Effizienz III)"};
      for (int i = 0; i < 4; i++) {
         int tier = i + 1;
         add("axe" + tier, Cat.TOOLS, axeCur[i], axePrice[i], it(AXES[i], 1), axeName[i], "Fuer Holz - Stufe " + tier, (p, t) -> tool(p, AXES, tier, "Axt"));
      }

      // ---------------------------------------------------------------- Fernkampf
      add("arrows", Cat.RANGED, GOLD, 2, it(Items.ARROW, 8), "Pfeile x8", null, stack(t -> it(Items.ARROW, 8)));
      add("bow", Cat.RANGED, GOLD, 12, it(Items.BOW, 1), "Bogen", null, stack(t -> it(Items.BOW, 1)));
      add("power_bow", Cat.RANGED, GOLD, 20, enchanted(Items.BOW, Enchantments.POWER, 1), "Bogen (Staerke I)", null,
         stack(t -> enchanted(Items.BOW, Enchantments.POWER, 1)));
      add("punch_bow", Cat.RANGED, EM, 6, enchanted(Items.BOW, Enchantments.POWER, 1, Enchantments.PUNCH, 1), "Bogen (Staerke I, Schlag I)", "Schiesst Gegner weit weg",
         stack(t -> enchanted(Items.BOW, Enchantments.POWER, 1, Enchantments.PUNCH, 1)));
      add("snowballs", Cat.RANGED, IRON, 8, it(Items.SNOWBALL, 16), "Schneebaelle x16", "Kleiner Schubs aus der Ferne", stack(t -> it(Items.SNOWBALL, 16)));
      add("wind", Cat.RANGED, IRON, 16, it(Items.WIND_CHARGE, 4), "Windkugeln x4", "Schleudert Gegner (und dich) weg", stack(t -> it(Items.WIND_CHARGE, 4)));
      add("rod", Cat.RANGED, IRON, 12, it(Items.FISHING_ROD, 1), "Angel", "Zieht Gegner zu dir", stack(t -> it(Items.FISHING_ROD, 1)));

      // ---------------------------------------------------------------- Traenke
      add("speed", Cat.POTIONS, EM, 1, potion("Tempotrank (45 s)", 0x7CAFC6, new MobEffectInstance(MobEffects.SPEED, 900, 1)), "Tempotrank", "Tempo II fuer 45 Sekunden",
         stack(t -> potion("Tempotrank (45 s)", 0x7CAFC6, new MobEffectInstance(MobEffects.SPEED, 900, 1))));
      add("jump", Cat.POTIONS, EM, 1, potion("Sprungtrank (45 s)", 0x22FF4C, new MobEffectInstance(MobEffects.JUMP_BOOST, 900, 4)), "Sprungtrank", "Sprungkraft V fuer 45 Sekunden",
         stack(t -> potion("Sprungtrank (45 s)", 0x22FF4C, new MobEffectInstance(MobEffects.JUMP_BOOST, 900, 4))));
      add("invis", Cat.POTIONS, EM, 2, potion("Unsichtbarkeitstrank (30 s)", 0xF6F6F6, new MobEffectInstance(MobEffects.INVISIBILITY, 600, 0)), "Unsichtbarkeitstrank",
         "30 Sekunden unsichtbar - Bots sehen dich erst ganz nah", stack(t -> potion("Unsichtbarkeitstrank (30 s)", 0xF6F6F6, new MobEffectInstance(MobEffects.INVISIBILITY, 600, 0))));
      add("milk", Cat.POTIONS, GOLD, 4, BwItems.make(Items.MILK_BUCKET, 1, BwItems.MAGIC_MILK, "Magische Milch", ChatFormatting.WHITE), "Magische Milch",
         "30 Sekunden keine Fallen ausloesen\n(Rechtsklick)", stack(t -> BwItems.make(Items.MILK_BUCKET, 1, BwItems.MAGIC_MILK, "Magische Milch", ChatFormatting.WHITE,
            "Rechtsklick: 30 s keine Fallen ausloesen")));

      // ---------------------------------------------------------------- Extras
      add("gapple", Cat.UTILITY, GOLD, 3, it(Items.GOLDEN_APPLE, 1), "Goldener Apfel", "Heilt und gibt Extra-Herzen", stack(t -> it(Items.GOLDEN_APPLE, 1)));
      add("fireball", Cat.UTILITY, IRON, 40, it(Items.FIRE_CHARGE, 1), "Feuerball", "Rechtsklick: fliegt geradeaus und explodiert\n(auch zum Feuerball-Springen)",
         stack(t -> BwItems.make(Items.FIRE_CHARGE, 1, BwItems.FIREBALL, "Feuerball", ChatFormatting.GOLD, "Rechtsklick zum Werfen")));
      add("tnt", Cat.UTILITY, GOLD, 4, it(Items.TNT, 1), "TNT", "Zuendet sofort - sprengt Bloecke (kein Glas, kein Obsidian)",
         stack(t -> BwItems.make(Items.TNT, 1, BwItems.TNT, "TNT", ChatFormatting.RED, "Setzen: zuendet sofort")));
      add("pearl", Cat.UTILITY, EM, 4, it(Items.ENDER_PEARL, 1), "Enderperle", "Teleportiert dich dorthin, wo sie landet", stack(t -> it(Items.ENDER_PEARL, 1)));
      add("water", Cat.UTILITY, GOLD, 3, it(Items.WATER_BUCKET, 1), "Wassereimer", "Bremst Stuerze und Gegner", stack(t -> it(Items.WATER_BUCKET, 1)));
      add("sponge", Cat.UTILITY, GOLD, 3, it(Items.SPONGE, 4), "Schwamm x4", "Saugt Wasser auf", stack(t -> it(Items.SPONGE, 4)));
      add("bridge_egg", Cat.UTILITY, EM, 1, it(Items.EGG, 1), "Bruecken-Ei", "Werfen: baut eine Wollbruecke hinter sich her",
         stack(t -> BwItems.make(Items.EGG, 1, BwItems.BRIDGE_EGG, "Bruecken-Ei", ChatFormatting.YELLOW, "Rechtsklick zum Werfen")));
      add("popup_tower", Cat.UTILITY, IRON, 24, it(Items.CHEST, 1), "Pop-Up-Turm", "Baut in Sekunden einen Turm mit Leiter vor dir",
         stack(t -> BwItems.make(Items.CHEST, 1, BwItems.POPUP_TOWER, "Pop-Up-Turm", ChatFormatting.GOLD, "Rechtsklick: Turm vor dir bauen")));
      add("bedbug", Cat.UTILITY, IRON, 24, it(Items.SNOWBALL, 1), "Bettwanze", "Werfen: ein Silberfischchen kaempft 15 s fuer dich",
         stack(t -> BwItems.make(Items.SNOWBALL, 1, BwItems.BEDBUG, "Bettwanze", ChatFormatting.DARK_GRAY, "Rechtsklick zum Werfen")));
      add("golem", Cat.UTILITY, IRON, 120, it(Items.IRON_GOLEM_SPAWN_EGG, 1), "Traumverteidiger", "Ein Eisengolem verteidigt 4 Minuten eure Insel",
         stack(t -> BwItems.make(Items.IRON_GOLEM_SPAWN_EGG, 1, BwItems.GOLEM, "Traumverteidiger", ChatFormatting.WHITE, "Rechtsklick auf den Boden")));
      add("rescue", Cat.UTILITY, EM, 1, it(Items.BLAZE_ROD, 1), "Rettungsplattform", "Rechtsklick beim Fallen: Schleimplattform fuer 10 s",
         stack(t -> BwItems.make(Items.BLAZE_ROD, 1, BwItems.RESCUE, "Rettungsplattform", ChatFormatting.GREEN, "Rechtsklick beim Fallen")));
      add("tracker", Cat.UTILITY, EM, 2, it(Items.COMPASS, 1), "Spieler-Tracker", "Zeigt auf den naechsten Gegner und sagt die Entfernung",
         stack(t -> BwItems.make(Items.COMPASS, 1, BwItems.TRACKER, "Spieler-Tracker", ChatFormatting.RED, "In der Hand: zeigt auf den naechsten Gegner")));

      // ---------------------------------------------------------------- Team-Upgrades (Diamanten)
      addDyn("u_sharp", Cat.UPGRADES, DIA, t -> t.sharpness ? -1 : 8, t -> it(Items.IRON_SWORD, 1), "Geschaerfte Klingen", "Schaerfe I auf alle Schwerter und Aexte",
         upgrade("Geschaerfte Klingen", t -> !t.sharpness, t -> t.sharpness = true, "Habt ihr schon."));
      addDyn("u_prot", Cat.UPGRADES, DIA, t -> t.protection >= 4 ? -1 : new int[]{5, 10, 20, 30}[t.protection], t -> it(Items.IRON_CHESTPLATE, Math.min(4, t.protection + 1)),
         "Verstaerkte Ruestung", "Schutz I - IV fuers ganze Team", upgrade("Verstaerkte Ruestung", t -> t.protection < 4, t -> t.protection++, "Ihr habt schon Schutz IV."));
      addDyn("u_haste", Cat.UPGRADES, DIA, t -> t.haste >= 2 ? -1 : new int[]{4, 6}[t.haste], t -> it(Items.GOLDEN_PICKAXE, Math.min(2, t.haste + 1)),
         "Wahnsinniger Bergarbeiter", "Eile I / II - schneller abbauen", upgrade("Wahnsinniger Bergarbeiter", t -> t.haste < 2, t -> t.haste++, "Habt ihr schon ganz."));
      addDyn("u_forge", Cat.UPGRADES, DIA, t -> t.forge >= 4 ? -1 : new int[]{4, 8, 12, 16}[t.forge], t -> it(Items.FURNACE, Math.min(4, t.forge + 1)),
         "Eisenschmiede", "I: +40% Eisen/Gold, II: +100%\nIII: Smaragde auf der Insel, IV: geschmolzen +50%",
         upgrade("Eisenschmiede", t -> t.forge < 4, t -> t.forge++, "Eure Schmiede ist schon auf Stufe IV."));
      addDyn("u_heal", Cat.UPGRADES, DIA, t -> t.healPool ? -1 : 3, t -> it(Items.BEACON, 1), "Heilfeld", "Regeneration auf eurer Insel",
         upgrade("Heilfeld", t -> !t.healPool, t -> t.healPool = true, "Euer Heilfeld steht schon."));
      addDyn("u_feather", Cat.UPGRADES, DIA, t -> t.featherFall ? -1 : 2, t -> it(Items.FEATHER, 1), "Federfall-Stiefel", "Federfall II auf alle Stiefel",
         upgrade("Federfall-Stiefel", t -> !t.featherFall, t -> t.featherFall = true, "Habt ihr schon."));
      Item[] trapIcons = {Items.TRIPWIRE_HOOK, Items.FEATHER, Items.REDSTONE_TORCH, Items.IRON_PICKAXE};
      for (BwItems.Trap trap : BwItems.Trap.values()) {
         addDyn("trap_" + trap.name().toLowerCase(), Cat.UPGRADES, DIA, Shop::trapPrice, t -> it(trapIcons[trap.ordinal()], 1), "Falle: " + trap.label,
            trap.effect + "\nLoest aus, wenn ein Gegner eure Insel betritt", trap(trap));
      }
   }
}
