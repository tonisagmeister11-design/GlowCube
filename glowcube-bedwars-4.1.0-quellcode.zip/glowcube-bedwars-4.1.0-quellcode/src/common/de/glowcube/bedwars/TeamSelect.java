package de.glowcube.bedwars;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ResolvableProfile;

/**
 * Die Teamwahl: eine Kiste mit den Koepfen aller Mitspieler. Links stehen die fuenf Teams (je 4 Plaetze),
 * rechts die Spieler, die noch kein Team haben. Kopf anklicken = aufnehmen, in ein Team klicken = ablegen
 * (Ziehen mit gedrueckter Maus geht auch). Shift-Klick verteilt automatisch. Freie Plaetze werden Bots.
 *
 * <pre>
 *  [Rot ] [ ][ ][ ][ ]   [Pool][Pool][Pool][Pool]
 *  [Blau] [ ][ ][ ][ ]   ...
 *  ...
 *  [Zufall][Leeren][Schwierigkeit] . [Info] . [Abbrechen][START]
 * </pre>
 */
public final class TeamSelect {
   private static final int TEAMS = BwTeam.values().length;
   private static final int SLOTS = Game.TEAM_SIZE;
   private static final int POOL = 20;
   private static final Random RND = new Random();

   private static MinecraftServer server;
   /** Wer mitspielt (Reihenfolge = Reihenfolge im Pool). */
   private static final Map<UUID, ServerPlayer> players = new LinkedHashMap<>();
   private static final UUID[][] grid = new UUID[TEAMS][SLOTS];
   private static UUID carried;
   private static int dragTarget = -1;
   private static GuiMenu menu;
   private static boolean active;
   /** Knopf gedrueckt (1 = Start, -1 = Abbrechen) - wird im naechsten Tick ausgefuehrt, nicht mitten im Klick. */
   private static int pending;

   private TeamSelect() {
   }

   static void begin(MinecraftServer srv, List<ServerPlayer> ps) {
      server = srv;
      players.clear();
      for (ServerPlayer p : ps) {
         if (players.size() < POOL) {
            players.put(p.getUUID(), p);
         }
      }

      for (UUID[] row : grid) {
         java.util.Arrays.fill(row, null);
      }

      carried = null;
      dragTarget = -1;
      pending = 0;
      active = true;
   }

   /** @return 1 = Start gedrueckt, -1 = Abbrechen, 0 = nichts */
   static int pollAction() {
      int a = pending;
      pending = 0;
      return a;
   }

   static void open(ServerPlayer host) {
      if (!active) {
         return;
      }

      SimpleContainer box = GuiMenu.box(6);
      render(box);
      menu = GuiMenu.open(host, Component.literal("Teams einteilen").withStyle(ChatFormatting.DARK_GRAY), 6, box, new Handler());
   }

   static void close() {
      active = false;
      carried = null;
      if (menu != null) {
         for (ServerPlayer p : players.values()) {
            if (p.containerMenu == menu) {
               p.closeContainer();
            }
         }
      }

      menu = null;
   }

   static void remove(UUID id) {
      players.remove(id);
      if (id.equals(carried)) {
         carried = null;
      }

      for (UUID[] row : grid) {
         for (int i = 0; i < row.length; i++) {
            if (id.equals(row[i])) {
               row[i] = null;
            }
         }
      }

      redraw();
   }

   /**
    * Die Teams sind fertig: wer noch kein Team hat, kommt zufaellig ins leerste Team.
    *
    * @return Team je Spieler
    */
   static Map<UUID, Integer> finish() {
      if (carried != null) {
         carried = null;
      }

      for (UUID id : unassigned()) {
         placeInEmptiest(id);
      }

      Map<UUID, Integer> out = new HashMap<>();
      for (int t = 0; t < TEAMS; t++) {
         for (UUID id : grid[t]) {
            if (id != null) {
               out.put(id, t);
            }
         }
      }

      return out;
   }

   // ====================================================================== Modell

   private static List<UUID> unassigned() {
      List<UUID> list = new ArrayList<>();
      for (UUID id : players.keySet()) {
         if (teamOf(id) < 0 && !id.equals(carried)) {
            list.add(id);
         }
      }

      return list;
   }

   private static int teamOf(UUID id) {
      for (int t = 0; t < TEAMS; t++) {
         for (UUID u : grid[t]) {
            if (id.equals(u)) {
               return t;
            }
         }
      }

      return -1;
   }

   private static void unplace(UUID id) {
      for (UUID[] row : grid) {
         for (int i = 0; i < row.length; i++) {
            if (id.equals(row[i])) {
               row[i] = null;
            }
         }
      }
   }

   private static int members(int t) {
      int n = 0;
      for (UUID u : grid[t]) {
         if (u != null) {
            n++;
         }
      }

      return n;
   }

   private static boolean placeInTeam(UUID id, int t) {
      for (int i = 0; i < SLOTS; i++) {
         if (grid[t][i] == null) {
            unplace(id);
            grid[t][i] = id;
            return true;
         }
      }

      return false;
   }

   private static void placeInEmptiest(UUID id) {
      List<Integer> order = new ArrayList<>();
      for (int t = 0; t < TEAMS; t++) {
         order.add(t);
      }

      Collections.shuffle(order, RND);
      int best = -1;
      for (int t : order) {
         if (members(t) < SLOTS && (best < 0 || members(t) < members(best))) {
            best = t;
         }
      }

      if (best >= 0) {
         placeInTeam(id, best);
      }
   }

   private static void randomize() {
      for (UUID[] row : grid) {
         java.util.Arrays.fill(row, null);
      }

      List<UUID> ids = new ArrayList<>(players.keySet());
      Collections.shuffle(ids, RND);
      for (UUID id : ids) {
         placeInEmptiest(id);
      }
   }

   // ====================================================================== Anzeige

   private static int teamOfSlot(int slot) {
      int row = slot / 9;
      int col = slot % 9;
      return row < TEAMS && col <= SLOTS ? row : -1;
   }

   private static int memberIndex(int slot) {
      int col = slot % 9;
      return slot / 9 < TEAMS && col >= 1 && col <= SLOTS ? col - 1 : -1;
   }

   private static int poolIndex(int slot) {
      int row = slot / 9;
      int col = slot % 9;
      return row < 5 && col >= 5 ? row * 4 + col - 5 : -1;
   }

   private static int poolSlot(int i) {
      return i / 4 * 9 + 5 + i % 4;
   }

   static ItemStack head(UUID id, boolean held) {
      ServerPlayer p = players.get(id);
      ItemStack s = new ItemStack(Items.PLAYER_HEAD);
      if (p != null) {
         s.set(DataComponents.PROFILE, ResolvableProfile.createResolved(p.getGameProfile()));
         s.set(DataComponents.CUSTOM_NAME, Component.literal(p.getName().getString()).withStyle(st -> st.withColor(ChatFormatting.YELLOW).withBold(true).withItalic(false)));
         s.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
            Component.literal(held ? "In ein Team klicken zum Ablegen" : "Klicken und in ein Team ziehen").withStyle(st -> st.withColor(ChatFormatting.GRAY).withItalic(false)),
            Component.literal("Shift-Klick: automatisch verteilen / zurueck").withStyle(st -> st.withColor(ChatFormatting.DARK_GRAY).withItalic(false))
         )));
      }

      return s;
   }

   private static void render(SimpleContainer box) {
      ItemStack filler = BwItems.make(Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.BLACK), 1, null, " ", ChatFormatting.GRAY);
      for (int i = 0; i < 54; i++) {
         box.setItem(i, filler.copy());
      }

      for (int t = 0; t < TEAMS; t++) {
         BwTeam team = BwTeam.values()[t];
         List<String> lore = new ArrayList<>();
         for (UUID u : grid[t]) {
            if (u != null && players.containsKey(u)) {
               lore.add("• " + players.get(u).getName().getString());
            }
         }

         for (int i = members(t); i < SLOTS; i++) {
            lore.add("• Bot");
         }

         lore.add("Klick: getragenen Kopf hier einsetzen");
         ItemStack label = BwItems.make(team.wool.asItem(), Math.max(1, members(t)), null, "Team " + team.label + " (" + members(t) + "/" + SLOTS + ")", team.format,
            lore.toArray(new String[0]));
         box.setItem(t * 9, label);

         Item pane = net.minecraft.world.level.block.Blocks.STAINED_GLASS_PANE.pick(team.dye).asItem();
         for (int i = 0; i < SLOTS; i++) {
            UUID u = grid[t][i];
            box.setItem(t * 9 + 1 + i, u != null && players.containsKey(u) ? head(u, false)
               : BwItems.make(pane, 1, null, "Freier Platz", team.format, "Wird von einem Bot gespielt", "Kopf hierher ziehen"));
         }
      }

      List<UUID> pool = unassigned();
      for (int i = 0; i < POOL; i++) {
         box.setItem(poolSlot(i), i < pool.size() ? head(pool.get(i), false)
            : BwItems.make(Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.LIGHT_GRAY), 1, null, "Ohne Team", ChatFormatting.GRAY, "Hier liegen Spieler ohne Team", "(werden beim Start zufaellig verteilt)"));
      }

      box.setItem(45, BwItems.make(Items.ENDER_EYE, 1, null, "Zufaellig verteilen", ChatFormatting.LIGHT_PURPLE, "Alle Spieler gleichmaessig auf die Teams"));
      box.setItem(46, BwItems.make(Items.BUCKET, 1, null, "Alle zuruecksetzen", ChatFormatting.WHITE, "Alle Koepfe zurueck nach rechts"));
      box.setItem(47, BwItems.make(Items.IRON_SWORD, 1, null, "Bot-Schwierigkeit: " + Config.DIFFICULTIES[Config.difficulty], ChatFormatting.AQUA,
         "Klicken zum Aendern", "leicht - normal - schwer - profi"));
      box.setItem(49, BwItems.make(Items.BOOK, 1, null, "So geht's", ChatFormatting.YELLOW,
         "Kopf anklicken = aufnehmen", "Platz in einem Team anklicken = ablegen", "Shift-Klick = automatisch", "Freie Plaetze spielen Bots",
         "Wer kein Team hat, wird beim Start verteilt"));
      box.setItem(51, BwItems.make(Items.BARRIER, 1, null, "Abbrechen", ChatFormatting.RED, "Die Runde faellt aus"));
      box.setItem(53, BwItems.make(Items.CONCRETE.pick(net.minecraft.world.item.DyeColor.LIME), 1, null, "▶ START", ChatFormatting.GREEN, "Teams bestaetigen", "Danach dreht sich das Gluecksrad"));
      box.setItem(52, BwItems.make(Items.STAINED_GLASS_PANE.pick(net.minecraft.world.item.DyeColor.LIME), 1, null, "▶ START", ChatFormatting.GREEN, "Teams bestaetigen"));
   }

   private static void redraw() {
      if (menu != null) {
         render(menu.box);
         menu.setCarried(carried == null ? ItemStack.EMPTY : head(carried, true));
      }
   }

   private static void click(ServerPlayer host, int slot) {
      int team = teamOfSlot(slot);
      int member = memberIndex(slot);
      int pool = poolIndex(slot);
      if (carried == null) {
         // aufnehmen
         UUID pick = null;
         if (member >= 0) {
            pick = grid[team][member];
         } else if (pool >= 0) {
            List<UUID> list = unassigned();
            pick = pool < list.size() ? list.get(pool) : null;
         }

         if (pick != null) {
            unplace(pick);
            carried = pick;
            sound(host, 1.4F);
         }
      } else if (member >= 0) {
         UUID there = grid[team][member];
         UUID was = carried;
         unplace(was);
         grid[team][member] = was;
         carried = there;
         sound(host, 1.8F);
      } else if (team >= 0) {
         if (placeInTeam(carried, team)) {
            carried = null;
            sound(host, 1.8F);
         } else {
            host.sendSystemMessage(Component.literal("Team " + BwTeam.values()[team].label + " ist voll.").withStyle(ChatFormatting.RED));
            sound(host, 0.6F);
         }
      } else if (pool >= 0) {
         unplace(carried);
         carried = null;
         sound(host, 1.2F);
      }
   }

   private static void quickMove(int slot) {
      int member = memberIndex(slot);
      int team = teamOfSlot(slot);
      int pool = poolIndex(slot);
      if (member >= 0 && grid[team][member] != null) {
         grid[team][member] = null;
      } else if (pool >= 0) {
         List<UUID> list = unassigned();
         if (pool < list.size()) {
            placeInEmptiest(list.get(pool));
         }
      }
   }

   private static void sound(ServerPlayer p, float pitch) {
      p.level().playSound(null, p.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.MASTER, 0.5F, pitch);
   }

   private static final class Handler implements GuiMenu.Handler {
      @Override
      public void click(GuiMenu m, ServerPlayer p, int slot, ContainerInput input, int button) {
         if (!active || !Lobby.isHost(p)) {
            return;
         }

         switch (input) {
            case PICKUP -> {
               if (slot == 45) {
                  carried = null;
                  randomize();
                  sound(p, 1.0F);
               } else if (slot == 46) {
                  carried = null;
                  for (UUID[] row : grid) {
                     java.util.Arrays.fill(row, null);
                  }
               } else if (slot == 47) {
                  Config.difficulty = (Config.difficulty + 1) % Config.DIFFICULTIES.length;
                  Config.save();
                  sound(p, 1.0F);
               } else if (slot == 51) {
                  pending = -1;
                  return;
               } else if (slot == 52 || slot == 53) {
                  pending = 1;
                  return;
               } else if (slot >= 0) {
                  TeamSelect.click(p, slot);
               }
            }
            case QUICK_MOVE -> {
               if (carried == null && slot >= 0) {
                  quickMove(slot);
               }
            }
            case QUICK_CRAFT -> {
               // Ziehen mit gedrueckter Maustaste: der erste Platz, ueber den man zieht, zaehlt
               int stage = AbstractContainerMenu.getQuickcraftHeader(button);
               if (stage == 0) {
                  dragTarget = -1;
               } else if (stage == 1 && dragTarget < 0 && slot >= 0) {
                  dragTarget = slot;
               } else if (stage == 2) {
                  if (dragTarget >= 0 && carried != null) {
                     TeamSelect.click(p, dragTarget);
                  }

                  dragTarget = -1;
               }
            }
            default -> {
            }
         }

         if (active) {
            render(m.box);
            m.setCarried(carried == null ? ItemStack.EMPTY : head(carried, true));
         }
      }

      @Override
      public void closed(GuiMenu m, ServerPlayer p) {
         // getragener Kopf faellt zurueck in die Liste
         carried = null;
         if (menu == m) {
            menu = null;
         }

         if (active && Lobby.isHost(p)) {
            p.sendSystemMessage(Component.literal("Teamwahl geschlossen. ").withStyle(ChatFormatting.GRAY)
               .append(Lobby.button("[Teams oeffnen]", "/bedwars teams", "Weiter einteilen", ChatFormatting.AQUA))
               .append(Component.literal("  "))
               .append(Lobby.button("[▶ START]", "/bedwars los", "So starten", ChatFormatting.GREEN)));
         }
      }
   }

   /** Fuer den Selbsttest: prueft Aufnehmen, Ablegen, Tauschen, volle Teams, Zufall und Fertig-Verteilung. */
   public static List<String> selfTest(MinecraftServer srv, List<ServerPlayer> ps) {
      List<String> fails = new ArrayList<>();
      begin(srv, ps);
      ServerPlayer host = ps.get(0);
      UUID a = ps.get(0).getUUID();
      UUID b = ps.get(1).getUUID();
      // Kopf a aus dem Pool (erstes Feld rechts oben) aufnehmen und bei Rot Platz 1 ablegen
      click(host, poolSlot(0));
      if (!a.equals(carried)) {
         fails.add("Kopf aufnehmen");
      }

      click(host, 1);
      if (!a.equals(grid[0][0]) || carried != null) {
         fails.add("Kopf in Team ablegen");
      }

      // b auf denselben Platz: Tausch, a haengt dann am Mauszeiger
      click(host, poolSlot(0));
      click(host, 1);
      if (!b.equals(grid[0][0]) || !a.equals(carried)) {
         fails.add("Koepfe tauschen");
      }

      // a auf das Team-Schild von Blau: erster freier Platz
      click(host, 9);
      if (!a.equals(grid[1][0])) {
         fails.add("auf Team-Schild ablegen");
      }

      // Rot vollmachen, dann darf kein weiterer rein
      for (int i = 2; i < ps.size() && members(0) < SLOTS; i++) {
         click(host, poolSlot(0));
         click(host, 0);
      }

      if (members(0) != SLOTS) {
         fails.add("Team voll machen");
      } else if (ps.size() > 5) {
         click(host, poolSlot(0));
         UUID c = carried;
         click(host, 0);
         if (c == null || !c.equals(carried) || members(0) != SLOTS) {
            fails.add("volles Team lehnt ab");
         }

         click(host, poolSlot(19));
      }

      randomize();
      for (int t = 0; t < TEAMS; t++) {
         if (members(t) > SLOTS) {
            fails.add("Zufall ueberfuellt Team");
         }
      }

      Map<UUID, Integer> out = finish();
      if (out.size() != players.size()) {
         fails.add("Fertig: nicht alle verteilt (" + out.size() + "/" + players.size() + ")");
      }

      active = false;
      return fails;
   }
}
