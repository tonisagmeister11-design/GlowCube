#!/usr/bin/env python3
"""
Vorschaubilder der Karten (isometrisch) aus den Dateien von /bedwars export.

    python3 tools/render_maps.py <ordner mit export_*.txt> <ausgabe-ordner>

Jede Zeile einer Exportdatei: "dx dy dz blockname" relativ zur Kartenmitte.
"""
import os
import sys

from PIL import Image, ImageDraw

COLORS = {
    # genaue Namen zuerst
    "quartz_bricks": (236, 230, 222), "smooth_quartz": (240, 235, 228), "quartz_pillar": (232, 226, 218),
    "chiseled_quartz_block": (226, 220, 210), "quartz_slab": (236, 230, 222), "smooth_quartz_slab": (240, 235, 228),
    "stone_bricks": (122, 122, 122), "chiseled_stone_bricks": (115, 115, 115), "mossy_stone_bricks": (105, 120, 90),
    "cracked_stone_bricks": (112, 112, 112), "polished_andesite": (132, 135, 134), "andesite": (136, 136, 137),
    "stone": (125, 125, 125), "cobblestone": (118, 118, 118), "mossy_cobblestone": (100, 118, 92), "smooth_stone": (158, 158, 158),
    "iron_block": (220, 220, 220), "gold_block": (246, 208, 61), "diamond_block": (98, 237, 228), "emerald_block": (42, 203, 87),
    "sea_lantern": (172, 199, 190), "beacon": (117, 220, 215), "lantern": (255, 190, 90), "soul_lantern": (90, 210, 220),
    "end_rod": (240, 236, 230), "player_head": (190, 140, 110), "grass_block": (104, 160, 60), "moss_block": (89, 110, 45),
    "dirt": (134, 96, 67), "rooted_dirt": (144, 103, 76), "tuff": (108, 109, 102), "cherry_log": (54, 33, 44),
    "cherry_leaves": (240, 168, 205), "cherry_planks": (226, 178, 172), "stripped_cherry_wood": (215, 145, 148),
    "stripped_cherry_log": (215, 145, 148), "stripped_mangrove_log": (120, 54, 48), "mangrove_planks": (117, 54, 48),
    "dark_oak_slab": (66, 43, 20), "stone_brick_wall": (122, 122, 122), "stone_brick_slab": (122, 122, 122),
    "smooth_sandstone": (223, 214, 170), "cut_sandstone": (217, 206, 159), "sandstone": (216, 203, 155),
    "chiseled_sandstone": (216, 202, 154), "cut_red_sandstone": (181, 97, 31), "chiseled_red_sandstone": (183, 96, 27),
    "red_sandstone": (186, 99, 29), "smooth_red_sandstone": (181, 98, 31), "terracotta": (152, 94, 67),
    "jungle_log": (85, 67, 25), "jungle_leaves": (48, 120, 20), "snow_block": (249, 254, 254), "snow": (249, 254, 254),
    "polished_diorite": (192, 193, 194), "calcite": (223, 224, 220), "packed_ice": (141, 180, 250), "blue_ice": (116, 167, 253),
    "spruce_log": (58, 37, 16), "spruce_leaves": (60, 90, 60), "spruce_slab": (114, 84, 48), "carved_pumpkin": (198, 118, 24),
    "polished_blackstone_bricks": (48, 42, 49), "nether_bricks": (44, 21, 26), "polished_blackstone": (53, 48, 56),
    "red_nether_bricks": (69, 7, 9), "gilded_blackstone": (56, 43, 38), "crimson_nylium": (130, 31, 31), "netherrack": (97, 38, 38),
    "blackstone": (42, 36, 41), "basalt": (80, 81, 86), "polished_basalt": (99, 98, 100), "nether_wart_block": (114, 2, 2),
    "warped_wart_block": (22, 119, 121), "crimson_stem": (92, 25, 29), "warped_stem": (58, 58, 77), "shroomlight": (240, 146, 70),
    "crying_obsidian": (32, 10, 60), "obsidian": (15, 10, 24), "soul_soil": (75, 57, 46), "nether_brick_fence": (44, 21, 26),
    "chiseled_nether_bricks": (47, 23, 28), "chiseled_polished_blackstone": (53, 48, 56), "cracked_polished_blackstone_bricks": (44, 37, 43),
    "prismarine_bricks": (99, 171, 158), "dark_prismarine": (51, 91, 75), "prismarine": (99, 156, 151), "conduit": (160, 140, 100),
    "purpur_block": (169, 125, 169), "purpur_pillar": (171, 129, 171), "end_stone_bricks": (218, 224, 162), "end_stone": (219, 222, 158),
    "purpur_slab": (169, 125, 169), "dragon_head": (30, 30, 30), "ochre_froglight": (250, 245, 206), "verdant_froglight": (229, 244, 228),
    "pearlescent_froglight": (245, 240, 239), "mud_bricks": (137, 103, 79),
}
DYES = {
    "white": (233, 236, 236), "orange": (240, 118, 19), "magenta": (189, 68, 179), "light_blue": (58, 175, 217),
    "yellow": (248, 197, 39), "lime": (112, 185, 25), "pink": (237, 141, 172), "gray": (62, 68, 71), "light_gray": (142, 142, 134),
    "cyan": (21, 137, 145), "purple": (121, 42, 172), "blue": (53, 57, 157), "brown": (114, 71, 40), "green": (84, 109, 27),
    "red": (161, 39, 34), "black": (20, 21, 25),
}


def color(name):
    if name in COLORS:
        return COLORS[name]
    for dye, c in sorted(DYES.items(), key=lambda kv: -len(kv[0])):
        if name.startswith(dye + "_"):
            if "terracotta" in name:
                return tuple(int(v * 0.75) for v in c)
            return c
    for key, c in COLORS.items():
        if key in name:
            return c
    return (200, 0, 200)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def render(path, out, title):
    blocks = {}
    with open(path) as f:
        for line in f:
            parts = line.split()
            if len(parts) == 4:
                x, y, z = int(parts[0]), int(parts[1]), int(parts[2])
                blocks[(x, y, z)] = parts[3]

    s = 4  # Pixel pro halbe Blockbreite
    xs = [k[0] for k in blocks]
    zs = [k[2] for k in blocks]
    ys = [k[1] for k in blocks]
    minx, maxx, minz, maxz, miny, maxy = min(xs), max(xs), min(zs), max(zs), min(ys), max(ys)

    def proj(x, y, z):
        return ((x - z) * s * 2, (x + z) * s - y * s * 2.4)

    corners = [proj(x, y, z) for x in (minx, maxx + 1) for z in (minz, maxz + 1) for y in (miny, maxy + 1)]
    ox = -min(c[0] for c in corners) + 20
    oy = -min(c[1] for c in corners) + 50
    w = int(max(c[0] for c in corners) + ox + 20)
    h = int(max(c[1] for c in corners) + oy + 20)
    img = Image.new("RGB", (w, h), (24, 26, 34))
    d = ImageDraw.Draw(img)
    order = sorted(blocks, key=lambda k: (k[0] + k[2], k[1]))
    for (x, y, z) in order:
        name = blocks[(x, y, z)]
        c = color(name)
        top = [proj(x, y + 1, z), proj(x + 1, y + 1, z), proj(x + 1, y + 1, z + 1), proj(x, y + 1, z + 1)]
        left = [proj(x, y + 1, z + 1), proj(x + 1, y + 1, z + 1), proj(x + 1, y, z + 1), proj(x, y, z + 1)]
        right = [proj(x + 1, y + 1, z), proj(x + 1, y + 1, z + 1), proj(x + 1, y, z + 1), proj(x + 1, y, z)]
        for poly, f in ((left, 0.62), (right, 0.8), (top, 1.0)):
            if poly is top and (x, y + 1, z) in blocks:
                continue
            if poly is left and (x, y, z + 1) in blocks:
                continue
            if poly is right and (x + 1, y, z) in blocks:
                continue
            d.polygon([(px + ox, py + oy) for px, py in poly], fill=shade(c, f))
    d.text((20, 15), title, fill=(255, 255, 255))
    img.save(out)


def main():
    src, dst = sys.argv[1], sys.argv[2]
    os.makedirs(dst, exist_ok=True)
    for fn in sorted(os.listdir(src)):
        if fn.startswith("export_") and fn.endswith(".txt"):
            key = fn[len("export_"):-4]
            render(os.path.join(src, fn), os.path.join(dst, key + ".png"), key)
            print("gerendert:", key)


if __name__ == "__main__":
    main()
