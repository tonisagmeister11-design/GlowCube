package de.glowcube.bedwars.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import de.glowcube.bedwars.BwCommands;
import de.glowcube.bedwars.BwItems;
import de.glowcube.bedwars.Config;
import de.glowcube.bedwars.Game;
import de.glowcube.bedwars.Platform;
import de.glowcube.bedwars.Shop;
import java.nio.file.Path;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;

/** Einstieg der Fabric-Mod: verbindet die Fabric-Ereignisse mit dem gemeinsamen Spielcode. */
public final class BedwarsMod implements ModInitializer {
   @Override
   public void onInitialize() {
      Platform.set(new FabricPlatform());
      Config.load();
      ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Game.onJoin(handler.getPlayer(), server));
      ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> Game.onDisconnect(handler.getPlayer()));
      net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> Game.onRespawn(newPlayer));
      ServerLifecycleEvents.SERVER_STOPPING.register(server -> Game.onServerStopping());
      ServerTickEvents.END_SERVER_TICK.register(server -> {
         Game.tick(server);
         Game.afterTick();
         SelfTest.tick(server);
      });
      ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> Game.onDeath(entity, source));
      ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> Game.allowDamage(entity, source));
      PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> !(player instanceof ServerPlayer sp && !Game.onPlayerBreak(sp, pos, state)));
      UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
         if (Game.running() && entity.entityTags().contains("bw_shop")) {
            if (player instanceof ServerPlayer sp && hand == InteractionHand.MAIN_HAND) {
               Shop.open(sp);
            }

            return InteractionResult.SUCCESS;
         }

         return InteractionResult.PASS;
      });
      UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
         if (player instanceof ServerPlayer sp && BwItems.onUseOnBlock(sp, hand, hit.getBlockPos(), hit.getDirection())) {
            return InteractionResult.SUCCESS;
         }

         return InteractionResult.PASS;
      });
      UseItemCallback.EVENT.register((player, world, hand) -> {
         if (player instanceof ServerPlayer sp && BwItems.onUse(sp, hand)) {
            return InteractionResult.SUCCESS;
         }

         return InteractionResult.PASS;
      });
      ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> Game.allowChat(sender, message.signedContent()));
      ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> Game.onChat(sender, message.signedContent()));
      CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> dispatcher.register(
         Commands.literal("bedwars")
            .executes(ctx -> run(ctx, ""))
            .then(Commands.argument("args", StringArgumentType.greedyString())
               .suggests((ctx, b) -> {
                  String[] parts = b.getRemaining().split(" ", -1);
                  int cut = b.getRemaining().lastIndexOf(' ') + 1;
                  var sub = b.createOffset(b.getStart() + cut);
                  for (String s : BwCommands.suggest(parts, isAdmin(ctx.getSource()))) {
                     sub.suggest(s);
                  }

                  return sub.buildFuture();
               })
               .executes(ctx -> run(ctx, StringArgumentType.getString(ctx, "args"))))
      ));
   }

   private static boolean isAdmin(CommandSourceStack src) {
      ServerPlayer p = src.getPlayer();
      return p == null || Platform.get().isAdmin(p);
   }

   private static int run(CommandContext<CommandSourceStack> ctx, String args) {
      CommandSourceStack src = ctx.getSource();
      ServerPlayer p = src.getPlayer();
      String[] parts = args.isBlank() ? new String[0] : args.trim().split("\\s+");
      if (parts.length > 0 && parts[0].equals("selbsttest") && isAdmin(src)) {
         SelfTest.start(src.getServer(), src.getLevel(), BlockPos.containing(src.getPosition()));
         return 1;
      }

      BwCommands.Source s = new BwCommands.Source(src.getServer(), p, src.getLevel(), BlockPos.containing(src.getPosition()), isAdmin(src),
         msg -> src.sendSystemMessage(msg));
      return BwCommands.run(s, parts) ? 1 : 0;
   }

   /** Fabric: die Arena schwebt hoch ueber der Welt, in der man gerade ist. */
   static final class FabricPlatform implements Platform {
      @Override
      public Path configDir() {
         return FabricLoader.getInstance().getConfigDir();
      }

      @Override
      public boolean isServerPlugin() {
         return false;
      }

      @Override
      public ServerLevel arenaLevel(MinecraftServer server, ServerPlayer host) {
         return host != null ? host.level() : server.overworld();
      }

      @Override
      public BlockPos arenaCenter(ServerLevel level, ServerPlayer host) {
         return host != null ? host.blockPosition() : level.getRespawnData().pos();
      }

      @Override
      public boolean teleport(ServerPlayer p, ServerLevel level, double x, double y, double z, float yaw, float pitch) {
         p.stopRiding();
         p.teleportTo(level, x, y, z, java.util.Set.of(), yaw, pitch, true);
         return p.level() == level && p.position().distanceToSqr(x, y, z) < 4.0;
      }

      @Override
      public Difficulty difficulty(ServerLevel level) {
         return level.getDifficulty();
      }

      @Override
      public void setDifficulty(ServerLevel level, Difficulty d) {
         level.getServer().setDifficulty(d, true);
      }

      @Override
      public boolean isAdmin(ServerPlayer p) {
         MinecraftServer srv = p.level().getServer();
         return srv.isSingleplayerOwner(p.nameAndId()) || srv.getPlayerList().isOp(p.nameAndId());
      }

      @Override
      public void log(String msg) {
         System.out.println("[Bedwars] " + msg);
      }
   }
}
