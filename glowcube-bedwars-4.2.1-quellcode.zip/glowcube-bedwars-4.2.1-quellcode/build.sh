#!/usr/bin/env bash
#
# Baut GlowCube Bedwars fuer Minecraft 26.3 - zweimal aus demselben Spielcode:
#
#   dist/glowcube-bedwars-<v>.jar         Fabric-Mod   (src/common + src/fabric)
#   dist/glowcube-bedwars-paper-<v>.jar   Paper-Plugin (src/common + src/paper)
#
# Ab 26.x liefert Mojang den Spielcode ohne Verschleierung aus, Paper 26.x ebenso.
# Deshalb laesst sich alles direkt mit javac uebersetzen - ganz ohne Gradle/Loom/paperweight.
#
#   ./build.sh            beides bauen
#   ./build.sh fabric     nur die Mod
#   ./build.sh paper      nur das Plugin
#
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="${WORK:-$ROOT/.build}"
VERSION="$(sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' "$ROOT/resources/fabric/fabric.mod.json" | head -1)"
JAVAC="${JAVAC:-javac}"
JAVA="${JAVA:-$(dirname "$(command -v "$JAVAC")")/java}"
TARGET="${1:-all}"

MC_JSON_URL="https://piston-meta.mojang.com/v1/packages/702fe59163c6ee6578607daa85811d9bc9c7cc40/26.3.json"
LOADER_URL="https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.19.5/fabric-loader-0.19.5.jar"
FAPI_URL="https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/0.162.0+26.3/fabric-api-0.162.0+26.3.jar"
PAPER_BUILDS_URL="https://fill.papermc.io/v3/projects/paper/versions/26.3/builds"

have_version="$("$JAVAC" -version 2>&1 | sed -n 's/^javac \([0-9]*\).*/\1/p')"
if [ "${have_version:-0}" -lt 25 ]; then
  echo "Fehler: javac 25 oder neuer noetig (gefunden: ${have_version:-unbekannt})." >&2
  exit 1
fi

mkdir -p "$WORK" "$ROOT/dist"

compile() { # name classpath srcdirs... -> $WORK/<name>/classes
  local name="$1" cp="$2"; shift 2
  echo "==> uebersetze $name"
  rm -rf "$WORK/$name"
  mkdir -p "$WORK/$name/classes"
  find "$@" -name '*.java' > "$WORK/$name/sources.txt"
  "$JAVAC" -nowarn -proc:none -encoding UTF-8 --release 25 -cp "$cp" -d "$WORK/$name/classes" "@$WORK/$name/sources.txt"
}

pack() { # name output resource-dirs...
  local name="$1" out="$2"; shift 2
  for r in "$@"; do cp -r "$r/." "$WORK/$name/classes/"; done
  rm -f "$out"
  ( cd "$WORK/$name/classes" && zip -q -r -X "$out" . )
  echo "fertig: $out"
}

build_fabric() {
  mkdir -p "$WORK/lib" "$WORK/fapi"
  if [ ! -f "$WORK/client.jar" ]; then
    echo "==> lade Minecraft 26.3"
    curl -sSL -o "$WORK/26.3.json" "$MC_JSON_URL"
    client_url="$(grep -o '"url": *"https://piston-data.mojang.com/[^"]*/client.jar"' "$WORK/26.3.json" | head -1 | sed 's/.*"\(https[^"]*\)"/\1/')"
    curl -sSL -o "$WORK/client.jar.part" "$client_url"
    mv "$WORK/client.jar.part" "$WORK/client.jar"
  fi
  if [ ! -f "$WORK/lib/.done" ]; then
    echo "==> lade Bibliotheken"
    grep -o '"url": *"https://libraries.minecraft.net/[^"]*\.jar"' "$WORK/26.3.json" \
      | sed 's/.*"\(https[^"]*\)"/\1/' | grep -v natives | sort -u \
      | while read -r url; do
          f="$WORK/lib/$(basename "$url")"
          [ -f "$f" ] || curl -sSL -o "$f" "$url"
        done
    touch "$WORK/lib/.done"
  fi
  if [ ! -f "$WORK/fabric-loader.jar" ]; then
    echo "==> lade Fabric Loader und Fabric API"
    curl -sSL -o "$WORK/fabric-loader.jar" "$LOADER_URL"
    curl -sSL -o "$WORK/fabric-api.jar" "$FAPI_URL"
    ( cd "$WORK/fapi" && unzip -q -o "$WORK/fabric-api.jar" 'META-INF/jars/*' )
  fi
  local cp="$WORK/client.jar:$WORK/fabric-loader.jar"
  for j in "$WORK"/lib/*.jar "$WORK"/fapi/META-INF/jars/*.jar; do cp="$cp:$j"; done
  compile fabric "$cp" "$ROOT/src/common" "$ROOT/src/fabric"
  pack fabric "$ROOT/dist/glowcube-bedwars-$VERSION.jar" "$ROOT/resources/common" "$ROOT/resources/fabric"
}

build_paper() {
  local pdir="$WORK/paper"
  mkdir -p "$pdir"
  if [ ! -f "$pdir/.done" ]; then
    echo "==> lade Paper 26.3"
    url="$(curl -sS "$PAPER_BUILDS_URL" | grep -o '"url":"[^"]*paper-26.3-[0-9]*\.jar"' | sed -n 1p | sed 's/"url":"\(.*\)"/\1/')"
    curl -sSL -o "$pdir/paper.jar" "$url"
    ( cd "$pdir" && "$JAVA" -Dpaperclip.patchonly=true -jar paper.jar >/dev/null )
    touch "$pdir/.done"
  fi
  # Das unveraenderte Minecraft kommt ZUERST in den Klassenpfad: so bindet sich das Plugin nur an Funktionen,
  # die es in jedem Paper-26.3-Build gibt (Paper fuegt in manchen Builds eigene Abkuerzungen hinzu).
  if [ ! -f "$pdir/vanilla-server.jar" ]; then
    unzip -p "$pdir/cache/mojang_26.3.jar" META-INF/versions/26.3/server-26.3.jar > "$pdir/vanilla-server.jar"
  fi
  local cp
  cp="$pdir/vanilla-server.jar:$(find "$pdir/versions" "$pdir/libraries" -name '*.jar' | tr '\n' ':')"
  compile paper-plugin "$cp" "$ROOT/src/common" "$ROOT/src/paper"
  sed "s/@VERSION@/$VERSION/" "$ROOT/resources/paper/plugin.yml" > "$WORK/paper-plugin/plugin.yml.tmp"
  pack paper-plugin "$ROOT/dist/glowcube-bedwars-paper-$VERSION.jar" "$ROOT/resources/common" "$ROOT/resources/paper"
  ( cd "$WORK/paper-plugin" && mv plugin.yml.tmp classes/plugin.yml && cd classes && zip -q -X "$ROOT/dist/glowcube-bedwars-paper-$VERSION.jar" plugin.yml )
}

case "$TARGET" in
  fabric) build_fabric ;;
  paper) build_paper ;;
  *) build_fabric; build_paper ;;
esac
