package de.glowcube.bedwars;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Ablauf vor einer Runde:
 * <ol>
 *    <li><b>Einladung</b>: {@code /bedwars multiplayer} - alle auf dem Server bekommen eine Nachricht mit
 *    [MITSPIELEN]. Wer nicht innerhalb weniger Sekunden (Standard 5) klickt, ist nicht dabei.</li>
 *    <li><b>Teamwahl</b>: wer eingeladen hat, verteilt die Spielerkoepfe auf die Teams (oder zufaellig).
 *    Freie Plaetze bekommen Bots.</li>
 *    <li><b>Gluecksrad</b>: die Karte wird ausgelost, dann geht es los.</li>
 * </ol>
 */
public final class Lobby {
   private enum Phase {
      IDLE,
      INVITE,
      TEAMS,
      WHEEL
   }

   private static Phase phase = Phase.IDLE;
   private static MinecraftServer server;
   private static UUID host;
   private static final Set<UUID> accepted = new LinkedHashSet<>();
   private static final Set<UUID> declined = new LinkedHashSet<>();
   private static final Set<UUID> invited = new LinkedHashSet<>();
   private static int phaseEndsAt = -1;

   private Lobby() {
   }

   public static boolean open() {
      return phase != Phase.IDLE;
   }

   private static int now() {
      return server == null ? 0 : server.getTickCount();
   }

   // ====================================================================== Chat erkennen

   /** "bedwars 2", "bad wars multiplayer", "bedwars zu zweit", "bw mp" ... (nur in der Mod - auf dem Server nur per Befehl) */
   static boolean isTrigger(String raw) {
      String c = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
      return c.matches(".*(bed|bad|bet|bett|bat)wars(2|zwei|mp|multi|multiplayer|zuzweit|zusammen|mitfreunden|online).*")
         || c.matches("(multiplayer|mp)(bed|bad|bett)wars.*")
         || c.equals("bw2")
         || c.equals("bwmp");
   }

   private static boolean isYes(String s) {
      return s.matches("(ja+|jo+|jaa*\\s*klar|klar|gerne?|yes|yep|ok|okay|bin dabei|ich bin dabei|dabei|ich|ich auch|bin am start|safe|na klar|jap|jup)[!. ]*");
   }

   /** @return true, wenn die Nachricht fuer die Lobby war (dann reagieren die Bots nicht darauf). */
   public static boolean onChat(ServerPlayer p, String raw) {
      if (raw == null) {
         return false;
      }

      if (!Platform.get().isServerPlugin() && isTrigger(raw)) {
         request(p);
         return true;
      }

      if (phase == Phase.INVITE && invited.contains(p.getUUID()) && !accepted.contains(p.getUUID()) && isYes(raw.toLowerCase(Locale.ROOT).trim())) {
         accept(p);
         return true;
      }

      return false;
   }

   // ====================================================================== Einladung

   /** Jemand will eine Multiplayer-Runde. */
   public static void request(ServerPlayer p) {
      MinecraftServer srv = p.level().getServer();
      server = srv;
      if (phase == Phase.INVITE) {
         if (!accepted.contains(p.getUUID())) {
            invited.add(p.getUUID());
            accept(p);
         }

         return;
      } else if (phase != Phase.IDLE) {
         p.sendSystemMessage(Component.literal("Gerade wird schon eine Runde vorbereitet.").withStyle(ChatFormatting.YELLOW));
         return;
      }

      if (Game.running() && (Platform.get().isServerPlugin() || Game.human(p) == null)) {
         p.sendSystemMessage(Component.literal("Gerade laeuft schon eine Bedwars-Runde. Sobald sie vorbei ist, kannst du eine neue starten.").withStyle(ChatFormatting.YELLOW));
         return;
      }

      List<ServerPlayer> others = new ArrayList<>();
      for (ServerPlayer o : srv.getPlayerList().getPlayers()) {
         if (o != p && !o.hasDisconnected()) {
            others.add(o);
         }
      }

      if (others.isEmpty()) {
         p.sendSystemMessage(header("BEDWARS MULTIPLAYER"));
         p.sendSystemMessage(Component.literal("Gerade ist niemand ausser dir online. ").withStyle(ChatFormatting.YELLOW)
            .append(button("[▶ ALLEIN MIT BOTS]", "/bedwars start", "Runde mit 19 Bots starten", ChatFormatting.GREEN)));

         return;
      }

      phase = Phase.INVITE;
      host = p.getUUID();
      accepted.clear();
      declined.clear();
      invited.clear();
      accepted.add(host);
      phaseEndsAt = now() + Config.inviteSeconds * 20;

      for (ServerPlayer o : others) {
         invite(o, p);
      }

      p.sendSystemMessage(header("BEDWARS MULTIPLAYER"));
      p.sendSystemMessage(Component.literal("Einladung an " + others.size() + " Spieler verschickt - sie haben " + Config.inviteSeconds + " Sekunden zum Annehmen.").withStyle(ChatFormatting.YELLOW));
      if (Game.running()) {
         p.sendSystemMessage(Component.literal("Die laufende Runde wird beim Start beendet.").withStyle(ChatFormatting.GRAY));
      }

      p.sendSystemMessage(Component.empty()
         .append(button("[▶ SOFORT WEITER]", "/bedwars los", "Nicht mehr warten", ChatFormatting.GREEN))
         .append(Component.literal("  "))
         .append(button("[✖ ABBRECHEN]", "/bedwars abbrechen", "Einladung zuruecknehmen", ChatFormatting.RED)));
      ping(p, 1.6F);
   }

   private static void invite(ServerPlayer o, ServerPlayer from) {
      invited.add(o.getUUID());
      o.sendSystemMessage(header("BEDWARS EINLADUNG"));
      o.sendSystemMessage(Component.literal(from.getName().getString()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
         .append(Component.literal(" startet eine Bedwars-Runde! ").withStyle(ChatFormatting.YELLOW))
         .append(button("[✔ MITSPIELEN]", "/bedwars ja", "Klicken, um mitzuspielen", ChatFormatting.GREEN)));
      o.sendSystemMessage(Component.literal("Du hast " + Config.inviteSeconds + " Sekunden - wer nicht klickt, ist nicht dabei.").withStyle(ChatFormatting.GRAY));
      Game.title(o, Component.literal("BEDWARS").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
         Component.literal("Klick im Chat auf [MITSPIELEN]").withStyle(ChatFormatting.YELLOW));
      ping(o, 1.2F);
   }

   public static void accept(ServerPlayer p) {
      server = p.level().getServer();
      if (phase != Phase.INVITE) {
         p.sendSystemMessage(Component.literal(phase == Phase.IDLE ? "Gerade gibt es keine Einladung." : "Zu spaet - die Teams werden schon eingeteilt.").withStyle(ChatFormatting.YELLOW));
         return;
      }

      if (!invited.contains(p.getUUID()) && !p.getUUID().equals(host)) {
         invited.add(p.getUUID());
      }

      if (accepted.size() >= Config.maxPlayers) {
         p.sendSystemMessage(Component.literal("Die Runde ist schon voll (" + Config.maxPlayers + " Spieler).").withStyle(ChatFormatting.RED));
         return;
      }

      declined.remove(p.getUUID());
      if (accepted.add(p.getUUID())) {
         tellLobby(Component.literal("✔ ").withStyle(ChatFormatting.GREEN)
            .append(Component.literal(p.getName().getString()).withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD))
            .append(Component.literal(" ist dabei! (" + accepted.size() + " Spieler)").withStyle(ChatFormatting.GREEN)));
         ping(p, 2.0F);
         maybeAllAnswered();
      }
   }

   public static void decline(ServerPlayer p) {
      if (phase != Phase.INVITE) {
         return;
      }

      if (p.getUUID().equals(host)) {
         cancel(p);
         return;
      }

      accepted.remove(p.getUUID());
      if (declined.add(p.getUUID())) {
         p.sendSystemMessage(Component.literal("Ok, du spielst diesmal nicht mit.").withStyle(ChatFormatting.GRAY));
         maybeAllAnswered();
      }
   }

   /** Wer eingeladen hat: sofort weiter (Einladung beenden bzw. Teams bestaetigen). */
   public static void startNow(ServerPlayer p) {
      if (phase == Phase.IDLE) {
         p.sendSystemMessage(Component.literal("Gerade gibt es keine Einladung.").withStyle(ChatFormatting.YELLOW));
      } else if (!p.getUUID().equals(host)) {
         p.sendSystemMessage(Component.literal("Das kann nur, wer eingeladen hat.").withStyle(ChatFormatting.YELLOW));
      } else if (phase == Phase.INVITE) {
         phaseEndsAt = now();
      } else if (phase == Phase.TEAMS) {
         teamsDone(TeamSelect.finish());
      }
   }

   public static void cancel(ServerPlayer p) {
      if (phase != Phase.IDLE && phase != Phase.WHEEL && (p == null || p.getUUID().equals(host) || Platform.get().isAdmin(p))) {
         tellLobby(Component.literal("Die Bedwars-Runde wurde abgebrochen.").withStyle(ChatFormatting.GRAY));
         TeamSelect.close();
         close();
      }
   }

   /** Teamwahl wieder oeffnen (wer eingeladen hat). */
   public static void openTeams(ServerPlayer p) {
      if (phase == Phase.TEAMS && p.getUUID().equals(host)) {
         TeamSelect.open(p);
      } else {
         p.sendSystemMessage(Component.literal("Gerade gibt es keine Teamwahl fuer dich.").withStyle(ChatFormatting.YELLOW));
      }
   }

   private static void close() {
      phase = Phase.IDLE;
      phaseEndsAt = -1;
      accepted.clear();
      declined.clear();
      invited.clear();
      host = null;
   }

   private static void maybeAllAnswered() {
      for (UUID id : invited) {
         if (!accepted.contains(id) && !declined.contains(id) && server.getPlayerList().getPlayer(id) != null) {
            return;
         }
      }

      phaseEndsAt = Math.min(phaseEndsAt, now() + 10);
   }

   // ====================================================================== Ablauf

   public static void tick(MinecraftServer srv) {
      server = srv;
      if (phase == Phase.IDLE) {
         return;
      }

      int left = phaseEndsAt - now();
      if (phase == Phase.INVITE) {
         if (left > 0 && left % 20 == 0) {
            for (ServerPlayer p : waiting()) {
               p.sendOverlayMessage(Component.literal("Bedwars: noch " + left / 20 + " s - klick im Chat auf [MITSPIELEN]").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
            }

            ServerPlayer h = hostPlayer();
            if (h != null) {
               h.sendOverlayMessage(Component.literal("Einladung laeuft: " + accepted.size() + " dabei, noch " + left / 20 + " s").withStyle(ChatFormatting.GOLD));
            }
         }

         if (left <= 0) {
            endInvite();
         }
      } else if (phase == Phase.TEAMS) {
         ServerPlayer h = hostPlayer();
         int action = TeamSelect.pollAction();
         if (action < 0 && h != null) {
            cancel(h);
         } else if (action > 0 && h != null) {
            teamsDone(TeamSelect.finish());
         } else if (h == null) {
            // der Gastgeber ist weg: zufaellig verteilen
            teamsDone(TeamSelect.finish());
         } else if (left <= 0) {
            tellLobby(Component.literal("Zeit um - die restlichen Spieler werden zufaellig verteilt.").withStyle(ChatFormatting.YELLOW));
            teamsDone(TeamSelect.finish());
         } else if (left % 20 == 0 && (left <= 200 || left % 200 == 0)) {
            h.sendOverlayMessage(Component.literal("Teams einteilen: noch " + left / 20 + " s").withStyle(ChatFormatting.GOLD));
         }
      } else if (phase == Phase.WHEEL) {
         MapWheel.tick();
      }
   }

   private static void endInvite() {
      List<ServerPlayer> ps = players(accepted);
      for (ServerPlayer p : waiting()) {
         p.sendSystemMessage(Component.literal("Die Einladung ist abgelaufen - du spielst diesmal nicht mit.").withStyle(ChatFormatting.GRAY));
      }

      if (ps.size() < 2) {
         if (ps.isEmpty()) {
            close();
            return;
         }

         ps.get(0).sendSystemMessage(Component.literal("Niemand hat angenommen - du spielst mit Bots.").withStyle(ChatFormatting.YELLOW));
         spin(ps, null);
         return;
      }

      ServerPlayer h = hostPlayer();
      if (h == null) {
         h = ps.get(0);
         host = h.getUUID();
      }

      phase = Phase.TEAMS;
      phaseEndsAt = now() + Config.teamSelectSeconds * 20;
      TeamSelect.begin(server, ps);
      for (ServerPlayer p : ps) {
         if (p != h) {
            p.sendSystemMessage(Component.literal("Du bist dabei! ").withStyle(ChatFormatting.GREEN)
               .append(Component.literal(h.getName().getString()).withStyle(ChatFormatting.GOLD))
               .append(Component.literal(" teilt jetzt die Teams ein ...").withStyle(ChatFormatting.GRAY)));
            Game.title(p, Component.literal("DU BIST DABEI").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
               Component.literal(h.getName().getString() + " teilt die Teams ein").withStyle(ChatFormatting.GRAY));
         }
      }

      h.sendSystemMessage(Component.literal(ps.size() + " Spieler sind dabei. Zieh die Koepfe in die Teams - freie Plaetze bekommen Bots. ").withStyle(ChatFormatting.YELLOW)
         .append(button("[Teams oeffnen]", "/bedwars teams", "Teamwahl wieder oeffnen", ChatFormatting.AQUA)));
      TeamSelect.open(h);
   }

   /** Die Teams stehen: jetzt das Gluecksrad. */
   static void teamsDone(Map<UUID, Integer> assignment) {
      if (phase != Phase.TEAMS) {
         return;
      }

      TeamSelect.close();
      List<ServerPlayer> ps = players(accepted);
      if (ps.isEmpty()) {
         tellLobby(Component.literal("Zu wenige Spieler uebrig - die Runde faellt aus.").withStyle(ChatFormatting.YELLOW));
         close();
         return;
      }

      spin(ps, assignment);
   }

   /** Allein mit Bots (nur Mod): direkt zum Gluecksrad. */
   public static void startSolo(ServerPlayer p) {
      server = p.level().getServer();
      if (phase != Phase.IDLE) {
         p.sendSystemMessage(Component.literal("Gerade wird schon eine Runde vorbereitet.").withStyle(ChatFormatting.YELLOW));
         return;
      }

      if (Game.running() && (Platform.get().isServerPlugin() || Game.multiplayer() || Game.human(p) == null)) {
         p.sendSystemMessage(Component.literal("Gerade laeuft schon eine Bedwars-Runde. Sobald sie vorbei ist, kannst du starten.").withStyle(ChatFormatting.YELLOW));
         return;
      }

      host = p.getUUID();
      accepted.clear();
      accepted.add(host);
      spin(List.of(p), null);
   }

   private static void spin(List<ServerPlayer> ps, Map<UUID, Integer> assignment) {
      phase = Phase.WHEEL;
      UUID hostId = host;
      MapWheel.start(ps, map -> {
         List<ServerPlayer> now = new ArrayList<>();
         for (ServerPlayer p : ps) {
            if (!p.hasDisconnected()) {
               now.add(p);
            }
         }

         close();
         if (now.isEmpty()) {
            for (ServerPlayer p : now) {
               p.sendSystemMessage(Component.literal("Zu wenige Spieler uebrig - die Runde faellt aus.").withStyle(ChatFormatting.YELLOW));
            }

            return;
         }

         ServerPlayer h = now.get(0);
         for (ServerPlayer p : now) {
            if (p.getUUID().equals(hostId)) {
               h = p;
            }
         }

         Game.roundHost = h.getUUID();
         ServerLevel level = Platform.get().arenaLevel(server, h);
         Game.startRound(server, level, Platform.get().arenaCenter(level, h), now, assignment, map, false);
      });
   }

   public static void onDisconnect(ServerPlayer p) {
      if (phase == Phase.IDLE) {
         return;
      }

      UUID id = p.getUUID();
      accepted.remove(id);
      invited.remove(id);
      TeamSelect.remove(id);
      if (id.equals(host) && phase == Phase.INVITE) {
         List<ServerPlayer> rest = players(accepted);
         rest.remove(p);
         if (rest.isEmpty()) {
            close();
         } else {
            host = rest.get(0).getUUID();
            tellLobby(Component.literal(rest.get(0).getName().getString() + " leitet jetzt die Einladung.").withStyle(ChatFormatting.GRAY));
         }
      }
   }

   /** Jemand kommt dazu, waehrend eingeladen oder gespielt wird. */
   public static void greetLateJoiner(ServerPlayer p) {
      if (phase == Phase.INVITE) {
         ServerPlayer h = hostPlayer();
         if (h != null) {
            invite(p, h);
         }
      } else if (!Platform.get().isServerPlugin()) {
         p.sendSystemMessage(Component.literal("Hier laeuft gerade eine Bedwars-Runde. Wenn sie vorbei ist, schreib ").withStyle(ChatFormatting.YELLOW)
            .append(Component.literal("/bedwars multiplayer").withStyle(ChatFormatting.GOLD))
            .append(Component.literal(", dann spielt ihr zusammen.").withStyle(ChatFormatting.YELLOW)));
      }
   }

   /** Kurzer Hinweis beim Betreten der Welt (nur Mod) - die Runde startet erst, wenn man es will. */
   public static void hint(ServerPlayer p) {
      p.sendSystemMessage(Component.literal("GlowCube Bedwars ist bereit. ").withStyle(ChatFormatting.GOLD)
         .append(button("[▶ ALLEIN MIT BOTS]", "/bedwars start", "Runde mit 19 Bots starten", ChatFormatting.GREEN))
         .append(Component.literal("  "))
         .append(button("[MULTIPLAYER]", "/bedwars multiplayer", "Alle auf dem Server einladen", ChatFormatting.AQUA)));
   }

   /** Wie man eine neue Runde startet (Text fuer Nachrichten). */
   public static String newRoundHint() {
      return "/bedwars start (allein mit Bots) oder /bedwars multiplayer";
   }

   // ====================================================================== Texte

   static MutableComponent lineup(Game.Human me) {
      MutableComponent line = Component.literal("Dein Team: ").withStyle(ChatFormatting.GRAY);
      boolean first = true;

      for (Game.Human h : me.team.humans) {
         line.append(Component.literal((first ? "" : ", ") + h.name).withStyle(me.team.team.format, ChatFormatting.BOLD));
         first = false;
      }

      for (BotProfile b : me.team.bots) {
         line.append(Component.literal((first ? "" : ", ") + b.name + " (Bot)").withStyle(me.team.team.format));
         first = false;
      }

      List<Game.Human> rivals = new ArrayList<>();
      for (Game.Human h : Game.humans()) {
         if (h.team != me.team) {
            rivals.add(h);
         }
      }

      if (!rivals.isEmpty()) {
         line.append(Component.literal("\nEchte Gegner: ").withStyle(ChatFormatting.GRAY));
         for (int i = 0; i < rivals.size(); i++) {
            Game.Human r = rivals.get(i);
            line.append(Component.literal((i == 0 ? "" : ", ") + r.name + " (" + r.team.team.label + ")").withStyle(r.team.team.format));
         }
      }

      return line;
   }

   static MutableComponent scoreboard() {
      List<Game.Human> list = new ArrayList<>(Game.humans());
      list.sort(Comparator.comparingInt((Game.Human h) -> h.kills + h.finals * 2 + h.beds * 3).reversed());
      MutableComponent c = header("ERGEBNIS");

      for (int i = 0; i < list.size(); i++) {
         Game.Human h = list.get(i);
         c.append(Component.literal("\n" + (i + 1) + ". ").withStyle(i == 0 ? ChatFormatting.GOLD : ChatFormatting.GRAY))
            .append(Component.literal(h.name).withStyle(h.team.team.format, ChatFormatting.BOLD))
            .append(Component.literal("  " + h.kills + " Kills, " + h.finals + " Finals, " + h.beds + " Betten, " + h.deaths + " Tode").withStyle(ChatFormatting.GRAY));
      }

      return c;
   }

   static MutableComponent rematchButton() {
      return Component.literal("Nochmal? ").withStyle(ChatFormatting.GRAY)
         .append(button("[↻ NEUE RUNDE]", "/bedwars multiplayer", "Alle wieder einladen", ChatFormatting.GOLD));
   }

   static MutableComponent header(String title) {
      return Component.literal("━━━━━ " + title + " ━━━━━").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
   }

   static MutableComponent button(String label, String command, String hover, ChatFormatting color) {
      return Component.literal(label).withStyle(s -> s.withColor(color).withBold(true)
         .withClickEvent(new ClickEvent.RunCommand(command))
         .withHoverEvent(new HoverEvent.ShowText(Component.literal(hover))));
   }

   static void tellLobby(Component msg) {
      Set<UUID> to = new LinkedHashSet<>(invited);
      to.addAll(accepted);
      for (ServerPlayer p : players(to)) {
         p.sendSystemMessage(msg);
      }
   }

   private static List<ServerPlayer> waiting() {
      List<ServerPlayer> list = new ArrayList<>();
      for (UUID id : invited) {
         if (!accepted.contains(id) && !declined.contains(id)) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) {
               list.add(p);
            }
         }
      }

      return list;
   }

   static List<ServerPlayer> players(Set<UUID> ids) {
      List<ServerPlayer> list = new ArrayList<>();
      if (server != null) {
         for (UUID id : ids) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null && !p.hasDisconnected()) {
               list.add(p);
            }
         }
      }

      return list;
   }

   static boolean isHost(ServerPlayer p) {
      return p.getUUID().equals(host);
   }

   private static ServerPlayer hostPlayer() {
      return host == null || server == null ? null : server.getPlayerList().getPlayer(host);
   }

   static void ping(ServerPlayer p, float pitch) {
      p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.NOTE_BLOCK_PLING, SoundSource.MASTER, 1.0F, pitch);
   }
}
