package de.glowcube.bedwars.paper;

import de.glowcube.bedwars.BwCommands;
import de.glowcube.bedwars.BwItems;
import de.glowcube.bedwars.Config;
import de.glowcube.bedwars.Game;
import de.glowcube.bedwars.Platform;
import de.glowcube.bedwars.Shop;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.nio.file.Path;
import java.util.List;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import org.bukkit.Bukkit;
import org.bukkit.GameRules;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.damage.CraftDamageSource;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Das Paper-Plugin: derselbe Spielcode wie die Mod, aber nur Multiplayer. Die Arena steht in einer
 * eigenen, leeren Welt ("bedwars_arena") - so wird auf dem SMP nichts kaputt gemacht. Nach der Runde
 * verschwindet die Karte samt Loot, und jeder bekommt Inventar, Ort, Leben, Erfahrung und Effekte zurueck.
 */
public final class BedwarsPlugin extends JavaPlugin implements Listener, TabExecutor {
   static final String WORLD = "bedwars_arena";
   private boolean internalTeleport;

   @Override
   public void onEnable() {
      Platform.set(new PaperPlatform());
      Config.load();
      Bukkit.getPluginManager().registerEvents(this, this);
      for (String name : new String[]{"bedwars", "@"}) {
         var cmd = this.getCommand(name);
         if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
         }
      }

      // erst nach dem Serverstart: Arena-Welt laden und den Takt starten
      Bukkit.getScheduler().runTask(this, () -> {
         arenaWorld();
         for (Player p : Bukkit.getOnlinePlayers()) {
            Game.onJoin(handle(p), server());
         }
      });
      Bukkit.getScheduler().runTaskTimer(this, () -> {
         try {
            Game.tick(server());
            Game.afterTick();
         } catch (Throwable t) {
            this.getLogger().severe("Fehler im Bedwars-Takt: " + t);
            t.printStackTrace();
            try {
               Game.stop(true);
            } catch (Throwable ignored) {
            }
         }
      }, 1L, 1L);
      this.getLogger().info("GlowCube Bedwars bereit - /bedwars multiplayer");
   }

   @Override
   public void onDisable() {
      // Server stoppt oder Plugin wird entladen: alle bekommen ihre Sachen zurueck
      try {
         Game.onServerStopping();
      } catch (Throwable t) {
         this.getLogger().severe("Fehler beim Beenden der Runde: " + t);
      }
   }

   static MinecraftServer server() {
      return ((CraftServer)Bukkit.getServer()).getServer();
   }

   static ServerPlayer handle(Player p) {
      return ((CraftPlayer)p).getHandle();
   }

   World arenaWorld() {
      World w = Bukkit.getWorld(WORLD);
      if (w == null) {
         w = new WorldCreator(WORLD).generator(new VoidGenerator()).generateStructures(false).createWorld();
         this.getLogger().info("Arena-Welt '" + WORLD + "' angelegt.");
      }

      if (w != null) {
         w.setGameRule(GameRules.ADVANCE_TIME, false);
         w.setGameRule(GameRules.ADVANCE_WEATHER, false);
         w.setGameRule(GameRules.SPAWN_MOBS, false);
         w.setGameRule(GameRules.SPAWN_MONSTERS, false);
         w.setGameRule(GameRules.SPAWN_PATROLS, false);
         w.setGameRule(GameRules.SPAWN_PHANTOMS, false);
         w.setGameRule(GameRules.SPAWN_WANDERING_TRADERS, false);
         w.setGameRule(GameRules.SHOW_DEATH_MESSAGES, false);
         w.setGameRule(GameRules.SHOW_ADVANCEMENT_MESSAGES, false);
         w.setGameRule(GameRules.KEEP_INVENTORY, true);
         w.setGameRule(GameRules.IMMEDIATE_RESPAWN, true);
         w.setGameRule(GameRules.MOB_GRIEFING, false);
         w.setGameRule(GameRules.SPREAD_VINES, false);
         w.setGameRule(GameRules.RANDOM_TICK_SPEED, 0);
         w.setGameRule(GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER, 0);
         w.setGameRule(GameRules.LOCATOR_BAR, false);
         w.setGameRule(GameRules.SPECTATORS_GENERATE_CHUNKS, false);
         w.setTime(6000L);
         w.setStorm(false);
         w.setAutoSave(false);
         w.setSpawnLocation(0, 200, 0);
      }

      return w;
   }

   static Location loc(ServerLevel level, double x, double y, double z, float yaw, float pitch) {
      return new Location(world(level), x, y, z, yaw, pitch);
   }

   /** Die Bukkit-Welt zu einer Minecraft-Welt (ohne Paper-eigene Methoden, die es nicht in jedem Build gibt). */
   static World world(ServerLevel level) {
      for (World w : Bukkit.getWorlds()) {
         if (((CraftWorld)w).getHandle() == level) {
            return w;
         }
      }

      return Bukkit.getWorlds().get(0);
   }

   static Player bukkit(ServerPlayer p) {
      return Bukkit.getPlayer(p.getUUID());
   }

   private static java.lang.reflect.Field activatedTick;
   private static java.lang.reflect.Method targetWithReason;
   private static boolean reflected;

   private static void reflect() {
      if (reflected) {
         return;
      }

      reflected = true;
      try {
         activatedTick = net.minecraft.world.entity.Entity.class.getField("activatedTick");
      } catch (Throwable ignored) {
         activatedTick = null;
      }

      try {
         targetWithReason = net.minecraft.world.entity.Mob.class.getMethod("setTarget", net.minecraft.world.entity.LivingEntity.class,
            org.bukkit.event.entity.EntityTargetEvent.TargetReason.class);
      } catch (Throwable ignored) {
         targetWithReason = null;
      }
   }

   // ====================================================================== Befehle

   @Override
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      ServerPlayer p = sender instanceof Player pl ? handle(pl) : null;
      if (command.getName().equals("@")) {
         if (p == null) {
            sender.sendMessage("Nur fuer Spieler.");
         } else {
            try {
               de.glowcube.bedwars.BotCommands.run(p, args);
            } catch (Throwable t) {
               sender.sendMessage("Fehler: " + t);
               this.getLogger().severe("Fehler bei /@ " + String.join(" ", args) + ": " + t);
            }
         }

         return true;
      }

      boolean admin = sender.hasPermission("bedwars.admin");
      ServerLevel level = p != null ? p.level() : server().overworld();
      BwCommands.Source src = new BwCommands.Source(server(), p, level, p != null ? p.blockPosition() : BlockPos.ZERO, admin, msg -> {
         if (p != null) {
            p.sendSystemMessage(msg);
         } else {
            sender.sendMessage(msg.getString());
         }
      });

      try {
         BwCommands.run(src, args);
      } catch (Throwable t) {
         sender.sendMessage("Fehler: " + t);
         this.getLogger().severe("Fehler bei /bedwars " + String.join(" ", args) + ": " + t);
         t.printStackTrace();
      }

      return true;
   }

   @Override
   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (command.getName().equals("@")) {
         return de.glowcube.bedwars.BotCommands.suggest(sender instanceof Player pl ? handle(pl) : null, args);
      }

      return BwCommands.suggest(args, sender.hasPermission("bedwars.admin"));
   }

   // ====================================================================== Ereignisse

   @EventHandler
   public void onJoin(PlayerJoinEvent e) {
      Player pl = e.getPlayer();
      Bukkit.getScheduler().runTaskLater(this, () -> {
         if (pl.isOnline()) {
            Game.onJoin(handle(pl), server());
         }
      }, 2L);
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent e) {
      Game.onDisconnect(handle(e.getPlayer()));
   }

   @EventHandler
   public void onRespawn(PlayerRespawnEvent e) {
      ServerPlayer old = handle(e.getPlayer());
      if (Game.running() && Game.isHuman(old) && Game.arena() != null) {
         var spawn = Game.teamOfPlayer(old).island().spawn();
         e.setRespawnLocation(loc(Game.arena().level, spawn.x, spawn.y + 8.0, spawn.z, 0.0F, 0.0F));
      }

      Player pl = e.getPlayer();
      Bukkit.getScheduler().runTask(this, () -> {
         if (pl.isOnline()) {
            Game.onRespawn(handle(pl));
         }
      });
   }

   /** Toedlicher Schaden in der Runde: kein echter Tod, sondern Bedwars-Tod (Wiederbeleben oder Zuschauen). */
   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onDamage(EntityDamageEvent e) {
      if (!Game.running()) {
         return;
      }

      net.minecraft.world.entity.Entity nms = ((CraftEntity)e.getEntity()).getHandle();
      if (!(nms instanceof net.minecraft.world.entity.LivingEntity le)) {
         return;
      }

      DamageSource src = ((CraftDamageSource)e.getDamageSource()).getHandle();
      if (!Game.allowDamage(le, src)) {
         e.setCancelled(true);
         return;
      }

      if (nms instanceof ServerPlayer sp && Game.isHuman(sp) && e.getFinalDamage() >= sp.getHealth() + sp.getAbsorptionAmount()
         && !sp.getMainHandItem().is(net.minecraft.world.item.Items.TOTEM_OF_UNDYING) && !sp.getOffhandItem().is(net.minecraft.world.item.Items.TOTEM_OF_UNDYING)) {
         e.setCancelled(true);
         Game.onDeath(sp, src);
      }
   }

   /** Falls doch jemand richtig stirbt (z.B. /kill): nichts fallen lassen, beim Wiederbeleben greift die Runde. */
   @EventHandler(priority = EventPriority.HIGHEST)
   public void onPlayerDeath(PlayerDeathEvent e) {
      if (Game.running() && Game.isHuman(handle(e.getEntity()))) {
         e.setKeepInventory(false);
         e.getDrops().clear();
         e.setDroppedExp(0);
         e.setKeepLevel(true);
         e.deathMessage(null);
      }
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onBreak(BlockBreakEvent e) {
      var b = e.getBlock();
      ServerPlayer p = handle(e.getPlayer());
      BlockPos pos = new BlockPos(b.getX(), b.getY(), b.getZ());
      ServerLevel level = ((CraftWorld)b.getWorld()).getHandle();
      if (Game.running() && level == Game.arena().level && !Game.onPlayerBreak(p, pos, level.getBlockState(pos))) {
         e.setCancelled(true);
      } else if (!Game.running() && b.getWorld().getName().equals(WORLD) && !e.getPlayer().hasPermission("bedwars.admin")) {
         e.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent e) {
      var b = e.getBlock();
      if (!b.getWorld().getName().equals(WORLD)) {
         return;
      }

      ServerPlayer p = handle(e.getPlayer());
      if (!Game.allowPlace(p, new BlockPos(b.getX(), b.getY(), b.getZ())) && !e.getPlayer().hasPermission("bedwars.admin")) {
         e.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGH)
   public void onInteractEntity(PlayerInteractEntityEvent e) {
      if (Game.running() && e.getRightClicked().getScoreboardTags().contains("bw_shop")) {
         e.setCancelled(true);
         if (e.getHand() == EquipmentSlot.HAND) {
            Shop.open(handle(e.getPlayer()));
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGH)
   public void onInteract(PlayerInteractEvent e) {
      if (!Game.running() || e.getHand() == null || e.getItem() == null) {
         return;
      }

      Action a = e.getAction();
      if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) {
         return;
      }

      ServerPlayer p = handle(e.getPlayer());
      InteractionHand hand = e.getHand() == EquipmentSlot.OFF_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
      boolean handled = false;
      if (a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null) {
         var b = e.getClickedBlock();
         handled = BwItems.onUseOnBlock(p, hand, new BlockPos(b.getX(), b.getY(), b.getZ()), CraftBlock.blockFaceToNotch(e.getBlockFace()));
      }

      if (!handled) {
         handled = BwItems.onUse(p, hand);
      }

      if (handled) {
         e.setUseItemInHand(Event.Result.DENY);
         e.setUseInteractedBlock(Event.Result.DENY);
         e.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onChat(AsyncChatEvent e) {
      String text = PlainTextComponentSerializer.plainText().serialize(e.message());
      Player pl = e.getPlayer();
      boolean teamChat = text.startsWith("@") && Game.running() && Game.isHuman(handle(pl));
      if (teamChat) {
         // Teamchat geht nicht an den ganzen Server
         e.setCancelled(true);
      }

      Bukkit.getScheduler().runTask(this, () -> {
         if (!pl.isOnline()) {
            return;
         }

         ServerPlayer p = handle(pl);
         if (teamChat) {
            Game.allowChat(p, text);
         } else {
            Game.onChat(p, text);
         }
      });
   }

   /** Mitspieler duerfen waehrend der Runde nicht per /home, /spawn, /tpa ... aus der Arena verschwinden. */
   /**
    * Unsere eigenen Teleports (in die Arena und zurueck) duerfen andere Plugins nicht abbrechen - sonst bleibt
    * man stehen. Laeuft als letztes (HIGHEST) und hebt eine Absage wieder auf.
    */
   @EventHandler(priority = EventPriority.HIGHEST)
   public void onTeleport(PlayerTeleportEvent e) {
      if (this.internalTeleport) {
         e.setCancelled(false);
         return;
      }

      if (e.isCancelled() || !Game.running()) {
         return;
      }

      ServerPlayer p = handle(e.getPlayer());
      if (Game.isHuman(p) && e.getTo() != null && !e.getTo().getWorld().getName().equals(WORLD)) {
         e.setCancelled(true);
         e.getPlayer().sendMessage("Du bist gerade in einer Bedwars-Runde. Verlassen: /bedwars verlassen");
      }
   }

   /** In der Arena entsteht kein Feuer (Feuerkugeln sind dort Feuerbaelle). */
   @EventHandler(ignoreCancelled = true)
   public void onIgnite(org.bukkit.event.block.BlockIgniteEvent e) {
      if (e.getBlock().getWorld().getName().equals(WORLD)) {
         e.setCancelled(true);
      }
   }

   @EventHandler(ignoreCancelled = true)
   public void onSpawn(CreatureSpawnEvent e) {
      if (e.getLocation().getWorld().getName().equals(WORLD) && e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL) {
         e.setCancelled(true);
      }
   }

   /** Die Arena-Welt: leer, ohne Gelaende, Strukturen oder Mobs. */
   static final class VoidGenerator extends ChunkGenerator {
   }

   /** Paper: Arena in eigener Welt, Teleport ueber Bukkit (auch zwischen Welten). */
   final class PaperPlatform implements Platform {
      @Override
      public Path configDir() {
         return BedwarsPlugin.this.getDataFolder().toPath();
      }

      @Override
      public boolean isServerPlugin() {
         return true;
      }

      @Override
      public ServerLevel arenaLevel(MinecraftServer server, ServerPlayer host) {
         World w = arenaWorld();
         return w == null ? server.overworld() : ((CraftWorld)w).getHandle();
      }

      @Override
      public BlockPos arenaCenter(ServerLevel level, ServerPlayer host) {
         return BlockPos.ZERO;
      }

      @Override
      public boolean teleport(ServerPlayer p, ServerLevel level, double x, double y, double z, float yaw, float pitch) {
         internalTeleport = true;
         try {
            // nichts darf den Teleport aufhalten: absteigen, Menue zu, Mitfahrer runter
            p.stopRiding();
            p.ejectPassengers();
            p.closeContainer();
            Player bp = bukkit(p);
            boolean ok = bp != null && bp.teleport(loc(level, x, y, z, yaw, pitch), PlayerTeleportEvent.TeleportCause.PLUGIN);
            if (!arrived(p, level, x, y, z)) {
               // zweiter Versuch direkt ueber Minecraft
               p.teleportTo(level, x, y, z, java.util.Set.of(), yaw, pitch, true);
            }

            boolean there = arrived(p, level, x, y, z);
            if (!there) {
               BedwarsPlugin.this.getLogger().warning("Teleport von " + p.getName().getString() + " nach " + world(level).getName()
                  + " ist fehlgeschlagen (Bukkit: " + ok + "). Blockiert ein anderes Plugin Teleports in diese Welt?");
            }

            return there;
         } finally {
            internalTeleport = false;
         }
      }

      private boolean arrived(ServerPlayer p, ServerLevel level, double x, double y, double z) {
         return p.level() == level && p.position().distanceToSqr(x, y, z) < 4.0;
      }

      @Override
      public net.minecraft.world.Difficulty difficulty(ServerLevel level) {
         return level.getDifficulty();
      }

      @Override
      public void setDifficulty(ServerLevel level, net.minecraft.world.Difficulty d) {
         world(level).setDifficulty(org.bukkit.Difficulty.getByValue(d.getId()));
      }

      @Override
      public void keepTicking(net.minecraft.world.entity.Entity e) {
         reflect();
         if (activatedTick != null) {
            try {
               activatedTick.setLong(e, Long.MAX_VALUE / 2);
            } catch (Throwable ignored) {
            }
         }
      }

      @Override
      public void setTarget(net.minecraft.world.entity.Mob mob, net.minecraft.world.entity.LivingEntity target) {
         reflect();
         if (targetWithReason != null) {
            try {
               targetWithReason.invoke(mob, target, org.bukkit.event.entity.EntityTargetEvent.TargetReason.CUSTOM);
               return;
            } catch (Throwable ignored) {
            }
         }

         mob.setTarget(target);
      }

      @Override
      public void remove(net.minecraft.world.entity.Entity e) {
         e.discard();
      }

      @Override
      public boolean isAdmin(ServerPlayer p) {
         Player bp = bukkit(p);
         return bp != null && bp.hasPermission("bedwars.admin");
      }

      @Override
      public boolean isArenaWorld(ServerLevel level) {
         return world(level).getName().equals(WORLD);
      }

      @Override
      public void sendHome(ServerPlayer p) {
         World main = Bukkit.getWorlds().get(0);
         internalTeleport = true;
         try {
            Player bp = bukkit(p);
            if (bp != null) {
               bp.teleport(main.getSpawnLocation(), PlayerTeleportEvent.TeleportCause.PLUGIN);
            }
         } finally {
            internalTeleport = false;
         }
      }

      @Override
      public void log(String msg) {
         BedwarsPlugin.this.getLogger().info(msg);
      }
   }
}
