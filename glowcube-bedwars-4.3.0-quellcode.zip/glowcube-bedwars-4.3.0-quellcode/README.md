# GlowCube Bedwars 4.3 – Fabric-Mod und Paper-Plugin für Minecraft 26.3

Fünf Teams mit je vier Spielern; alle Plätze ohne echte Spieler spielen Bots.
Den Spielcode gibt es zweimal:

| Datei | Für | Was geht |
| --- | --- | --- |
| `dist/glowcube-bedwars-4.3.0.jar` | Fabric (Einzelspieler, LAN, Essential) | allein mit Bots **und** Multiplayer |
| `dist/glowcube-bedwars-paper-4.3.0.jar` | Paper-Server 26.3 (z. B. dein SMP) | allein mit Bots **und** Multiplayer |

![Alle Karten](docs/karten/alle_karten.png)

## Neu in 4.3: Bots, die wie Menschen spielen

### Jeder Bot ist ein anderer Spieler

* Jeder Bot hat drei eigene Talente: **PvP**, **Bauen** und **Übersicht** (jeweils 1 bis 10). Sie werden
  bei jedem Bot neu ausgewürfelt. Es gibt also den Bauprofi, der im Kampf schwächelt, und den PvP-Spieler,
  der beim Brückenbauen öfter danebenliegt.
* Aus den Talenten ergibt sich alles andere: Reaktionszeit, Zielen, Klick-Tempo, Strafen, W-Tap, Crits,
  Tempo beim Brückenbau, Clutchen, wie oft er ausweicht oder einen Feuerball zurückschlägt, wie schnell er
  die Waffe wechselt und ob er beim Laufen springt.
* Die Schwierigkeit verschiebt nur den Durchschnitt. Auch auf „Schwer“ gibt es mal einen schwächeren Bot,
  auf „Leicht“ mal einen guten.
* **Lieblings-Item:** Fast jeder Bot hat ein Lieblings-Item, z. B. Feuerball, Bogen, TNT, Pop-Up-Turm,
  Rückstoß-Stock, Bettwanze oder Tempotrank, und kauft es früher als andere. Manche sogar vor der Rüstung.
* **Sammeln wie ein Spieler:** Bots laufen über die Spawner-Fläche und sammeln alles ein. Vorher blieb Eisen in der
  Mitte liegen, bis der Spawner voll war. Steht ein echter Teamkollege am Spawner, lassen sie ihm weiterhin den Vortritt.
* Ansehen: `/bedwars status` zeigt jeden Bot mit Talenten und Trefferquote, `/@ <name> ausruestung` zeigt,
  was er dabei hat und welches Lieblings-Item er hat.

### Jedes Team baut sein Bett anders ein

* Wer im Team zuerst baut, entscheidet die Bauweise. Es gibt 9: nur Wolle, doppelt Wolle,
  Wolle + Endstein, Wolle + Terrakotta, nur Endstein, Wolle/Endstein/Holz, Glas/Endstein/Wolle,
  Holz/Endstein/Glas und Obsidian/Endstein/Holz. Gute Bauer nehmen eher die aufwendigen Varianten.
* **Manche machen Wasser aufs Bett, manche nicht.** Das Wasser kommt in die zweite Schicht und kann nicht
  auslaufen. Es schützt vor TNT und Feuerbällen und macht das Abbauen langsamer. Fließt trotzdem einmal
  Wasser über den Rand, wird es unter der Insel abgefangen.
* Der Bauer spart für sein Material und kauft es zuerst. Reicht das Geld noch nicht, nimmt er erst Wolle,
  wie ein echter Spieler. Später **tauscht er die Wolle gegen Endstein, Glas, Holz oder Obsidian aus**.
  Innere Schichten reißt er dafür nicht auf.
* Im Chat sagt er manchmal, wie er baut („ich bau unser bett mit wolle und endstein ein“).

### Alle Items, wie ein Spieler

Zusätzlich zu Feuerball, TNT, Pop-Up-Turm, Brücken-Ei, Perle, Golem, Bettwanze, Milch und Tempotrank:

* **Feuerbälle zurückschlagen:** Fliegt ein Feuerball auf ihn zu, schlägt ein guter Bot ihn zurück.
* **Ausweichen:** Pfeilen und Schneebällen weicht er seitlich aus. Mit **Schild** blockt er Pfeile.
* **Schneebälle** gegen Gegner, die gerade eine Brücke bauen (runterschubsen).
* **Schwamm:** Liegt Wasser auf dem gegnerischen Bett, saugt er es vorher weg.
* **Axt** gegen Holz in der Verteidigung, **Spitzhacke** gegen Endstein, **Schere** gegen Wolle.
* **Feuerball auf Wolle:** Ist die gegnerische Verteidigung aus Wolle, sprengt er sie mit einem Feuerball auf.
* **Unsichtbarkeitstrank** für leise Angriffe (sein Name verschwindet dann auch).
* **Power-Bogen** für Fernkampf, **Enderperle zur Flucht**, wenn ein Kampf verloren ist.

### Menschlicher im Kampf

* Er springt beim Sprinten, wechselt die Waffe nicht sofort, vergisst manchmal den Goldapfel und
  verschätzt sich mal an der Kante, je nach Talent.
* Weiterhin **keine Kill-Aura:** Er trifft nur über die echte Hitbox, mit begrenzter Drehgeschwindigkeit,
  Reaktionszeit und Zittern.

## Neu in 4.0

### Ablauf einer Runde

1. Jemand tippt **`/bedwars multiplayer`**.
2. **Alle** auf dem Server bekommen eine Chat-Nachricht mit **[✔ MITSPIELEN]**, Titel und Ton.
   Wer **innerhalb von 10 Sekunden** nicht klickt, ist nicht dabei (einstellbar).
3. Wer eingeladen hat, bekommt die **Teamwahl**: eine Kiste mit den **Köpfen aller Mitspieler**
   (Maus drauf = Name). Kopf anklicken, dann in ein Team klicken. Ziehen mit gedrückter Maus und
   Shift-Klick (automatisch) gehen auch. Jedes Team hat **4 Plätze**, mehr passen nicht rein.
   Knöpfe: **Zufällig verteilen**, **Alle zurücksetzen**, **Bot-Schwierigkeit**, **Abbrechen**, **▶ START**.
   Wer bei START noch kein Team hat, kommt ins leerste Team. Nach 60 Sekunden wird automatisch verteilt.
4. **Alle freien Plätze werden Bots**: Es spielen immer 5 Teams à 4 (max. 20 echte Spieler).
5. **Glücksrad**: In einer Kiste laufen alle 8 Karten durch, werden langsamer und bleiben unter dem
   Zeiger stehen. Die Wahl ist zufällig, aber die **letzte Karte kommt nie direkt nochmal**, die
   davor nur selten.
6. Die Runde läuft. Am Ende (auch bei `/bedwars stop`, Server-Stopp oder Plugin-Neuladen) **verschwindet
   alles**: Karte, Blöcke, Items am Boden, Pfeile, TNT, Golems. Jeder bekommt **Inventar
   (mit Rüstung und Zweithand), Ort, Spielmodus, Leben, Hunger, XP und Effekte** zurück.
   Wer offline ist oder wenn der Server abstürzt: zurück beim nächsten Betreten (die Sicherung liegt als
   Datei im Weltordner).

**`/bedwars start`** startet eine Runde allein mit 19 Bots (auch dort dreht sich vorher das Glücksrad).
Nimmt bei `/bedwars multiplayer` niemand an, spielst du ebenfalls allein mit Bots.

**`/bedwars stop`:** Wer die Runde gestartet hat, beendet sie damit für alle, und alle bekommen ihre Sachen
zurück. Tippt es ein anderer Mitspieler, geht nur er raus: Ein Bot übernimmt seinen Platz, und er steht mit
allen Sachen wieder dort, wo er vorher war. Wer die Verbindung verliert, wird ebenfalls durch einen Bot ersetzt.

### Befehle an deine Bots: `/@`

`/@ <wer> <befehl> [ziel]` (oder `/bot …`) – mit Tab-Vervollständigung für alles.

* **wer:** `alle`, `einer` (der nächste), `zwei` (die zwei nächsten) oder der Name eines Bots
* **Befehle (32):** verteidigen, bett-zubauen, angreifen `<team>`, rushen `<team>`, jagen `<team/spieler/bot>`,
  folgen, beschuetzen, komm, hierbleiben, warte, mitte, diamanten, sammeln, einkaufen,
  kaufen `<26 Items>`, upgrade `<6 Upgrades>`, rueckzug, heim, bruecke-abreissen, feuerball `<ziel>`,
  golem, turm, hochbauen, gib `<eisen/gold/diamanten/smaragde>`, aggressiv, vorsichtig, normal, frei,
  status, geld, ausruestung, hilfe
* Beispiele: `/@ alle verteidigen`, `/@ mila angreifen blau`, `/@ einer kaufen feuerball`,
  `/@ zwei folgen`, `/@ finn gib eisen`, `/@ alle frei`

Ein Befehl gilt etwa 90 Sekunden. Kommt ein Gegner ans Bett, verteidigen die Bots trotzdem.
Gekauft wird immer mit dem eigenen Geld des Bots.

### Paper-Plugin für deinen SMP

* JAR in `plugins/` legen, Server neu starten. Braucht **Paper 26.3** (läuft auf allen 26.3-Builds, getestet mit Build 3, 166, 239 und 242) und Java 25.
* Die Arena steht in einer **eigenen, leeren Welt `bedwars_arena`**. Auf deinem SMP wird nichts
  abgebaut oder überbaut. Die Welt hat feste Mittagszeit, keine Mobs und kein Wetter.
* Mitspieler können sich während der Runde nicht per `/home`, `/spawn`, `/tpa` usw. wegteleportieren
  (dafür gibt es `/bedwars verlassen`, dann ist sofort alles zurück). Wer nicht mitspielt, kann weder
  Bots noch Mitspieler schlagen und in der Arena nichts abbauen.
* Nachrichten der Runde (Kills, Betten, Bot-Chat) gehen nur an Mitspieler und Zuschauer, nicht an den ganzen Server.

| Befehl | Wer | Wirkung |
| --- | --- | --- |
| `/bedwars start` | alle | allein mit 19 Bots spielen |
| `/bedwars multiplayer` | alle | Runde starten: Einladung → Teamwahl → Glücksrad |
| `/bedwars ja` | alle | Einladung annehmen (oder auf [MITSPIELEN] klicken) |
| `/bedwars teams` / `los` / `abbrechen` | Gastgeber | Teamwahl wieder öffnen / sofort weiter / abbrechen |
| `/bedwars shop` | Mitspieler | Shop öffnen (oder Händler auf der Insel anklicken) |
| `/bedwars schwierigkeit <stufe>` | alle | leicht, normal, schwer oder profi (ab der nächsten Runde) |
| `/bedwars karten` | alle | alle Karten anzeigen |
| `/bedwars status` | alle | Teams, Betten, Bot-Stärke, was jeder Bot gerade macht |
| `/bedwars verlassen` | Mitspieler | Runde verlassen, sofort alles zurück |
| `/bedwars stop` | Gastgeber / Mitspieler / OP | Gastgeber oder OP: Runde für alle beenden – Mitspieler: nur selbst raus, ein Bot übernimmt |
| `/@ <wer> <befehl>` | Mitspieler | deinen Bots Befehle geben (siehe unten) |
| `/bedwars test [karte]` | `bedwars.admin` | reine Bot-Runde zum Ausprobieren |
| `/bedwars verteidigung` | `bedwars.admin` | zeigt, wie jedes Team sein Bett eingebaut hat (Material, Wasser) |
| `/bedwars reflex` | `bedwars.admin` | schießt 8 Feuerbälle auf den reaktionsschnellsten Bot und zählt, wie oft er zurückschlägt oder ausweicht (Ergebnis in der Server-Konsole) |

Kurzform: `/bw`. Einstellungen stehen in `plugins/GlowCubeBedwars/glowcube_bedwars.properties`
(Mod: `config/glowcube_bedwars.properties`):

```properties
schwierigkeit=normal
einladung_sekunden=10
teamwahl_sekunden=60
max_spieler=20
letzte_karten=3,0,5
```

`letzte_karten` pflegt das Plugin selbst (gegen Doppel beim Glücksrad).

### 8 Karten

| Karte | Stil |
| --- | --- |
| **Rom** (überarbeitet) | Marmor-Inseln, Säulen mit Team-Bannern, Statuen, Rundtempel mit Leuchtfeuer |
| **Kirschblütental** | Japanischer Garten: Kirschbäume, Steinlaternen, Torii-Tore, Pagode in der Mitte |
| **Wüstentempel** | Sandstein, Obelisken mit Goldspitze, Palmen, Sphinx-Wächter, Säulenring |
| **Frostgipfel** | Schnee, Tannen, Eiszacken, Schneemänner, gefrorener Brunnen |
| **Höllenfestung** | Schwarzstein, Basaltsäulen, Pilzbäume, Seelenlaternen, Festungsmauer |
| **Dschungelruinen** | Bemooste Tempel, Urwaldriesen, Totems, eingestürzte Säulen |
| **Ozeanpalast** | Prismarin, Meereslaternen, Conduits, Glaskuppel über der Mitte |
| **Endstadt** | Purpur-Türme, Endstäbe, Drachenkopf, Obsidian-Säulen |

Jede Karte hat eigene Inselabstände. Die **Spawner-Fläche ist jetzt 5×3 Blöcke groß**, die Barren
fallen verteilt auf die ganze Fläche. Bots stellen sich an den Rand, und **sobald ein echter
Teamkollege am Spawner steht, gehen sie zur Seite und sammeln nichts mehr auf**.

Vorschaubilder: `docs/karten/*.png` (erzeugt mit `/bedwars export` und `tools/render_maps.py`).

### Shop mit 9 Reitern und über 40 neuen Sachen

Reiter: Schnellkauf · Blöcke · Nahkampf · Rüstung · Werkzeuge · Fernkampf · Tränke · Extras · Team-Upgrades & Fallen.

* **Blöcke:** Wolle, Terrakotta, explosionsfestes Glas, Endstein, Leiter, Holz, Obsidian
* **Nahkampf:** Stein-/Eisen-/Diamantschwert, Rückstoß-Stock, Schild
* **Rüstung:** Ketten, Eisen, Diamant (bleibt nach dem Tod)
* **Werkzeuge:** Schere, 4 Spitzhacken, 4 Äxte (nach dem Tod eine Stufe weniger, die Schere bleibt)
* **Fernkampf:** Pfeile, Bogen, Bogen (Stärke I), Bogen (Stärke + Schlag), Schneebälle, Windkugeln, Angel
* **Tränke:** Tempo II, Sprungkraft V, Unsichtbarkeit (Bots bemerken dich erst ganz nah), Magische Milch
* **Extras:** Goldapfel, **Feuerball** (auch zum Feuerball-Springen), **TNT** (zündet sofort), Enderperle,
  Wassereimer, Schwamm, **Brücken-Ei**, **Pop-Up-Turm** (baut sich in Sekunden mit Leiter auf),
  **Bettwanze**, **Traumverteidiger** (Eisengolem, 4 Minuten), **Rettungsplattform**, **Spieler-Tracker**
* **Team-Upgrades (Diamanten):** Geschärfte Klingen, Verstärkte Rüstung I–IV, Wahnsinniger Bergarbeiter
  I–II, Eisenschmiede I–IV (ab III Smaragde auf der Insel), Heilfeld, Federfall-Stiefel
* **Fallen** (höchstens 3 in der Warteschlange, jede weitere teurer): „Es ist eine Falle!“, Gegenangriff,
  Alarm, Bergbau-Müdigkeit

Feuerball und TNT haben eine eigene Explosion: Sie sprengen nur gesetzte Blöcke (nie die Karte, das
Bett, Glas oder Obsidian) und verletzen keine Teamkollegen.

### Bessere Bots

* **Keine Blöcke mehr in der Luft:** Bots setzen Blöcke nur noch an andere Blöcke und in Reichweite,
  wie ein Spieler. Kein Hochbauen oder Clutchen aus dem Nichts mehr.
* **Fallen kaum noch runter:** Eine Kantensicherung bremst, bevor ein Bot ins Leere läuft (nur Anfänger
  passen manchmal nicht auf). Beim Brückenbau verschätzen sie sich viel seltener.
* **Kein Selbstmord mehr:** Vor einem Angriff prüft der Bot Leben, Goldäpfel, Ausrüstung und wie viele
  Verteidiger da sind. Während eines Angriffs, einer Jagd oder in der Mitte zieht er sich zurück, wenn
  er in der Unterzahl oder fast tot ist, außer er steht direkt am Bett und kann es gleich abbauen.
  Im Chat sagen sie dann z. B. „zu viele ich zieh mich zurück“.
* **Nicht mehr rumstehen:** Kommt ein Gegner über eine Brücke, stellen sich die Bots in der Nähe ans Bett.
  Ist der Gegner überlegen, **bauen sie sich am Bett hoch** (Höhenvorteil). Gegner auf der eigenen Insel
  bemerken sie fast immer.
* **Leben kommt zurück:** Außerhalb vom Kampf regenerieren Bots langsam (wie Spieler mit vollem Hunger).
* **Unterschiedlich stark:** Jedes Bot-Team ist eine Stufe stärker, gleich stark oder eine Stufe schwächer
  als die eingestellte Schwierigkeit (steht in `/bedwars status`). Deine eigenen Bot-Kollegen sind immer
  genau so stark wie eingestellt.
* **Eigenes Geld, ehrlich gekauft:** Jeder Bot hat seine eigene Geldbörse. Er muss Eisen, Gold, Diamanten
  und Smaragde selbst aufsammeln (oder einem Gegner beim Kill abnehmen), zum Händler auf seiner Insel laufen
  und dort zu denselben Preisen wie du einkaufen. Ein Bot kann nicht das Geld eines anderen ausgeben, und
  auch Team-Upgrades und Fallen kauft ein Bot nur am Händler mit seinen eigenen Diamanten. Stirbt er, ist
  sein Geld weg (der Gegner bekommt es).
* **Bots benutzen die Items:** Feuerbälle, Bogen und Pfeile, Bettwanzen, Rückstoß-Stock (an der Kante),
  TNT an der Bett-Verteidigung, Brücken-Ei und Enderperle (wenn die Blöcke nicht reichen), Tempotrank
  vor dem Angriff, Magische Milch vor einer Insel mit Fallen, Traumverteidiger und Pop-Up-Turm zur
  Verteidigung, Rettungsplattform beim Fallen, Obsidian ums Bett und Goldäpfel.
* **Bett-Reflex:** Steht ein Gegner an eurem Bett, lassen alle Bots in der Nähe alles fallen und verteidigen.
  Gegner auf der eigenen Insel bemerkt jeder Bot, der zu Hause ist. Echte Spieler und Bots werden dabei gleich
  behandelt (vorher haben Bots echte Spieler bevorzugt angegriffen).
* **Gemeinsam statt einzeln:** Kämpft ein Teamkollege schon gegen einen Gegner, gehen die anderen eher auf denselben.
* **Weiterhin keine Kill-Aura:** Reaktionszeit, begrenzte Drehgeschwindigkeit, Zittern, Treffer nur über
  die echte Hitbox und Klick-Rhythmus sind unverändert. Die Bots kämpfen nicht stärker als vorher.

## Weiterhin dabei (aus 3.x)

* Bots als Spielermodelle (Steve/Alex) mit **Spielertypen** (Anfänger, Gelegenheitsspieler, solide,
  Schwitzer), A*-Wegsuche mit Brücken, Hochbauen und Abbauen, Bett zubauen, Brücken abreißen.
* Ein kleines **neuronales Netz** für die Strategie, dazu ein Gegner-Modell (Rusher, Bunker, Wirtschaft).
* **Chat-KI:** Die Bots bilden eigene Sätze, jeder hat seinen Schreibstil, und sie verstehen Befehle:

| Du schreibst (zum Beispiel) | Deine Teamkollegen … |
| --- | --- |
| „verteidigt mal unser bett" | bleiben am Bett |
| „greift blau an", „lasst uns gelb rushen" | greifen dieses Team an |
| „kommt mit", „folgt mir mal" | laufen hinter dir her |
| „hilfe", „kommt schnell her" | kommen zu dir |
| „holt dias", „wir brauchen smaragde" | gehen in die Mitte |
| „baut das bett zu" | bauen die Verteidigung neu |
| „kauft euch was", „holt euch rüstung" | gehen einkaufen |
| „was ist der plan" | erklären, was das Team vorhat |
| „wo seid ihr" / „wie viel eisen habt ihr" | sagen, wo sie sind / was das Team hat |
| „stop", „macht was ihr wollt" | machen wieder ihr eigenes Ding |

* Teamchat mit `@` vor der Nachricht. Nach 12 Minuten fallen alle Betten, ab 15 Minuten ist Sudden Death.

## Aufbau

| Ordner / Datei | Inhalt |
| --- | --- |
| `src/common/…` | der gesamte Spielcode (für Mod und Plugin gleich) |
| `Platform` | was sich zwischen Fabric und Paper unterscheidet |
| `Game`, `Arena`, `MapTheme` | Runde, Karte, die 8 Kartenthemen |
| `Lobby`, `TeamSelect`, `MapWheel` | Einladung, Teamwahl mit Köpfen, Glücksrad |
| `Shop`, `BwItems`, `BwEntities` | Shop, Spezial-Items, Feuerball/TNT/Golem/Bettwanze/Brücken-Ei |
| `BedwarsBot`, `TeamBrain`, `Hands`, `Pathfinder` | Bot-Körper, Strategie, Spielertyp, Wegsuche |
| `src/fabric/…` | Einstieg der Mod (Fabric-Ereignisse, Befehl) |
| `src/paper/…` | Einstieg des Plugins (Bukkit-Ereignisse, Befehl, Arena-Welt) |

## Bauen

```bash
./build.sh          # beides
./build.sh fabric   # nur dist/glowcube-bedwars-4.3.0.jar
./build.sh paper    # nur dist/glowcube-bedwars-paper-4.3.0.jar
```

Voraussetzungen: JDK 25, `curl`, `unzip`, `zip`. Minecraft 26.x und Paper 26.x sind unverschleiert,
deshalb reicht `javac` (ohne Gradle, Loom oder paperweight). Das Skript lädt Minecraft, Fabric und
Paper einmalig nach `.build/`.

Das Netz neu trainieren (braucht Python 3 mit numpy und einen Fabric-Server mit der Mod,
dessen Konsole an einer FIFO hängt):

```bash
python3 tools/train_brain.py teacher --console server/console.in --work /tmp/bw --games 30
python3 tools/train_brain.py clone   --console server/console.in --work /tmp/bw
python3 tools/train_brain.py evolve  --console server/console.in --work /tmp/bw \
    --bias-only --vs-rules --out brain_tuned.json --generations 15 --sigma 0.3 --lr 0.4 --pairs 4
python3 tools/train_brain.py eval    --console server/console.in --work /tmp/bw --games 30 --candidate brain_tuned.json
cp /tmp/bw/brain_tuned.json resources/assets/glowcube_bedwars/brain.json
```
