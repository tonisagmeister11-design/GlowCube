package de.glowcube.bedwars;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.decoration.Mannequin;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.hurtingprojectile.LargeFireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Der Koerper eines Bots: ein Spielermodell (Steve oder Alex) mit eigener Steuerung.
 * Er laeuft ueber den A*-Pfad, baut Bruecken, baut hoch, baut Verteidigungen ab,
 * kaempft mit Strafen, Krits und W-Tap, isst Goldaepfel und rettet sich mit Clutch-Bloecken.
 */
public final class BedwarsBot extends Mannequin {
   private static final Random RND = new Random();
   private static final float DEG = (float)(Math.PI / 180.0);
   private static EntityDataAccessor<Optional<Component>> descriptionAccessor;
   private static boolean descriptionLookedUp;

   public BotProfile profile;
   private int ticks;

   // Absicht fuer diesen Tick
   private Vec3 moveDir;
   private boolean sprint;
   private boolean jump;
   private boolean crouch;
   private Float faceYaw;
   private Vec3 lookPos;
   private double speedFactor = 1.0;
   /** Darf er in diesem Tick ueber eine Kante laufen (Bruecke, Sprung, absichtlich runter)? */
   private boolean allowEdge;
   /** Bis wann er vor einem Gegner flieht (Rueckzug statt Selbstmord). */
   private int fleeUntil;
   /** Abklingzeit fuer Bogen, Bettwanze, Golem, Turm ... */
   private int itemCd = 40;
   private int raidPrepFor = -1;
   private int lastTravelItemAt = -10000;
   private Vec3 tntAt;
   private int tntBackoffUntil;
   private boolean stickHit;
   /** Ausweichen vor einem heranfliegenden Geschoss. */
   private Vec3 dodgeDir;
   private int dodgeUntil;
   /** Schild oben (gegen Pfeile). */
   private int shieldUntil;
   private int reflexCd;

   // Pfad
   private List<Pathfinder.Step> path;
   private int pathIdx;
   private String pathKey;
   private int pathPlannedAt = -1000;
   private int pathProgressAt;
   private boolean pathComplete;
   private int failedPlans;
   /** Die letzte Wegsuche ist an fehlenden Bloecken gescheitert. */
   private boolean shortOfBlocks;

   // Kampf
   private LivingEntity enemy;
   private int attackCd;
   private int wtap;
   private int strafeDir = 1;
   private int strafeUntil;
   private LivingEntity lastAttacker;
   private int lastAttackedAt = -1000;
   // Fadenkreuz und Klicks
   private boolean aiming;
   private Vec3 aimPoint;
   private float aimYaw;
   private float aimPitch;
   private double aimNoiseYaw;
   private double aimNoisePitch;
   private int sinceSwing = 20;
   private int nextClickAt;
   private boolean timedClicker;
   private boolean strafing;
   private int freezeUntil;
   private Vec3 freezeDir;
   private LivingEntity engagedWith;
   private int engagedSince;
   private boolean edgeCareful = true;
   private boolean wantsPillarEscape;
   private int pillarLeft;
   private BlockPos pillarBase;
   private int gappleDecisionAt;
   public int hits;
   public int misses;

   // Handlungen
   private BlockPos breakPos;
   private int breakProgress;
   private int breakTotal;
   private int placeCd;
   private int fireCd = 60;
   private int clutchCd;
   private int eatTicks;
   private int bedMining;
   private int stayUntil;
   private int idleTurnAt;
   private Vec3 lastPos = Vec3.ZERO;
   private Vec3 anchor;
   private int anchorTick;
   private int stillTicks;
   private int shownHealth = -1;
   private HeldItem held = HeldItem.NONE;

   private enum HeldItem {
      NONE,
      SWORD,
      BLOCK,
      SHEARS,
      PICKAXE,
      FIREBALL,
      GAPPLE,
      OTHER
   }

   public BedwarsBot(Level level) {
      super(EntityTypes.MANNEQUIN, level);
   }

   public void setup(BotProfile profile) {
      this.profile = profile;
      this.entityData.set(DATA_PROFILE, skin(profile.alex));
      this.setCustomName(this.displayName());
      this.setCustomNameVisible(true);
      this.addTag("bw_bot");
      profile.equipArmor(this);
      this.hold(HeldItem.SWORD);
      this.updateHealthTag();
   }

   /** Standard-Skin ueber den Skin-Patch des Profils: Steve (breit) oder Alex (schmal). */
   private static ResolvableProfile skin(boolean alex) {
      try {
         JsonObject json = new JsonObject();
         json.addProperty("texture", alex ? "minecraft:entity/player/slim/alex" : "minecraft:entity/player/wide/steve");
         json.addProperty("model", alex ? "slim" : "wide");
         return (ResolvableProfile)ResolvableProfile.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow();
      } catch (Exception e) {
         return Mannequin.DEFAULT_PROFILE;
      }
   }

   @SuppressWarnings("unchecked")
   private void setBelowName(Component text) {
      if (!descriptionLookedUp) {
         descriptionLookedUp = true;

         try {
            Field f = Mannequin.class.getDeclaredField("DATA_DESCRIPTION");
            f.setAccessible(true);
            descriptionAccessor = (EntityDataAccessor<Optional<Component>>)f.get(null);
         } catch (Throwable t) {
            descriptionAccessor = null;
         }
      }

      if (descriptionAccessor != null) {
         this.entityData.set(descriptionAccessor, Optional.ofNullable(text));
      }
   }

   private void updateHealthTag() {
      if (this.hasEffect(MobEffects.INVISIBILITY)) {
         return;
      }

      int hp = (int)Math.ceil(this.getHealth() + this.getAbsorptionAmount());
      if (hp != this.shownHealth) {
         this.shownHealth = hp;
         this.setBelowName(Component.literal(hp + " ❤").withStyle(this.getAbsorptionAmount() > 0.0F ? ChatFormatting.GOLD : ChatFormatting.RED));
      }
   }

   public Component displayName() {
      return Component.literal("[" + this.profile.team.team.label + "] " + this.profile.name).withStyle(this.profile.team.team.format);
   }

   @Override
   public boolean shouldBeSaved() {
      return false;
   }

   @Override
   public boolean hurtServer(ServerLevel level, DamageSource source, float damage) {
      Entity attacker = source.getEntity();
      if (this.profile != null && attacker != null && Game.teamOf(attacker) == this.profile.team.team) {
         return false;
      } else {
         boolean hurt = super.hurtServer(level, source, damage);
         if (hurt && attacker instanceof LivingEntity living && attacker != this) {
            this.lastAttacker = living;
            this.lastAttackedAt = this.ticks;
            if (this.profile != null) {
               TeamBrain.onMemberHurt(this.profile, living);
            }
         }

         return hurt;
      }
   }

   /** Paper: der Tod laeuft ueber die Runde (Wiederbeleben), nicht ueber Minecraft. */
   @Override
   public void die(DamageSource source) {
      if (this.profile != null && Game.running() && !Game.onDeath(this, source)) {
         return;
      }

      super.die(source);
   }

   // ======================================================================== Tick

   @Override
   protected void serverAiStep() {
      super.serverAiStep();
      if (this.profile == null || !Game.running() || !(this.level() instanceof ServerLevel level)) {
         this.xxa = 0.0F;
         this.zza = 0.0F;
         this.setJumping(false);
         return;
      }

      this.ticks++;
      Platform.get().keepTicking(this);
      if (this.attackCd > 0) {
         this.attackCd--;
      }

      if (this.placeCd > 0) {
         this.placeCd--;
      }

      if (this.fireCd > 0) {
         this.fireCd--;
      }

      if (this.clutchCd > 0) {
         this.clutchCd--;
      }

      if (this.itemCd > 0) {
         this.itemCd--;
      }

      if (this.wtap > 0) {
         this.wtap--;
      }

      this.sinceSwing++;
      this.aiming = false;
      this.moveDir = null;
      this.sprint = false;
      this.jump = false;
      this.crouch = false;
      this.faceYaw = null;
      this.lookPos = null;
      this.speedFactor = 1.0;
      this.allowEdge = false;
      if (this.ticks % 10 == 0) {
         this.collectItems(level);
         this.updateHealthTag();
         // unsichtbar: kein Namensschild (wie bei Spielern)
         boolean invis = this.hasEffect(MobEffects.INVISIBILITY);
         if (this.isCustomNameVisible() == invis) {
            this.setCustomNameVisible(!invis);
            this.shownHealth = -1;
            if (invis) {
               this.setBelowName(null);
            }
         }
      }

      // wie ein Spieler mit vollem Hunger: ausserhalb vom Kampf kommt langsam Leben zurueck
      if (this.ticks % 60 == 0 && this.getHealth() < this.getMaxHealth() && this.ticks - this.lastAttackedAt > 100 && this.isAlive()) {
         this.heal(1.0F);
      }

      this.tickEating();
      if (!this.clutch(level)) {
         this.think(level);
         if (this.tickPillar(level)) {
            this.moveDir = null;
            this.sprint = false;
         }
      }

      this.reflexes(level);
      this.updateAim();
      this.edgeGuard();
      this.detectStuck();
      this.giveUpIfTrapped(level);
      this.applyIntent();
   }

   /**
    * Sitzt er abseits aller Inseln fest (z.B. unter einer Insel, ohne Bloecke), springt er nach
    * einer Weile in die Leere - wie ein echter Spieler. Sonst koennte eine Runde nie enden.
    */
   private void giveUpIfTrapped(ServerLevel level) {
      if (this.ticks % 100 == 0) {
         if (this.anchor == null || this.position().distanceTo(this.anchor) > 3.0) {
            this.anchor = this.position();
            this.anchorTick = this.ticks;
         }

         BotProfile.Task task = this.profile.task;
         boolean waiting = task == BotProfile.Task.ESCORT || task == BotProfile.Task.FOLLOW_PLAYER;
         boolean stalled = this.ticks - this.anchorTick > 900 && this.enemy == null && !waiting;
         if (stalled && this.profile.blocks() < 4 && !Game.arena().onAnyIsland(this.position())) {
            this.kill(level);
         }
      }
   }

   private void think(ServerLevel level) {
      if (this.ticks % 4 == 0 || this.enemy != null && !this.validEnemy(this.enemy)) {
         this.enemy = this.chooseEnemy();
      }

      if (this.eatTicks > 0) {
         this.retreatWhileEating(level);
         return;
      }

      if (this.shouldEat()) {
         this.startEating();
         return;
      }

      if (this.ticks % 20 == 7) {
         this.considerRetreat();
      }

      if (this.enemy != null && this.ticks % 10 == 3) {
         this.useDefenseItems(level, this.enemy);
      }

      if (this.enemy != null && this.shouldEngage(this.enemy)) {
         this.cancelBreak(level);
         this.fight(level, this.enemy);
         return;
      }

      this.doTask(level);
   }

   /**
    * Ein Mensch rennt nicht sehenden Auges in den Tod: wer weit weg von zu Hause, angeschlagen und in der
    * Unterzahl ist, zieht sich zurueck - ausser er steht direkt am gegnerischen Bett und kann es gleich abbauen.
    */
   private void considerRetreat() {
      BotProfile p = this.profile;
      BotProfile.Task task = p.task;
      if (task != BotProfile.Task.RAID && task != BotProfile.Task.HUNT && task != BotProfile.Task.MID && task != BotProfile.Task.ESCORT) {
         return;
      }

      float hpNow = this.getHealth() + this.getAbsorptionAmount();
      if (task == BotProfile.Task.RAID && p.taskTeam != null && p.taskTeam.bedAlive && this.position().distanceTo(p.taskTeam.island().bedCenter()) < 9.0 && hpNow >= 6.0F) {
         // so nah am Bett gibt man nicht auf
         return;
      }

      int enemies = 0;
      double enemyGear = 0.0;
      for (LivingEntity e : Game.enemiesOf(p.team)) {
         if (e.distanceTo(this) < 11.0 && !(e.isInvisible() && e.distanceTo(this) > 4.0)) {
            enemies++;
            enemyGear += TeamBrain.gearOf(e);
         }
      }

      if (enemies == 0) {
         return;
      }

      int allies = 0;
      for (LivingEntity m : Game.membersOf(p.team)) {
         if (m.distanceTo(this) < 11.0) {
            allies++;
         }
      }

      float hp = this.getHealth() + this.getAbsorptionAmount();
      boolean weak = hp < 6.0F && p.gapples == 0;
      boolean outgeared = p.gearScore() + 2.0 < enemyGear / enemies;
      boolean outnumbered = enemies >= allies + 3 || enemies >= allies + 2 && (hp < 12.0F || outgeared) || enemies > allies && outgeared && hp < 12.0F;
      // gute Spieler erkennen die Lage frueher, Anfaenger rennen oefter trotzdem rein
      double sense = 0.35 + p.skill * 0.6 + p.caution * 0.2 + (p.mood == 2 ? 0.4 : (p.mood == 1 ? -0.3 : 0.0));
      if ((weak || outnumbered) && RND.nextDouble() < sense) {
         Game.count("rueckzug");
         Vec3 home = p.team.island().spawn();
         if (p.pearls > 0 && this.position().distanceTo(home) > 25.0 && this.position().distanceTo(home) < 55.0 && RND.nextDouble() < p.hands.sense
            && this.level() instanceof ServerLevel lvl) {
            // mit der Enderperle nach Hause
            BwEntities.Thrown pearl = new BwEntities.Thrown(lvl, this, BwEntities.Thrown.Kind.PEARL, p.team);
            this.launch(pearl, home.add(0.0, -0.5, 0.0), 1.4, 0.03);
            lvl.addFreshEntity(pearl);
            this.holdItem(Items.ENDER_PEARL);
            p.pearls--;
            Game.count("perle-flucht");
         }

         p.task = BotProfile.Task.RETREAT;
         p.taskLockUntil = Game.tick() + 240;
         p.taskSince = Game.tick();
         p.taskEntity = null;
         this.path = null;
         this.fleeUntil = this.ticks + 80;
         if (RND.nextInt(3) == 0) {
            BotChat.event(p, BotChat.Event.RETREAT, null);
         }
      }
   }

   // ======================================================================== Bewegung

   private static float yawOf(double dx, double dz) {
      return (float)(Mth.atan2(-dx, dz) * (180.0 / Math.PI));
   }

   private void applyIntent() {
      float yaw;
      if (this.aiming) {
         yaw = this.aimYaw;
      } else if (this.faceYaw != null) {
         yaw = this.faceYaw;
      } else if (this.moveDir != null && this.moveDir.horizontalDistanceSqr() > 1.0E-4) {
         yaw = yawOf(this.moveDir.x, this.moveDir.z);
      } else {
         yaw = this.getYRot();
      }

      float maxTurn = this.aiming ? 360.0F : (float)(25.0 + this.profile.skill * 35.0);
      float newYaw = this.getYRot() + Mth.clamp(Mth.wrapDegrees(yaw - this.getYRot()), -maxTurn, maxTurn);
      this.setYRot(newYaw);
      float headYaw = newYaw;
      float pitch = 0.0F;
      if (this.aiming) {
         headYaw = this.aimYaw;
         pitch = this.aimPitch;
      } else if (this.lookPos != null) {
         Vec3 eye = this.getEyePosition();
         double dx = this.lookPos.x - eye.x;
         double dy = this.lookPos.y - eye.y;
         double dz = this.lookPos.z - eye.z;
         headYaw = yawOf(dx, dz);
         pitch = (float)(-Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
      }

      this.setYHeadRot(headYaw);
      this.setXRot(Mth.clamp(pitch, -90.0F, 90.0F));
      if (this.moveDir != null) {
         double len = Math.min(1.0, this.moveDir.horizontalDistance());
         Vec3 d = this.moveDir.horizontalDistanceSqr() > 1.0E-6 ? new Vec3(this.moveDir.x, 0.0, this.moveDir.z).normalize().scale(len) : Vec3.ZERO;
         float rad = newYaw * DEG;
         double sin = Mth.sin(rad);
         double cos = Mth.cos(rad);
         this.xxa = (float)(d.x * cos + d.z * sin);
         this.zza = (float)(-d.x * sin + d.z * cos);
      } else {
         this.xxa = 0.0F;
         this.zza = 0.0F;
      }

      boolean sprinting = this.sprint && this.wtap == 0 && this.zza > 0.6F && !this.crouch && this.eatTicks == 0;
      if (sprinting && this.onGround() && !this.allowEdge && this.profile.hands.sprintJump > 0.0 && RND.nextDouble() < this.profile.hands.sprintJump
         && this.moveDir != null && this.groundAt(this.position().add(this.moveDir.normalize().scale(2.2)))) {
         this.jump = true;
      }
      this.setSprinting(sprinting);
      float speed = sprinting ? 0.13F : (this.crouch ? 0.045F : 0.1F);
      if (this.eatTicks > 0) {
         speed *= 0.35F;
      }

      // Tempotrank und Langsamkeit (Fallen) wirken wie bei Spielern
      double attr = Mth.clamp(this.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED) / 0.1, 0.4, 2.0);
      this.setSpeed((float)(speed * this.speedFactor * attr));
      // im Wasser: oben bleiben und an Kanten hochschwimmen, wie ein Spieler mit gedrueckter Leertaste
      boolean swim = this.isInWater() && (this.horizontalCollision || this.isEyeInFluid(net.minecraft.tags.FluidTags.WATER) || this.jump);
      this.setJumping(this.jump && this.onGround() || swim);
      Pose pose = this.crouch ? Pose.CROUCHING : Pose.STANDING;
      if (this.getPose() != pose) {
         this.setPose(pose);
      }
   }

   /**
    * Letzte Sicherung gegen das Runterlaufen: wer nicht gerade baut oder springt, laeuft nicht ueber eine Kante
    * ins Nichts. Nur Anfaenger passen manchmal nicht auf.
    */
   private void edgeGuard() {
      if (this.allowEdge || this.moveDir == null || !this.onGround() || this.moveDir.horizontalDistanceSqr() < 1.0E-4) {
         return;
      }

      Vec3 dir = this.moveDir;
      Vec3 vel = this.getDeltaMovement().multiply(1.0, 0.0, 1.0);
      Vec3 ahead = this.position().add(dir.normalize().scale(0.6)).add(vel.scale(2.0));
      if (!this.voidBelow(ahead)) {
         return;
      }

      // nur Anfaenger passen an der Kante manchmal nicht auf
      double careless = this.profile.hands.style == Hands.Style.NOOB ? 0.01 : 0.0;
      if (careless > 0.0 && RND.nextDouble() < careless * (1.0 + this.profile.tilt)) {
         Game.count("kante-nicht-aufgepasst");
         return;
      }

      Vec3 safer = this.safe(dir);
      this.moveDir = safer;
      if (safer == null) {
         this.sprint = false;
         // abbremsen, statt mit Schwung ueber die Kante zu rutschen
         this.setDeltaMovement(this.getDeltaMovement().multiply(0.3, 1.0, 0.3));
         Game.count("kante-gebremst");
      }
   }

   /** Unter dieser Stelle ist bis tief hinunter nichts (Leere)? */
   private boolean voidBelow(Vec3 pos) {
      BlockPos base = BlockPos.containing(pos.x, this.getY() - 0.2, pos.z);

      for (int i = 0; i <= 6; i++) {
         BlockPos p = base.below(i);
         if (!this.level().getBlockState(p).getCollisionShape(this.level(), p).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private void go(Vec3 target, boolean sprint) {
      Vec3 d = new Vec3(target.x - this.getX(), 0.0, target.z - this.getZ());
      double len = d.length();
      if (len > 0.08) {
         this.moveDir = d.scale(1.0 / len).scale(Math.min(1.0, len * 2.5));
         this.sprint = sprint && len > 1.5;
      }
   }

   private void detectStuck() {
      if (this.ticks % 10 == 0) {
         boolean wants = this.moveDir != null && this.moveDir.horizontalDistanceSqr() > 0.2;
         if (wants && this.position().distanceToSqr(this.lastPos) < 0.01) {
            this.stillTicks += 10;
         } else {
            this.stillTicks = 0;
         }

         this.lastPos = this.position();
      }

      if (this.stillTicks >= 20 && this.onGround()) {
         this.jump = true;
      }

      if (this.stillTicks >= 60) {
         this.stillTicks = 0;
         this.path = null;
      }
   }

   /** Liegt dort, wohin er treten will, Boden (bis drei Bloecke tiefer)? */
   private boolean groundAt(Vec3 pos) {
      BlockPos base = BlockPos.containing(pos.x, this.getY() - 0.2, pos.z);

      for (int i = 0; i <= 3; i++) {
         BlockPos p = base.below(i);
         if (!this.level().getBlockState(p).getCollisionShape(this.level(), p).isEmpty()) {
            return true;
         }
      }

      return false;
   }

   /** Begrenzt eine freie Bewegung so, dass er nicht in die Leere laeuft. */
   private Vec3 safe(Vec3 dir) {
      if (dir == null) {
         return null;
      } else {
         Vec3 ahead = this.position().add(dir.normalize().scale(0.9));
         if (this.groundAt(ahead)) {
            return dir;
         } else {
            Vec3 alt = new Vec3(dir.x, 0.0, 0.0);
            if (alt.lengthSqr() > 0.01 && this.groundAt(this.position().add(alt.normalize().scale(0.9)))) {
               return alt;
            } else {
               alt = new Vec3(0.0, 0.0, dir.z);
               return alt.lengthSqr() > 0.01 && this.groundAt(this.position().add(alt.normalize().scale(0.9))) ? alt : null;
            }
         }
      }
   }

   // ======================================================================== Pfade

   private enum Nav {
      MOVING,
      ARRIVED,
      WAITING,
      FAILED
   }

   private Nav navigate(ServerLevel level, Pathfinder.Goal goal, String key, boolean bridge, boolean breaking, int replan) {
      BlockPos feet = this.feet();
      if (goal.reached(feet.getX(), feet.getY(), feet.getZ()) && this.onGround()) {
         this.path = null;
         return Nav.ARRIVED;
      } else {
         boolean need = this.path == null
            || !key.equals(this.pathKey)
            || this.pathIdx >= this.path.size()
            || this.ticks - this.pathPlannedAt >= replan
            || this.ticks - this.pathProgressAt > 80;
         if (need) {
            if (!Game.takePlanBudget()) {
               if (this.path != null && key.equals(this.pathKey) && this.pathIdx < this.path.size()) {
                  return this.followPath(level);
               }

               return Nav.WAITING;
            }

            Pathfinder.Options opt = new Pathfinder.Options();
            opt.blocks = bridge ? this.profile.blocks() : 0;
            opt.pickaxe = this.profile.pickaxe;
            opt.axe = this.profile.axe;
            opt.shears = this.profile.shears;
            opt.allowBreak = breaking;
            opt.maxNodes = (int)Mth.clamp(1500.0 + goal.estimate(feet.getX(), feet.getY(), feet.getZ()) * 90.0, 1500.0, 7000.0);
            opt.bridgeCost = 2.2 + this.profile.caution;
            Pathfinder.Result res = Pathfinder.find(level, Game.arena(), feet, goal, opt);
            this.path = res.steps;
            this.pathIdx = 0;
            this.pathKey = key;
            this.pathPlannedAt = this.ticks;
            this.pathProgressAt = this.ticks;
            this.pathComplete = res.complete;
            this.shortOfBlocks = bridge && !res.complete && res.blocksUsed >= opt.blocks - 1;
            if (res.steps.isEmpty()) {
               this.failedPlans++;
               this.path = null;
               return Nav.FAILED;
            }

            this.failedPlans = 0;
         }

         return this.followPath(level);
      }
   }

   private BlockPos feet() {
      BlockPos p = this.blockPosition();
      // auf einer Kante: die Zelle nehmen, in der wirklich Boden ist
      if (this.onGround() && this.level().getBlockState(p.below()).getCollisionShape(this.level(), p.below()).isEmpty()) {
         AABB box = this.getBoundingBox();

         for (double ox : new double[]{-0.3, 0.3}) {
            for (double oz : new double[]{-0.3, 0.3}) {
               BlockPos q = BlockPos.containing(box.getCenter().x + ox, this.getY() - 0.5, box.getCenter().z + oz);
               if (!this.level().getBlockState(q).getCollisionShape(this.level(), q).isEmpty()) {
                  return q.above();
               }
            }
         }
      }

      return p;
   }

   private Nav followPath(ServerLevel level) {
      if (this.path == null || this.pathIdx >= this.path.size()) {
         return Nav.FAILED;
      } else {
         Pathfinder.Step step = this.path.get(this.pathIdx);
         Vec3 c = Vec3.atBottomCenterOf(step.pos);
         double hd = Math.sqrt((c.x - this.getX()) * (c.x - this.getX()) + (c.z - this.getZ()) * (c.z - this.getZ()));
         double dy = step.pos.getY() - this.getY();
         if (hd < 0.4 && Math.abs(dy) < 0.75 && (this.onGround() || step.move == Pathfinder.Move.DROP && dy > -0.2)) {
            this.pathIdx++;
            this.pathProgressAt = this.ticks;
            if (this.pathIdx >= this.path.size()) {
               return this.pathComplete ? Nav.ARRIVED : Nav.FAILED;
            }

            step = this.path.get(this.pathIdx);
            c = Vec3.atBottomCenterOf(step.pos);
            hd = Math.sqrt((c.x - this.getX()) * (c.x - this.getX()) + (c.z - this.getZ()) * (c.z - this.getZ()));
         }

         if (hd > 4.5 || Math.abs(step.pos.getY() - this.getY()) > 4.0) {
            this.path = null;
            return Nav.WAITING;
         }

         Pathfinder.Move move = step.move;
         if (move == Pathfinder.Move.WALK && !this.solid(step.pos.below()) && this.profile.blocks() > 0) {
            move = Pathfinder.Move.BRIDGE;
         }

         // geplante Spruenge, Stuerze und Bruecken duerfen ueber Kanten gehen
         this.allowEdge = move != Pathfinder.Move.WALK || step.pos.getY() < this.getY() - 0.5;

         switch (move) {
            case BREAK:
               for (BlockPos b : step.breaks) {
                  if (!level.getBlockState(b).isAir()) {
                     this.mine(level, b);
                     return Nav.MOVING;
                  }
               }

               this.go(c, false);
               break;
            case BRIDGE:
               BlockPos place = step.place != null ? step.place : step.pos.below();
               this.crouch = this.profile.hands.style != Hands.Style.SWEAT;
               if (!this.solid(place)) {
                  this.lookPos = Vec3.atCenterOf(place);
                  if (this.placeCd == 0 && this.onGround() && hd < 1.7) {
                     if (RND.nextDouble() < this.profile.hands.bridgeSlip * (1.0 + this.profile.tilt)) {
                        // verschaetzt: ohne Block weitergelaufen
                        Game.count("abgerutscht");
                        this.go(c, false);
                        this.placeCd = 10;
                        return Nav.MOVING;
                     }

                     if (!this.place(level, place, false, 1)) {
                        this.path = null;
                     }
                  }

                  return Nav.MOVING;
               }

               this.go(c, false);
               break;
            case PILLAR:
               BlockPos under = step.place != null ? step.place : step.pos.below();
               if (!this.solid(under) && this.onGround()) {
                  Game.count("hochbauen-weg");
               }

               if (!this.solid(under)) {
                  this.go(c, false);
                  this.lookPos = Vec3.atCenterOf(under);
                  if (this.onGround()) {
                     this.jump = true;
                  } else if (this.getY() >= under.getY() + 1.0 && this.placeCd == 0) {
                     this.place(level, under, false, 1);
                  }

                  return Nav.MOVING;
               }

               this.go(c, false);
               break;
            case JUMP:
               this.go(c, false);
               if (this.onGround() && hd < 1.4) {
                  this.jump = true;
               }
               break;
            default:
               this.go(c, hd > 2.0);
               if (this.horizontalCollision && this.onGround()) {
                  this.jump = true;
               }
         }

         return Nav.MOVING;
      }
   }

   private boolean solid(BlockPos pos) {
      return !this.level().getBlockState(pos).getCollisionShape(this.level(), pos).isEmpty();
   }

   // ======================================================================== Bloecke

   /** Wie ein Spieler: Bloecke nur an einen anderen Block setzen (nie frei in die Luft) und nur in Reichweite. */
   private boolean placeable(ServerLevel level, BlockPos pos) {
      return this.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) <= 4.6 && hasSupport(level, pos);
   }

   /** Grenzt die Stelle an einen festen Block (an den man etwas setzen kann)? */
   static boolean hasSupport(ServerLevel level, BlockPos pos) {
      for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) {
         BlockPos n = pos.relative(d);
         BlockState st = level.getBlockState(n);
         if (!st.isAir() && st.getFluidState().isEmpty() && !st.getCollisionShape(level, n).isEmpty()) {
            return true;
         }
      }

      return false;
   }

   private boolean place(ServerLevel level, BlockPos pos, boolean defensive, int layer) {
      BlockState there = level.getBlockState(pos);
      if (!there.canBeReplaced() || !Game.arena().inBuildArea(pos) || Game.arena().isMap(pos) || !this.placeable(level, pos)) {
         return false;
      } else if (!level.getEntities((Entity)null, new AABB(pos), e -> e instanceof LivingEntity && e.isAlive()).isEmpty()) {
         return false;
      } else {
         Block block = this.profile.takeBlock(defensive, layer);
         if (block == null) {
            return false;
         } else {
            BlockState state = block.defaultBlockState();
            level.setBlock(pos, state, 3);
            level.playSound(null, pos, state.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 0.9F + RND.nextFloat() * 0.2F);
            this.holdBlock(block);
            this.swingArm();
            this.placeCd = Math.max(1, this.profile.hands.bridgeDelay + RND.nextInt(3) - 1);
            return true;
         }
      }
   }

   private void mine(ServerLevel level, BlockPos pos) {
      BlockState state = level.getBlockState(pos);
      if (state.isAir() || Game.arena().isMap(pos) || state.getBlock() instanceof BedBlock) {
         this.cancelBreak(level);
      } else {
         if (!pos.equals(this.breakPos)) {
            this.cancelBreak(level);
            this.breakPos = pos.immutable();
            this.breakProgress = 0;
            int base = Pathfinder.breakTicks(state, this.profile.pickaxe, this.profile.shears, this.profile.axe);
            // unter Wasser baut man (wie Spieler) deutlich langsamer ab
            double wet = this.isEyeInFluid(net.minecraft.tags.FluidTags.WATER) ? 2.5 : 1.0;
            this.breakTotal = Math.max(2, (int)(base * (1.25 - this.profile.skill * 0.35) * wet));
         }

         this.lookPos = Vec3.atCenterOf(pos);
         if (state.is(net.minecraft.tags.BlockTags.PLANKS) && this.profile.axe > 0) {
            this.holdItem(new net.minecraft.world.item.Item[]{Items.WOODEN_AXE, Items.STONE_AXE, Items.IRON_AXE, Items.DIAMOND_AXE}[Math.min(3, this.profile.axe - 1)]);
         } else {
            this.hold(state.is(net.minecraft.tags.BlockTags.WOOL) && this.profile.shears ? HeldItem.SHEARS : (this.profile.pickaxe > 0 ? HeldItem.PICKAXE : HeldItem.SWORD));
         }
         this.breakProgress++;
         if (this.breakProgress % 4 == 1) {
            this.swingArm();
            level.playSound(null, pos, state.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.5F, 0.8F);
         }

         level.destroyBlockProgress(this.getId(), pos, Math.min(9, this.breakProgress * 10 / Math.max(1, this.breakTotal)));
         if (this.breakProgress >= this.breakTotal) {
            level.destroyBlockProgress(this.getId(), pos, -1);
            level.destroyBlock(pos, false, this);
            this.breakPos = null;
            this.pathProgressAt = this.ticks;
         }
      }
   }

   private void cancelBreak(ServerLevel level) {
      if (this.breakPos != null) {
         level.destroyBlockProgress(this.getId(), this.breakPos, -1);
         this.breakPos = null;
      }
   }

   /** Faellt er in die Leere, setzt er (je nach Koennen) einen Block unter sich. */
   private boolean clutch(ServerLevel level) {
      if (this.onGround() || this.getDeltaMovement().y > -0.25 || this.clutchCd > 0 || this.profile.blocks() == 0) {
         return false;
      } else {
         BlockPos feet = this.blockPosition();

         for (int i = 1; i <= 8; i++) {
            if (this.solid(feet.below(i))) {
               return false;
            }
         }

         this.clutchCd = 14;
         if (RND.nextDouble() < this.profile.hands.clutch) {
            BlockPos under = feet.below();
            if (this.place(level, under, false, 1)) {
               Game.count("clutch");
               this.setDeltaMovement(this.getDeltaMovement().multiply(0.3, 0.0, 0.3));
               this.path = null;
               if (RND.nextInt(3) == 0) {
                  BotChat.event(this.profile, BotChat.Event.CLUTCH, null);
               }

               return true;
            }
         }

         // kein Block in Reichweite: die Rettungsplattform
         if (this.profile.rescue > 0 && RND.nextDouble() < 0.4 + this.profile.skill * 0.6 && BwItems.rescueAt(level, feet.below(2))) {
            this.profile.rescue--;
            this.holdItem(Items.BLAZE_ROD);
            this.fallDistance = 0.0;
            this.path = null;
            Game.count("rettungsplattform");
            return true;
         }

         return false;
      }
   }

   // ======================================================================== Kampf

   private boolean validEnemy(LivingEntity e) {
      return e != null && e.isAlive() && !e.isRemoved() && Game.isEnemy(this.profile.team, e) && !Game.isProtected(e);
   }

   private double awareness() {
      return switch (this.profile.task) {
         case DEFEND -> 26.0;
         case HUNT -> 40.0;
         case FORTIFY, GATHER -> 18.0;
         default -> 16.0;
      };
   }

   /** Steht ein Gegner an unserem Bett? (Bot oder echter Spieler - egal) */
   private boolean atOurBed(LivingEntity e) {
      Game.TeamState t = this.profile.team;
      return t.bedAlive && e.position().distanceTo(t.island().bedCenter()) < 8.0 && Math.abs(e.getY() - t.island().bedCenter().y) < 6.0;
   }

   private LivingEntity chooseEnemy() {
      double range = this.awareness() * this.profile.hands.awareness;
      LivingEntity best = null;
      double bestScore = Double.MAX_VALUE;
      boolean meHome = Game.arena().islandAt(this.position(), 2.0) == this.profile.team.team;

      for (LivingEntity e : Game.enemiesOf(this.profile.team)) {
         if (!Game.isProtected(e)) {
            double d = this.distanceTo(e);
            // wer auf unserer Insel oder an unserem Bett ist, wird von allen zu Hause bemerkt und hat Vorrang
            boolean bedThreat = this.atOurBed(e) && d < 30.0;
            boolean islandThreat = meHome && Game.arena().islandAt(e.position(), 2.0) == this.profile.team.team;
            if (bedThreat || islandThreat) {
               double score = d - (bedThreat ? 30.0 : 15.0) - (20.0 - e.getHealth()) * 0.3;
               if (score < bestScore && !(e.isInvisible() && d > 4.0)) {
                  bestScore = score;
                  best = e;
               }

               continue;
            }

            boolean target = e == this.profile.taskEntity;
            boolean attacker = e == this.lastAttacker && this.ticks - this.lastAttackedAt < 100;
            if (e.isInvisible() && d > 4.0 && !attacker) {
               // unsichtbar: erst ganz nah zu bemerken
               continue;
            }

            if (d <= range || target && d < 60.0 || attacker && d < 24.0) {
               double score = d;
               if (target) {
                  score -= 12.0;
               }

               if (attacker) {
                  score -= 8.0;
               }

               score -= (20.0 - e.getHealth()) * 0.3;
               // gemeinsam auf einen: kaempft ein Teamkollege schon gegen ihn, kommt er eher dran
               for (BotProfile mate : this.profile.team.bots) {
                  if (mate != this.profile && mate.body != null && mate.body.currentEnemy() == e && mate.body.distanceTo(e) < 6.0) {
                     score -= 3.0;
                     break;
                  }
               }

               if (d > 6.0 && !this.hasLineOfSight(e)) {
                  score += 10.0;
               }

               if (score < bestScore) {
                  bestScore = score;
                  best = e;
               }
            }
         }
      }

      return best;
   }

   private boolean shouldEngage(LivingEntity e) {
      double d = this.distanceTo(e);
      BotProfile p = this.profile;
      boolean attacked = e == this.lastAttacker && this.ticks - this.lastAttackedAt < 80;
      boolean onOurIsland = Game.arena().islandAt(e.position(), 9.0) == p.team.team;
      if (this.atOurBed(e) && this.getHealth() > 3.0F && d < 30.0) {
         // am eigenen Bett wird immer verteidigt - egal, was er gerade vorhatte
         return true;
      }

      if (p.task == BotProfile.Task.RETREAT && (this.ticks < this.fleeUntil || this.getHealth() < 12.0F)) {
         // auf dem Rueckzug: nur wehren, wenn einer direkt dran ist
         return d < 2.6 || attacked && d < 3.2 && this.getHealth() > 6.0F;
      } else if (p.task == BotProfile.Task.RAID && p.taskTeam != null && p.taskTeam.bedAlive
         && this.position().distanceTo(p.taskTeam.island().bedCenter()) < 10.0 && !onOurIsland) {
         // am gegnerischen Bett: Bett zuerst, gekaempft wird nur, wenn einer direkt im Weg steht
         return d < 2.4 || this.getHealth() < 6.0F && attacked && d < 3.5;
      } else if (p.task == BotProfile.Task.HUNT && e == p.taskEntity) {
         return true;
      } else if (onOurIsland) {
         return d < 28.0;
      } else if (d < 4.5 || attacked && d < 14.0) {
         return true;
      } else if (!p.team.bedAlive) {
         // ohne Bett: nur kaempfen, wenn es sich lohnt
         return d < 9.0 && this.advantageOver(e) > 0.0;
      } else {
         double range = (p.mood == 1 ? 6.0 : (p.mood == 2 ? -3.0 : 0.0)) + switch (p.task) {
            case HOLD -> 10.0;
            case RAID -> 5.5 + p.aggression * 3.0;
            case DEFEND, ESCORT, FOLLOW_PLAYER -> 14.0;
            case FORTIFY, SHOP, CUT_BRIDGE -> 6.0;
            case HUNT -> 16.0;
            default -> 7.0 + p.aggression * 7.0;
         };
         return d < range;
      }
   }

   /** Grobe Einschaetzung: positiv = er ist staerker als der Gegner. */
   private double advantageOver(LivingEntity e) {
      double mine = this.getHealth() + this.getAbsorptionAmount() + this.profile.gearScore() * 2.5;
      double theirs = e.getHealth() + e.getAbsorptionAmount();
      if (e instanceof BedwarsBot b && b.profile != null) {
         theirs += b.profile.gearScore() * 2.5;
      } else if (e instanceof ServerPlayer sp) {
         theirs += Game.playerGearScore(sp) * 2.5;
      }

      return mine - theirs + (this.profile.aggression - 0.5) * 8.0;
   }

   private void fight(ServerLevel level, LivingEntity e) {
      Hands h = this.profile.hands;
      double d = this.distanceTo(e);
      Vec3 seen = Game.pastPosition(e, h.reaction + (this.profile.tilt > 0.5 ? 2 : 0));
      this.aimAt(seen.add(0.0, e.getBbHeight() * 0.72, 0.0));
      if (this.engagedWith != e) {
         this.engagedWith = e;
         this.engagedSince = this.ticks;
         this.edgeCareful = RND.nextDouble() < h.edge;
         this.wantsPillarEscape = RND.nextDouble() < h.pillar;
         this.timedClicker = RND.nextDouble() < h.timing;
      }

      if (this.ticks % 20 == 0) {
         this.edgeCareful = RND.nextDouble() < h.edge;
      }

      // kurzer Aussetzer: stehen bleiben oder falsch laufen, wie ein Mensch, der kurz nicht aufpasst
      if (this.ticks < this.freezeUntil) {
         if (this.freezeDir != null) {
            this.moveDir = this.edgeCareful ? this.safe(this.freezeDir) : this.freezeDir;
         }

         this.clickAt(level, e, d);
         return;
      } else if (RND.nextDouble() < h.brainfart * (1.0 + this.profile.tilt)) {
         this.freezeUntil = this.ticks + 5 + RND.nextInt(16);
         Game.count("aussetzer");
         this.freezeDir = RND.nextBoolean() ? null : new Vec3(RND.nextGaussian(), 0.0, RND.nextGaussian());
      }

      boolean lowAndLosing = this.getHealth() < 7.0F && this.advantageOver(e) < -4.0 && this.profile.caution > 0.35;
      if (lowAndLosing && this.wantsPillarEscape && this.profile.blocks() >= 3 && this.pillarLeft == 0 && d < 5.0) {
         // in Not hochbauen
         this.pillarLeft = 3;
         this.wantsPillarEscape = false;
         Game.count("flucht-hochbauen");
      }

      if (lowAndLosing && d > 2.0) {
         // zurueckweichen statt sinnlos sterben
         Vec3 away = this.position().subtract(seen).multiply(1.0, 0.0, 1.0);
         Vec3 home = this.profile.team.island().spawn().subtract(this.position()).multiply(1.0, 0.0, 1.0);
         Vec3 dir = away.normalize().add(home.normalize().scale(0.8));
         this.moveDir = this.edgeCareful ? this.safe(dir) : dir;
         this.sprint = true;
         this.hold(HeldItem.SWORD);
         this.clickAt(level, e, d);
         return;
      }

      // Gegner steht ueber ihm: hochbauen
      double above = e.getY() - this.getY();
      if (above > 1.8 && Math.hypot(e.getX() - this.getX(), e.getZ() - this.getZ()) < 2.8 && this.profile.blocks() > 0 && this.pillarLeft == 0
         && RND.nextDouble() < h.pillar * 0.2) {
         this.pillarLeft = (int)Math.ceil(above);
         Game.count("hochbauen-zum-gegner");
      }

      boolean direct = d < 7.0 && Math.abs(e.getY() - this.getY()) < 1.3 && this.hasLineOfSight(e) && this.walkableTowards(e.position());
      if (this.profile.fireballs > 0 && this.fireCd == 0 && d > 9.0 && d < 30.0 && this.hasLineOfSight(e)) {
         this.throwFireball(level, e);
         return;
      }

      if (this.itemCd == 0 && this.useRangedItem(level, e, d)) {
         return;
      }

      if (!direct) {
         boolean bridge = this.profile.task == BotProfile.Task.HUNT || this.profile.aggression > 0.45 || Game.arena().islandAt(e.position(), 6.0) != null;
         Nav nav = this.navigate(level, Pathfinder.near(e.blockPosition(), 1.6), "enemy" + e.getId(), bridge, true, 15);
         if (this.held != HeldItem.BLOCK && this.breakPos == null) {
            this.hold(HeldItem.SWORD);
         }

         if (nav == Nav.FAILED || nav == Nav.WAITING) {
            this.go(seen, true);
            this.moveDir = this.edgeCareful ? this.safe(this.moveDir) : this.moveDir;
         }

         // unterwegs schaut er dorthin, wohin er laeuft - ausser der Gegner ist schon nah
         if (d > 6.0) {
            this.aiming = false;
         }
      } else {
         this.path = null;
         this.hold(HeldItem.SWORD);
         Vec3 to = new Vec3(seen.x - this.getX(), 0.0, seen.z - this.getZ());
         if (to.lengthSqr() < 1.0E-4) {
            to = new Vec3(1.0, 0.0, 0.0);
         }

         to = to.normalize();
         if (this.ticks >= this.strafeUntil || this.horizontalCollision) {
            this.strafing = RND.nextDouble() < h.strafe;
            this.strafeDir = RND.nextBoolean() ? 1 : -1;
            this.strafeUntil = this.ticks + 6 + RND.nextInt(h.style == Hands.Style.NOOB ? 30 : 18);
         }

         Vec3 side = new Vec3(-to.z, 0.0, to.x).scale(this.strafeDir);
         Vec3 move;
         if (d > 2.8) {
            move = this.strafing ? to.add(side.scale(0.3)) : to;
            this.sprint = true;
         } else if (d < 1.4 && h.strafe > 0.3) {
            move = to.scale(-0.7).add(side.scale(0.5));
         } else if (this.strafing) {
            move = side.scale(0.5 + h.strafe * 0.5).add(to.scale(0.35));
            this.sprint = true;
         } else {
            // wer nicht strafed, laeuft einfach weiter drauf
            move = to;
            this.sprint = true;
         }

         this.moveDir = this.edgeCareful ? this.safe(move) : move;
         if (this.moveDir == null) {
            this.strafeDir = -this.strafeDir;
         }

         if (this.onGround() && d < 3.4 && RND.nextDouble() < h.crits * 0.12) {
            this.jump = true;
         }
      }

      this.clickAt(level, e, d);
   }

   /** Entscheidet, ob er in diesem Tick klickt - wie ein Mensch, nicht wie eine Kill-Aura. */
   /** Nach einem Item (Feuerball, Bogen, Schneeball ...) braucht ein Mensch einen Moment, bis das Schwert wieder in der Hand ist. */
   private void afterItem() {
      this.nextClickAt = Math.max(this.nextClickAt, this.ticks + this.profile.hands.switchDelay);
   }

   private void clickAt(ServerLevel level, LivingEntity e, double d) {
      Hands h = this.profile.hands;
      if (d > h.clickRange + 0.4 || this.ticks < this.nextClickAt || this.eatTicks > 0 || this.ticks < this.shieldUntil) {
         return;
      }

      // steht der Gegner an der Kante, nimmt er den Rueckstoss-Stock
      this.stickHit = this.profile.kbStick && this.nearVoid(e) && RND.nextDouble() < 0.4 + this.profile.skill * 0.5;
      if (this.stickHit) {
         this.holdItem(Items.STICK);
      } else if (this.held == HeldItem.OTHER) {
         this.hold(HeldItem.SWORD);
      }

      if (this.timedClicker) {
         if (d > 3.05) {
            return;
         }

         // wartet die Abklingzeit ab, mal etwas zu frueh, mal zu spaet
         int ready = 11 + (int)Math.round(RND.nextGaussian() * (1.6 - h.timing));
         if (this.sinceSwing < ready) {
            this.nextClickAt = this.ticks + Math.max(1, ready - this.sinceSwing);
            return;
         }

         // Krit-Timing: kurz warten, bis er faellt
         boolean rising = !this.onGround() && this.getDeltaMovement().y > 0.05;
         if (rising && RND.nextDouble() < h.crits && d < 3.0) {
            return;
         }
      }

      this.swingSword(level);
      double interval = 20.0 / h.cps * (0.6 + RND.nextDouble() * 0.8);
      this.nextClickAt = this.ticks + Math.max(1, (int)Math.round(interval));
      if (RND.nextDouble() > 0.92) {
         this.timedClicker = RND.nextDouble() < h.timing;
      }
   }

   /** Schwingt das Schwert entlang des Fadenkreuzes. Getroffen wird nur, wenn der Strahl die Hitbox trifft. */
   private void swingSword(ServerLevel level) {
      float strength = Mth.clamp((this.sinceSwing + 0.5F) / 12.5F, 0.0F, 1.0F);
      this.sinceSwing = 0;
      this.swingArm();
      Vec3 eye = this.getEyePosition();
      Vec3 dir = Vec3.directionFromRotation(this.aimPitch, this.aimYaw);
      double reach = 3.0;
      Vec3 end = eye.add(dir.scale(reach));
      BlockHitResult block = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
      if (block.getType() != HitResult.Type.MISS) {
         end = block.getLocation();
      }

      LivingEntity hit = null;
      double best = Double.MAX_VALUE;

      for (LivingEntity c : level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(4.5), x -> x != this && x.isAlive())) {
         Optional<Vec3> on = c.getBoundingBox().inflate(0.1).clip(eye, end);
         if (on.isPresent()) {
            double dd = on.get().distanceToSqr(eye);
            if (dd < best) {
               best = dd;
               hit = c;
            }
         }
      }

      if (hit == null || Game.teamOf(hit) == this.profile.team.team || hit instanceof net.minecraft.world.entity.npc.villager.Villager) {
         if (hit == null) {
            this.misses++;
         }

         return;
      }

      float dmg = (this.stickHit ? 1.0F : this.profile.swordDamage()) * (0.2F + strength * strength * 0.8F);
      boolean full = strength > 0.9F;
      boolean crit = full && !this.onGround() && this.getDeltaMovement().y < 0.0 && this.fallDistance > 0.0;
      if (crit) {
         dmg *= 1.5F;
      }

      boolean sprintHit = full && this.isSprinting();
      DamageSource src = this.damageSources().mobAttack(this);
      if (hit.hurtServer(level, src, dmg)) {
         if (sprintHit) {
            hit.knockback(0.5, Mth.sin(this.getYRot() * DEG), -Mth.cos(this.getYRot() * DEG), src, dmg);
            this.setDeltaMovement(this.getDeltaMovement().multiply(0.6, 1.0, 0.6));
            if (RND.nextDouble() < this.profile.hands.wtap) {
               this.wtap = 3 + RND.nextInt(3);
            }
         }

         if (this.stickHit) {
            hit.knockback(1.1 * strength, Mth.sin(this.getYRot() * DEG), -Mth.cos(this.getYRot() * DEG), src, dmg);
            Game.count("rueckstoss-stock");
         }

         if (crit) {
            level.sendParticles(ParticleTypes.CRIT, hit.getX(), hit.getY() + hit.getBbHeight() * 0.5, hit.getZ(), 10, 0.3, 0.4, 0.3, 0.2);
            level.playSound(null, hit.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.0F, 1.0F);
         } else {
            level.playSound(null, hit.blockPosition(), !full ? SoundEvents.PLAYER_ATTACK_WEAK : (sprintHit ? SoundEvents.PLAYER_ATTACK_KNOCKBACK : SoundEvents.PLAYER_ATTACK_STRONG), SoundSource.PLAYERS, 1.0F, 1.0F);
         }

         this.setLastHurtMob(hit);
         this.hits++;
      }
   }

   /** Fadenkreuz Richtung Ziel bewegen: begrenzte Drehgeschwindigkeit, Nachziehen, Zittern, Ueberschiessen. */
   private void aimAt(Vec3 point) {
      this.aiming = true;
      this.aimPoint = point;
   }

   private void updateAim() {
      Hands h = this.profile.hands;
      if (!this.aiming || this.aimPoint == null) {
         this.aimYaw = this.getYHeadRot();
         this.aimPitch = this.getXRot();
         return;
      }

      Vec3 eye = this.getEyePosition();
      double dx = this.aimPoint.x - eye.x;
      double dy = this.aimPoint.y - eye.y;
      double dz = this.aimPoint.z - eye.z;
      float wantYaw = yawOf(dx, dz);
      float wantPitch = (float)(-Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
      float errYaw = Mth.wrapDegrees(wantYaw - this.aimYaw);
      float errPitch = wantPitch - this.aimPitch;
      double gain = h.aimGain * (1.0 - this.profile.tilt * 0.3);
      if (Math.abs(errYaw) > 25.0F) {
         gain *= 1.0 + h.overshoot;
      }

      double max = h.aimSpeed();
      this.aimNoiseYaw = this.aimNoiseYaw * 0.75 + RND.nextGaussian() * h.aimNoise * 0.45 * (1.0 + this.profile.tilt);
      this.aimNoisePitch = this.aimNoisePitch * 0.75 + RND.nextGaussian() * h.aimNoise * 0.25;
      this.aimYaw += (float)(Mth.clamp(errYaw * gain, -max, max) + this.aimNoiseYaw * 0.35);
      this.aimPitch = Mth.clamp(this.aimPitch + (float)(Mth.clamp(errPitch * gain, -max, max) + this.aimNoisePitch * 0.35), -90.0F, 90.0F);
   }

   private boolean walkableTowards(Vec3 target) {
      Vec3 from = this.position();
      Vec3 delta = target.subtract(from).multiply(1.0, 0.0, 1.0);
      double len = delta.length();
      if (len < 0.5) {
         return true;
      } else {
         Vec3 step = delta.scale(1.0 / len);

         for (double t = 0.8; t < len; t += 0.8) {
            Vec3 p = from.add(step.scale(t));
            if (!this.groundAt(p)) {
               return false;
            }

            BlockPos feet = BlockPos.containing(p.x, this.getY() + 0.1, p.z);
            if (this.solid(feet) && this.solid(feet.above())) {
               return false;
            }
         }

         return true;
      }
   }

   /** Hochbauen: springen und im hoechsten Punkt einen Block unter sich setzen. */
   private boolean tickPillar(ServerLevel level) {
      if (this.pillarLeft <= 0) {
         return false;
      } else if (this.profile.blocks() == 0 || this.solid(this.blockPosition().above(2))) {
         this.pillarLeft = 0;
         return false;
      } else {
         if (this.onGround()) {
            this.pillarBase = this.blockPosition();
            this.jump = true;
         } else if (this.pillarBase != null && this.getY() >= this.pillarBase.getY() + 1.02 && this.placeCd == 0) {
            if (this.place(level, this.pillarBase, false, 1)) {
               Game.count("hochgebaut");
               this.pillarLeft--;
               this.pillarBase = null;
            }
         }

         this.lookPos = Vec3.atCenterOf(this.blockPosition().below());
         return true;
      }
   }

   // ======================================================================== Spezial-Items

   private void holdItem(net.minecraft.world.item.Item item) {
      if (this.held != HeldItem.OTHER || !this.getMainHandItem().is(item)) {
         this.held = HeldItem.OTHER;
         this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(item));
      }
   }

   /** Steht dieses Wesen nah an einer Kante zur Leere? */
   private boolean nearVoid(LivingEntity e) {
      Vec3 away = e.position().subtract(this.position()).multiply(1.0, 0.0, 1.0);
      if (away.lengthSqr() < 1.0E-4) {
         return false;
      }

      Vec3 behind = e.position().add(away.normalize().scale(1.6));
      BlockPos base = BlockPos.containing(behind.x, e.getY() - 0.2, behind.z);
      for (int i = 0; i <= 6; i++) {
         if (this.solid(base.below(i))) {
            return false;
         }
      }

      return true;
   }

   /** Wirft/schiesst etwas mit Vorhalt und menschlicher Streuung in Richtung eines Punktes. */
   private void launch(net.minecraft.world.entity.projectile.Projectile proj, Vec3 target, double speed, double gravity) {
      Vec3 eye = this.getEyePosition();
      Vec3 to = target.subtract(eye);
      double horiz = Math.sqrt(to.x * to.x + to.z * to.z);
      double ticks = horiz / speed;
      double vy = (to.y + 0.5 * gravity * ticks * ticks) / Math.max(1.0, ticks);
      Vec3 v = new Vec3(to.x / Math.max(1.0E-3, horiz) * speed, vy, to.z / Math.max(1.0E-3, horiz) * speed);
      double spread = this.profile.hands.aimNoise * 0.012 * (1.0 + this.profile.tilt);
      v = v.add(RND.nextGaussian() * spread, RND.nextGaussian() * spread * 0.5, RND.nextGaussian() * spread);
      proj.setPos(eye.x, eye.y - 0.1, eye.z);
      proj.setDeltaMovement(v);
      proj.needsSync = true;
      this.lookPos = target;
      this.swingArm();
   }

   /** Bogen (auf Abstand) und Bettwanze (mittlere Entfernung) im Kampf. */
   private boolean useRangedItem(ServerLevel level, LivingEntity e, double d) {
      BotProfile p = this.profile;
      boolean sees = this.hasLineOfSight(e);
      if (p.bedbugs > 0 && d > 4.0 && d < 16.0 && sees && RND.nextDouble() < 0.08) {
         BwEntities.Thrown bug = new BwEntities.Thrown(level, this, BwEntities.Thrown.Kind.BEDBUG, p.team);
         this.launch(bug, e.position(), 1.2, 0.03);
         level.addFreshEntity(bug);
         this.holdItem(Items.SNOWBALL);
         p.bedbugs--;
         this.itemCd = 40;
         Game.count("bettwanze");
         return true;
      }

      // Schneebaelle auf Gegner ueber der Leere (Brueckenbauer) - schubsen sie runter
      boolean overVoid = this.nearVoid(e) || !Game.arena().onAnyIsland(e.position());
      if (p.snowballs > 0 && overVoid && d > 4.0 && d < 24.0 && sees && RND.nextDouble() < 0.35) {
         net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball ball =
            new net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball(level, this, new ItemStack(Items.SNOWBALL));
         Vec3 lead = Game.pastPosition(e, p.hands.reaction).add(e.getDeltaMovement().scale(d / 1.5 * p.skill)).add(0.0, e.getBbHeight() * 0.5, 0.0);
         this.launch(ball, lead, 1.5, 0.03);
         level.addFreshEntity(ball);
         level.playSound(null, this.blockPosition(), SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.6F, 0.8F);
         this.holdItem(Items.SNOWBALL);
         p.snowballs--;
         this.itemCd = 5 + RND.nextInt(6);
         this.afterItem();
         Game.count("schneeball");
         return true;
      }

      if (p.bow && p.arrows > 0 && d > 8.0 && d < 32.0 && sees && RND.nextDouble() < 0.5) {
         Vec3 seen = Game.pastPosition(e, p.hands.reaction);
         Vec3 lead = seen.add(e.getDeltaMovement().scale(d / 2.6 * p.skill)).add(0.0, e.getBbHeight() * 0.6, 0.0);
         net.minecraft.world.entity.projectile.arrow.Arrow arrow = new net.minecraft.world.entity.projectile.arrow.Arrow(level, this, new ItemStack(Items.ARROW), new ItemStack(Items.BOW));
         arrow.pickup = net.minecraft.world.entity.projectile.arrow.AbstractArrow.Pickup.DISALLOWED;
         if (p.powerBow) {
            arrow.setBaseDamage(3.0);
         }
         this.launch(arrow, lead, 2.6, 0.05);
         level.addFreshEntity(arrow);
         level.playSound(null, this.blockPosition(), SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
         this.holdItem(Items.BOW);
         p.arrows--;
         // Bogen spannen dauert - menschliche Pause zwischen zwei Schuessen
         this.itemCd = 22 + RND.nextInt(18);
         this.afterItem();
         Game.count("pfeil");
         return true;
      }

      return false;
   }

   /**
    * Verteidigung mit Items: Traumverteidiger rufen, wenn Gegner auf der Insel sind; ist der Gegner
    * ueberlegen, einen Pop-Up-Turm als Deckung zwischen sich und ihn stellen.
    */
   private void useDefenseItems(ServerLevel level, LivingEntity e) {
      BotProfile p = this.profile;
      if (this.itemCd > 0 || !p.team.bedAlive || Game.arena().islandAt(this.position(), 2.0) != p.team.team) {
         return;
      }

      boolean threat = Game.arena().islandAt(e.position(), 6.0) == p.team.team;
      if (!threat) {
         return;
      }

      if (p.golems > 0) {
         BlockPos at = p.team.island().at(this.profile.name.hashCode() % 2 == 0 ? 3 : -3, 1, 1);
         BwItems.summonGolem(level, p.team, at, "[" + p.team.team.label + "] " + p.name);
         p.golems--;
         this.holdItem(Items.IRON_GOLEM_SPAWN_EGG);
         this.itemCd = 40;
         Game.count("golem");
         return;
      }

      double d = this.distanceTo(e);
      // Pop-Up-Turm: wer im Nachteil ist (oder ihn besonders mag), stellt sich einen hin - Hoehenvorteil am Bett
      double edge = "popupturm".equals(p.favorite) ? 2.0 : -1.0;
      if (p.popupTowers > 0 && d > 4.0 && d < 16.0 && this.advantageOver(e) < edge && this.onGround()
         && this.position().distanceTo(p.team.island().bedCenter()) < 9.0) {
         Vec3 to = e.position().subtract(this.position());
         net.minecraft.core.Direction dir = net.minecraft.core.Direction.getApproximateNearest(to.x, 0.0, to.z);
         if (BwItems.buildTower(level, this.blockPosition().relative(dir, -1), dir, p.team)) {
            p.popupTowers--;
            this.holdItem(Items.CHEST);
            this.itemCd = 60;
            Game.count("pop-up-turm");
         }
      }
   }

   /**
    * Vor und waehrend eines Angriffs: Tempotrank beim Losgehen, Magische Milch vor einer Insel mit Fallen,
    * Bruecken-Ei oder Enderperle, wenn die Bloecke nicht reichen.
    */
   private boolean useRaidItems(ServerLevel level, Game.TeamState target) {
      BotProfile p = this.profile;
      boolean atHome = Game.arena().islandAt(this.position(), 2.0) == p.team.team;
      if (!atHome && this.raidPrepFor != p.taskSince) {
         this.raidPrepFor = p.taskSince;
         if (p.invisPotions > 0) {
            p.invisPotions--;
            this.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 600, 0));
            level.playSound(null, this.blockPosition(), SoundEvents.GENERIC_DRINK.value(), SoundSource.PLAYERS, 0.8F, 1.0F);
            Game.count("unsichtbar");
         }

         if (p.speedPotions > 0) {
            p.speedPotions--;
            this.addEffect(new MobEffectInstance(MobEffects.SPEED, 900, 1));
            this.holdItem(Items.POTION);
            level.playSound(null, this.blockPosition(), SoundEvents.GENERIC_DRINK.value(), SoundSource.PLAYERS, 0.8F, 1.0F);
            Game.count("tempotrank");
         }
      }

      if (p.milk > 0 && !target.traps.isEmpty() && this.position().distanceTo(target.island().centerVec()) < Arena.ISLAND_RADIUS + 12) {
         p.milk--;
         BwItems.drinkMilk(this);
         Game.count("milch");
      }

      if (!atHome || this.ticks - this.lastTravelItemAt < 300 || !this.onGround()) {
         return false;
      }

      Vec3 goal = target.island().centerVec();
      Vec3 me = this.position();
      double dist = Math.hypot(goal.x - me.x, goal.z - me.z);
      boolean shortOf = this.shortOfBlocks || p.blocks() < 20;
      // nur vom Inselrand aus, Richtung Ziel
      Vec3 toGoal = new Vec3(goal.x - me.x, 0.0, goal.z - me.z).normalize();
      boolean atEdge = !this.solid(BlockPos.containing(me.add(toGoal.scale(1.6))).below());
      if (!atEdge || dist > 52.0) {
         return false;
      }

      if (p.pearls > 0 && (shortOf || RND.nextDouble() < p.aggression * 0.3)) {
         // auf die Kante der Zielinsel, die zu uns zeigt
         Vec3 land = goal.add(toGoal.scale(-(Arena.ISLAND_RADIUS - 2))).add(0.0, -0.5, 0.0);
         BwEntities.Thrown pearl = new BwEntities.Thrown(level, this, BwEntities.Thrown.Kind.PEARL, p.team);
         this.launch(pearl, land, 1.4, 0.03);
         level.addFreshEntity(pearl);
         this.holdItem(Items.ENDER_PEARL);
         p.pearls--;
         this.lastTravelItemAt = this.ticks;
         this.path = null;
         Game.count("enderperle");
         return true;
      }

      if (p.bridgeEggs > 0 && shortOf) {
         // flach werfen: die Bruecke entsteht unter der Flugbahn
         Vec3 aim = me.add(toGoal.scale(Math.min(dist, 34.0))).add(0.0, this.getEyeHeight() + 0.6, 0.0);
         BwEntities.Thrown egg = new BwEntities.Thrown(level, this, BwEntities.Thrown.Kind.BRIDGE_EGG, p.team);
         this.launch(egg, aim, 1.5, 0.03);
         level.addFreshEntity(egg);
         this.holdItem(Items.EGG);
         p.bridgeEggs--;
         this.lastTravelItemAt = this.ticks;
         this.shortOfBlocks = false;
         this.path = null;
         Game.count("bruecken-ei");
         return true;
      }

      return false;
   }

   /** Wasser am gegnerischen Bett mit einem Schwamm aufsaugen. */
   private boolean useSponge(ServerLevel level, Game.TeamState target) {
      BotProfile p = this.profile;
      if (p.sponges <= 0 || this.itemCd > 0 || this.position().distanceTo(target.island().bedCenter()) > 6.0) {
         return false;
      }

      BlockPos bed = target.island().bedFoot();
      BlockPos best = null;
      for (BlockPos q : BlockPos.betweenClosed(bed.offset(-3, -1, -3), bed.offset(3, 3, 3))) {
         if (!level.getFluidState(q).isEmpty() && level.getBlockState(q).canBeReplaced() && this.placeable(level, q)
            && (best == null || q.distSqr(this.blockPosition()) < best.distSqr(this.blockPosition()))) {
            best = q.immutable();
         }
      }

      if (best == null) {
         return false;
      }

      this.holdItem(Items.SPONGE);
      this.lookPos = Vec3.atCenterOf(best);
      this.swingArm();
      level.setBlock(best, net.minecraft.world.level.block.Blocks.SPONGE.defaultBlockState(), 3);
      p.sponges--;
      this.itemCd = 20;
      this.path = null;
      Game.count("schwamm");
      return true;
   }

   /** Woll-Verteidigung aus der Entfernung mit Feuerbaellen wegsprengen - bevor man hingeht. */
   private boolean fireballDefense(ServerLevel level, Game.TeamState target) {
      BotProfile p = this.profile;
      if (p.fireballs <= 0 || this.fireCd > 0 || this.itemCd > 0) {
         return false;
      }

      double d = this.position().distanceTo(target.island().bedCenter());
      if (d < 5.0 || d > 15.0 || RND.nextDouble() > 0.04 + p.skill * 0.06) {
         return false;
      }

      Vec3 eye = this.getEyePosition();
      for (Game.DefenseCell c : target.defensePlan()) {
         BlockState st = level.getBlockState(c.pos());
         if (st.is(net.minecraft.tags.BlockTags.WOOL) && !BwEntities.touchesWater(level, c.pos())) {
            Vec3 cc = Vec3.atCenterOf(c.pos());
            BlockHitResult hit = level.clip(new ClipContext(eye, cc, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(c.pos())) {
               this.throwFireballAt(level, cc);
               Game.count("feuerball-verteidigung");
               return true;
            }
         }
      }

      return false;
   }

   /** TNT an die Bett-Verteidigung legen und zuruecktreten. */
   private boolean useTnt(ServerLevel level, Game.TeamState target) {
      BotProfile p = this.profile;
      if (p.tnt <= 0 || this.breakPos == null || this.itemCd > 0) {
         return false;
      }

      if (this.position().distanceTo(target.island().bedCenter()) > 5.0 || target.fortificationStrength() < 12) {
         return false;
      }

      BlockPos at = null;
      for (net.minecraft.core.Direction dd : net.minecraft.core.Direction.values()) {
         BlockPos c = this.breakPos.relative(dd);
         if (level.getBlockState(c).isAir() && !Game.arena().isMap(c) && this.getEyePosition().distanceTo(Vec3.atCenterOf(c)) < 4.5
            && (at == null || c.distSqr(this.blockPosition()) < at.distSqr(this.blockPosition()))) {
            at = c;
         }
      }

      if (at == null) {
         return false;
      }

      this.cancelBreak(level);
      BwEntities.Tnt tnt = new BwEntities.Tnt(level, at.getX() + 0.5, at.getY(), at.getZ() + 0.5, this);
      level.addFreshEntity(tnt);
      level.playSound(null, at, SoundEvents.TNT_PRIMED, SoundSource.BLOCKS, 1.0F, 1.0F);
      this.holdItem(Items.TNT);
      p.tnt--;
      this.tntAt = Vec3.atCenterOf(at);
      this.tntBackoffUntil = this.ticks + 60;
      this.itemCd = 60;
      this.path = null;
      Game.count("tnt");
      return true;
   }

   /**
    * Reflexe wie bei einem Spieler: Schild hoch gegen Pfeile, Feuerbaelle zurueckschlagen, ausweichen.
    * Wie gut, haengt von PvP und Uebersicht ab - Anfaenger reagieren kaum.
    */
   private void reflexes(ServerLevel level) {
      if (this.ticks < this.dodgeUntil && this.dodgeDir != null) {
         Vec3 d = this.safe(this.dodgeDir);
         if (d != null) {
            this.moveDir = d;
            this.sprint = true;
         }
      }

      if (this.shieldUntil > 0 && this.ticks >= this.shieldUntil) {
         this.shieldUntil = 0;
         if (this.isUsingItem() && this.eatTicks == 0) {
            this.stopUsingItem();
         }

         this.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
      }

      if (this.reflexCd > 0) {
         this.reflexCd--;
         return;
      }

      this.reflexCd = 2;
      Hands h = this.profile.hands;
      for (net.minecraft.world.entity.projectile.Projectile pr : level.getEntitiesOfClass(net.minecraft.world.entity.projectile.Projectile.class,
         this.getBoundingBox().inflate(10.0), x -> x.isAlive() && x.getOwner() != this)) {
         if (pr.getOwner() != null && Game.teamOf(pr.getOwner()) == this.profile.team.team) {
            continue;
         }

         Vec3 v = pr.getDeltaMovement();
         Vec3 to = this.position().add(0.0, 1.0, 0.0).subtract(pr.position());
         if (v.lengthSqr() < 1.0E-3 || v.dot(to) <= 0.0) {
            continue;
         }

         // wie nah kommt das Geschoss an ihm vorbei?
         Vec3 vn = v.normalize();
         double along = to.dot(vn);
         double miss = to.subtract(vn.scale(along)).length();
         if (miss > 1.6) {
            continue;
         }

         double dist = to.length();
         boolean fireball = pr instanceof BwEntities.Fireball;
         if (fireball && dist < 4.0 && h.deflect > 0.0 && RND.nextDouble() < h.deflect * 0.5) {
            // zurueckschlagen: zum Werfer schauen und draufhauen
            Entity owner = pr.getOwner();
            Vec3 back = owner != null ? owner.getEyePosition() : this.getEyePosition().subtract(vn.scale(10.0));
            Vec3 dir = back.subtract(this.getEyePosition());
            this.setYRot(yawOf(dir.x, dir.z));
            this.setXRot((float)(-Mth.atan2(dir.y, Math.sqrt(dir.x * dir.x + dir.z * dir.z)) * (180.0 / Math.PI)));
            this.hold(HeldItem.SWORD);
            this.swingArm();
            pr.hurtServer(level, this.damageSources().mobAttack(this), 1.0F);
            Game.count("feuerball-zurueck");
            this.reflexCd = 10;
            return;
         }

         if (pr instanceof net.minecraft.world.entity.projectile.arrow.AbstractArrow && this.profile.shield && dist < 10.0 && this.eatTicks == 0
            && RND.nextDouble() < 0.4 + h.sense * 0.5) {
            // Schild hoch
            this.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
            this.startUsingItem(InteractionHand.OFF_HAND);
            this.shieldUntil = this.ticks + 15;
            Game.count("schild");
            this.reflexCd = 10;
            return;
         }

         if (dist < 9.0 && RND.nextDouble() < h.dodge * 0.35) {
            Vec3 side = new Vec3(-vn.z, 0.0, vn.x);
            if (RND.nextBoolean()) {
               side = side.scale(-1.0);
            }

            this.dodgeDir = side;
            this.dodgeUntil = this.ticks + 6 + RND.nextInt(5);
            Game.count("ausweichen");
            this.reflexCd = 8;
            return;
         }
      }
   }

   private void throwFireball(ServerLevel level, LivingEntity e) {
      Vec3 eye = this.getEyePosition();
      double d = this.distanceTo(e);
      Vec3 seen = Game.pastPosition(e, this.profile.hands.reaction);
      Vec3 aim = seen.add(0.0, e.getBbHeight() * 0.5, 0.0).add(e.getDeltaMovement().scale(d * 0.9 * this.profile.skill));
      Vec3 dir = aim.subtract(eye).normalize();
      double spread = this.profile.hands.aimNoise * 0.02;
      dir = dir.add(RND.nextGaussian() * spread, RND.nextGaussian() * spread * 0.5, RND.nextGaussian() * spread).normalize();
      this.hold(HeldItem.FIREBALL);
      this.lookPos = aim;
      BwEntities.Fireball fb = new BwEntities.Fireball(level, this, dir.scale(0.1));
      fb.setPos(eye.x + dir.x * 1.4, eye.y + dir.y * 1.4, eye.z + dir.z * 1.4);
      level.addFreshEntity(fb);
      level.playSound(null, this.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
      this.swingArm();
      this.profile.fireballs--;
      this.fireCd = 70 + RND.nextInt(50);
      Game.count("feuerball");
      this.afterItem();
   }

   /** Feuerball auf eine Stelle (z.B. die Woll-Verteidigung eines Betts). */
   private void throwFireballAt(ServerLevel level, Vec3 aim) {
      Vec3 eye = this.getEyePosition();
      Vec3 dir = aim.subtract(eye).normalize();
      double spread = this.profile.hands.aimNoise * 0.012;
      dir = dir.add(RND.nextGaussian() * spread, RND.nextGaussian() * spread * 0.5, RND.nextGaussian() * spread).normalize();
      this.hold(HeldItem.FIREBALL);
      this.lookPos = aim;
      BwEntities.Fireball fb = new BwEntities.Fireball(level, this, dir.scale(0.1));
      fb.setPos(eye.x + dir.x * 1.4, eye.y + dir.y * 1.4, eye.z + dir.z * 1.4);
      level.addFreshEntity(fb);
      level.playSound(null, this.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
      this.swingArm();
      this.profile.fireballs--;
      this.fireCd = 60 + RND.nextInt(40);
      this.afterItem();
   }

   // ======================================================================== Essen

   private boolean shouldEat() {
      if (this.ticks < this.gappleDecisionAt) {
         return false;
      } else if (this.profile.gapples > 0 && this.getHealth() < 10.0F && RND.nextDouble() < this.profile.hands.forgetGapple * 0.05) {
         // vergisst den Goldapfel - passiert
         Game.count("apfel-vergessen");
         this.gappleDecisionAt = this.ticks + 100;
         return false;
      }

      return this.profile.gapples > 0
         && this.eatTicks == 0
         && this.getHealth() < 9.0F + (float)(this.profile.caution * 4.0)
         && !this.hasEffect(MobEffects.REGENERATION)
         && (this.enemy == null || this.distanceTo(this.enemy) > 3.5 || this.getHealth() < 5.0F);
   }

   private void startEating() {
      this.profile.gapples--;
      this.eatTicks = 33;
      this.hold(HeldItem.GAPPLE);
      this.startUsingItem(InteractionHand.MAIN_HAND);
   }

   private void tickEating() {
      if (this.eatTicks > 0) {
         this.eatTicks--;
         if (this.eatTicks == 0) {
            if (!this.hasEffect(MobEffects.REGENERATION)) {
               this.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
               this.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0));
               this.level().playSound(null, this.blockPosition(), SoundEvents.PLAYER_BURP, SoundSource.PLAYERS, 0.6F, 1.0F);
            }

            this.stopUsingItem();
            this.hold(HeldItem.SWORD);
         }
      }
   }

   private void retreatWhileEating(ServerLevel level) {
      if (this.enemy != null && this.distanceTo(this.enemy) < 6.0) {
         Vec3 away = this.position().subtract(this.enemy.position()).multiply(1.0, 0.0, 1.0);
         this.moveDir = this.safe(away);
         this.lookPos = this.enemy.getEyePosition();
         if (this.distanceTo(this.enemy) < 2.2 && this.profile.hands.style != Hands.Style.NOOB && RND.nextDouble() < 0.1) {
            this.stopUsingItem();
            this.eatTicks = 0;
            this.profile.gapples++;
            this.hold(HeldItem.SWORD);
         }
      }
   }

   // ======================================================================== Auftraege

   private void doTask(ServerLevel level) {
      BotProfile p = this.profile;
      switch (p.task) {
         case GATHER -> this.taskGather(level);
         case SHOP -> this.taskShop(level);
         case FORTIFY -> this.taskFortify(level, false);
         case DEFEND -> this.taskDefend(level);
         case RAID -> this.taskRaid(level);
         case MID -> this.taskMid(level);
         case HUNT -> this.taskHunt(level);
         case ESCORT, FOLLOW_PLAYER -> this.taskEscort(level);
         case RETREAT, REGROUP -> this.taskHome(level);
         case CUT_BRIDGE -> this.taskCutBridge(level);
         case HOLD -> this.taskHold(level);
         default -> this.idle(level);
      }
   }

   public void finishTask() {
      this.profile.task = BotProfile.Task.IDLE;
      this.profile.taskEntity = null;
      this.profile.taskTeam = null;
      this.profile.taskPos = null;
      this.profile.taskLockUntil = 0;
      this.path = null;
      this.bedMining = 0;
      TeamBrain.requestThink(this.profile.team);
   }

   private void idle(ServerLevel level) {
      this.hold(HeldItem.SWORD);
      if (this.ticks >= this.idleTurnAt) {
         this.idleTurnAt = this.ticks + 20 + RND.nextInt(50);
         this.faceYaw = this.getYRot() + (float)(RND.nextGaussian() * 60.0);
      }
   }

   /** Steht ein echter Teamkollege am Spawner? Dann macht der Bot Platz und sammelt nichts auf. */
   private boolean humanAtGenerator() {
      Arena.Island is = this.profile.team.island();
      AABB pad = is.generatorArea().inflate(2.5, 1.0, 2.5);
      for (Game.Human h : this.profile.team.humans) {
         if (h.active() && pad.contains(h.p.position())) {
            return true;
         }
      }

      return false;
   }

   /** Jeder Bot hat seinen eigenen Platz am Rand der Spawner-Flaeche - keiner blockiert die Mitte. */
   private BlockPos gatherSpot() {
      Arena.Island is = this.profile.team.island();
      int w = Arena.Island.GEN_HALF_WIDTH;
      int k = Math.floorMod(this.profile.name.hashCode(), 4);
      if (this.humanAtGenerator()) {
         // Platz machen: neben die Flaeche
         return is.at(k < 2 ? -(w + 2) : w + 2, 1, k % 2 == 0 ? -6 : -4);
      }

      return is.at(k < 2 ? -w : w, 1, k % 2 == 0 ? -7 : -5);
   }

   /**
    * Wie ein Spieler ueber die Spawner-Flaeche laufen und einsammeln, was dort liegt (sonst bleibt Eisen in der Mitte
    * liegen, bis der Spawner voll ist). Echten Teamkollegen lassen Bots den Vortritt.
    */
   private boolean sweepGenerator(ServerLevel level) {
      AABB pad = this.profile.team.island().generatorArea();
      if (this.enemy != null || this.humanAtGenerator() || !pad.inflate(2.5, 1.0, 2.5).contains(this.position())) {
         return false;
      }

      ItemEntity best = null;
      double bd = Double.MAX_VALUE;
      for (ItemEntity e : level.getEntitiesOfClass(ItemEntity.class, pad.inflate(0.6, 0.5, 0.6))) {
         ItemStack st = e.getItem();
         if (e.tickCount < 6 || !(st.is(Items.IRON_INGOT) || st.is(Items.GOLD_INGOT) || st.is(Items.DIAMOND) || st.is(Items.EMERALD))) {
            continue;
         }

         // Gold und Edelsteine zuerst, sonst das naechste
         double d = e.distanceToSqr(this) - (st.is(Items.IRON_INGOT) ? 0.0 : 4.0);
         if (d < bd) {
            bd = d;
            best = e;
         }
      }

      if (best == null) {
         return false;
      }

      this.go(best.position(), false);
      if (this.ticks % 10 == 0) {
         this.lookPos = best.position();
      }

      return true;
   }

   private void taskGather(ServerLevel level) {
      BlockPos gen = this.gatherSpot();
      if (this.sweepGenerator(level)) {
         if (this.ticks % 60 == 0 && TeamBrain.wantsToShop(this.profile)) {
            this.profile.afterShop = BotProfile.Task.GATHER;
            this.profile.task = BotProfile.Task.SHOP;
         }

         return;
      }

      Nav nav = this.navigate(level, Pathfinder.near(gen, 0.7), "gather" + gen.asLong(), false, false, 80);
      if (nav == Nav.ARRIVED || nav == Nav.FAILED) {
         this.go(Vec3.atBottomCenterOf(gen), false);
         this.idle(level);
         if (this.ticks % 60 == 0 && TeamBrain.wantsToShop(this.profile)) {
            this.profile.afterShop = BotProfile.Task.GATHER;
            this.profile.task = BotProfile.Task.SHOP;
         }
      }
   }

   /** Am eigenen Generator warten, bis das Team sich etwas leisten kann - ohne den Auftrag zu wechseln. */
   private void waitAtGenerator(ServerLevel level) {
      BlockPos gen = this.gatherSpot();
      if (this.sweepGenerator(level)) {
         return;
      }

      Nav nav = this.navigate(level, Pathfinder.near(gen, 0.7), "gather" + gen.asLong(), false, false, 80);
      if (nav == Nav.ARRIVED || nav == Nav.FAILED) {
         this.go(Vec3.atBottomCenterOf(gen), false);
         this.idle(level);
      }
   }

   private void taskShop(ServerLevel level) {
      Arena.Island is = this.profile.team.island();
      Nav nav = this.navigate(level, Pathfinder.near(is.shopFront(), 1.3), "shop", true, false, 80);
      if (nav == Nav.ARRIVED || this.position().distanceTo(Vec3.atBottomCenterOf(is.shopFront())) < 2.0) {
         this.lookPos = is.shop().add(0.0, 1.5, 0.0);
         String bought = this.profile.shop();
         this.profile.equipArmor(this);
         this.hold(HeldItem.NONE);
         this.hold(HeldItem.SWORD);
         if (bought != null) {
            BotChat.purchase(this.profile, bought);
         }

         BotProfile.Task next = this.profile.afterShop;
         this.profile.afterShop = BotProfile.Task.IDLE;
         if (next == BotProfile.Task.IDLE || next == BotProfile.Task.SHOP) {
            this.finishTask();
         } else {
            this.profile.task = next;
            this.path = null;
         }
      } else if (nav == Nav.FAILED && this.failedPlans > 3) {
         this.finishTask();
      }
   }

   private void gotoShop(BotProfile.Task after) {
      this.profile.afterShop = after;
      this.profile.task = BotProfile.Task.SHOP;
      this.path = null;
   }

   /** Baut die Verteidigung ums eigene Bett, Schicht fuer Schicht von innen nach aussen. */
   private int matShopAt = -10000;
   private int fortifyWaitSince;

   /**
    * Baut die Verteidigung ums eigene Bett nach der Bauweise des Teams, Schicht fuer Schicht von innen nach
    * aussen. Bei der Wasser-Bauweise kommt nach der zweiten Schicht ein Wassereimer direkt aufs Bett.
    */
   private boolean taskFortify(ServerLevel level, boolean repairOnly) {
      Game.TeamState t = this.profile.team;
      if (!t.bedAlive) {
         if (!repairOnly) {
            this.finishTask();
         }

         return false;
      }

      if (t.defenseStyle == null) {
         // wer zuerst baut, entscheidet - jeder Bot hat seine eigene Lieblingsbauweise
         t.defenseStyle = this.profile.defensePref;
         t.defenseWater = this.profile.waterPref && t.defenseStyle.layers() >= 2;
         t.builderName = this.profile.name;
         if (RND.nextDouble() < 0.7) {
            BotChat.sayPlain(this.profile, "ich bau unser bett mit " + t.defenseStyle.label.toLowerCase() + (t.defenseWater ? " ein, und wasser kommt drauf" : " ein"), 30, true);
         }
      }

      int maxLayer = repairOnly ? Math.min(2, t.defenseLayers()) : t.defenseLayers();
      BlockPos cell = null;
      int layer = 0;

      for (int L = 1; L <= maxLayer && cell == null; L++) {
         for (Game.DefenseCell dc : t.defensePlan()) {
            if (dc.layer() == L && t.cellMissing(dc) && hasSupport(level, dc.pos())) {
               cell = dc.pos();
               layer = L;
               break;
            }
         }

         if (cell == null && L == 2 && t.defenseWater && !t.hasWater()) {
            Boolean w = this.pourWater(level, t, repairOnly);
            if (w != null) {
               return w;
            }
         }
      }

      // improvisierte Wolle in den inneren Schichten zuerst austauschen - spaeter kommt keiner mehr ran
      if (!repairOnly && (cell == null || layer > 1)) {
         Boolean up = this.fortifyUpgrade(level, t, cell == null ? 99 : layer);
         if (up != null) {
            return up;
         }
      }

      if (cell == null) {
         if (!repairOnly) {

            t.fortified = true;
            BotChat.event(this.profile, BotChat.Event.FORTIFIED, null);
            this.finishTask();
         }

         return false;
      }

      // fehlt das Material fuer diese Schicht, erst kaufen gehen (wenn das Geld reicht), sonst eine Weile dafuer
      // sammeln - wie ein Spieler, der auf Endstein spart. Erst nach einer Minute wird improvisiert.
      DefenseStyle.Mat want = t.defenseStyle.mat(layer);
      if (this.profile.count(want) == 0 && !repairOnly) {
         if (this.profile.canAffordMaterial(want) && this.ticks - this.matShopAt > 200) {
            this.matShopAt = this.ticks;
            this.fortifyWaitSince = 0;
            this.gotoShop(BotProfile.Task.FORTIFY);
            return false;
         }

         if (want != DefenseStyle.Mat.OBSIDIAN || Game.tick() > 20 * 300) {
            if (this.fortifyWaitSince == 0 || this.ticks - this.fortifyWaitSince > 2400) {
               this.fortifyWaitSince = this.ticks;
            }

            if (this.ticks - this.fortifyWaitSince < 400 + (int)(this.profile.hands.build * 400.0)) {
               this.waitAtGenerator(level);
               return true;
            }
         }
      }

      if (this.profile.blocks() + this.profile.glass + this.profile.terracotta + this.profile.obsidian == 0) {
         if (!repairOnly) {
            if (TeamBrain.canAfford(this.profile, 4)) {
               this.gotoShop(BotProfile.Task.FORTIFY);
            } else {
               this.waitAtGenerator(level);
            }
         }

         return false;
      }

      Vec3 cc = Vec3.atCenterOf(cell);
      double reach = this.getEyePosition().distanceTo(cc);
      boolean inside = this.getBoundingBox().intersects(new AABB(cell));
      if (reach <= 4.6 && !inside && this.onGround()) {
         this.lookPos = cc;
         if (this.placeCd == 0) {
            this.place(level, cell, true, layer);
         }

         return true;
      }

      BlockPos spot = t.nearestDefenseSpot(cell);
      Nav nav = this.navigate(level, Pathfinder.near(spot, 0.8), "fortify" + spot.asLong(), false, false, 80);
      if (nav == Nav.FAILED && this.failedPlans > 4) {
         this.finishTask();
      }

      return true;
   }

   /**
    * Wassereimer aufs Bett (eingeschlossen von der zweiten Schicht, es laeuft nicht weg).
    *
    * @return Ergebnis fuer taskFortify, oder null = ohne Wasser weiterbauen
    */
   private Boolean pourWater(ServerLevel level, Game.TeamState t, boolean repairOnly) {
      BlockPos src = t.waterSource();
      if (this.profile.waterBuckets <= 0) {
         if (!repairOnly && this.profile.gold >= 3 && this.ticks - this.matShopAt > 400) {
            this.matShopAt = this.ticks;
            this.gotoShop(BotProfile.Task.FORTIFY);
            return false;
         }

         return null;
      }

      if (!level.getBlockState(src).canBeReplaced()) {
         return null;
      }

      Vec3 cc = Vec3.atCenterOf(src);
      if (this.getEyePosition().distanceTo(cc) <= 5.0 && this.onGround()) {
         this.lookPos = cc;
         this.holdItem(Items.WATER_BUCKET);
         this.swingArm();
         level.setBlock(src, net.minecraft.world.level.block.Blocks.WATER.defaultBlockState(), 3);
         level.playSound(null, src, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
         this.profile.waterBuckets--;
         t.waterPlaced = true;
         this.placeCd = 10;
         Game.count("wasser-aufs-bett");
         return true;
      }

      BlockPos spot = t.nearestDefenseSpot(src);
      this.navigate(level, Pathfinder.near(spot, 0.8), "water" + spot.asLong(), false, false, 80);
      return true;
   }

   private int pillaredAt = -10000;
   private BlockPos upgradeCell;

   private int upgradeLayer;

   /**
    * Wolle abbauen und sofort das richtige Material hinsetzen - wie ein Spieler, der abbaut und im selben Moment
    * nachsetzt. So entsteht kein Loch, das ein Teamkollege wieder mit Wolle stopft.
    */
   private void swapCell(ServerLevel level, BlockPos pos, int layer) {
      this.mine(level, pos);
      if (level.getBlockState(pos).isAir()) {
         if (this.place(level, pos, true, layer)) {
            Game.count("verteidigung-verbessert");
         }

         this.upgradeCell = null;
      }
   }

   /**
    * Verteidigung nachbessern (im Verteidigungs-Modus): hat er das richtige Material dabei und steht improvisierte
    * Wolle in Reichweite, tauscht er sie aus.
    */
   private boolean upgradeDefense(ServerLevel level, Game.TeamState t) {
      if (!t.bedAlive || t.defenseStyle == null || this.enemy != null) {
         this.upgradeCell = null;
         return false;
      }

      if (this.upgradeCell != null) {
         if (level.getBlockState(this.upgradeCell).is(net.minecraft.tags.BlockTags.WOOL) && this.getEyePosition().distanceTo(Vec3.atCenterOf(this.upgradeCell)) <= 4.6) {
            this.swapCell(level, this.upgradeCell, this.upgradeLayer);
            return true;
         }

         this.upgradeCell = null;
         return false;
      }

      if (this.ticks % 20 != 5) {
         return false;
      }

      for (Game.DefenseCell c : t.defensePlan()) {
         if (t.isImprovised(c) && this.profile.count(t.defenseStyle.mat(c.layer())) > 0 && t.canUpgradeCell(c.pos())
            && this.getEyePosition().distanceTo(Vec3.atCenterOf(c.pos())) <= 4.4) {
            this.upgradeCell = c.pos();
            this.upgradeLayer = c.layer();
            return true;
         }
      }

      return false;
   }

   /**
    * Improvisierte Wolle gegen das Material der Bauweise tauschen (nur Schichten unter belowLayer): Geld da? Kaufen
    * gehen. Material da? Hingehen und austauschen.
    *
    * @return Ergebnis fuer taskFortify, oder null = nichts zu verbessern
    */
   private Boolean fortifyUpgrade(ServerLevel level, Game.TeamState t, int belowLayer) {
      if (this.enemy != null) {
         return null;
      }

      for (Game.DefenseCell c : t.defensePlan()) {
         if (c.layer() >= belowLayer || !t.isImprovised(c) || !t.canUpgradeCell(c.pos())) {
            continue;
         }

         DefenseStyle.Mat want = t.defenseStyle.mat(c.layer());
         if (this.profile.count(want) == 0) {
            if (this.profile.canAffordMaterial(want) && this.ticks - this.matShopAt > 200) {
               this.matShopAt = this.ticks;
               this.gotoShop(BotProfile.Task.FORTIFY);
               return false;
            }

            continue;
         }

         if (this.getEyePosition().distanceTo(Vec3.atCenterOf(c.pos())) <= 4.4 && this.onGround()) {
            this.lookPos = Vec3.atCenterOf(c.pos());
            this.swapCell(level, c.pos(), c.layer());
            return true;
         }

         BlockPos spot = t.nearestDefenseSpot(c.pos());
         Nav nav = this.navigate(level, Pathfinder.near(spot, 0.8), "upgrade" + spot.asLong(), false, false, 80);
         if (nav == Nav.FAILED && this.failedPlans > 4) {
            return null;
         }

         return true;
      }

      return null;
   }

   private void taskDefend(ServerLevel level) {
      Game.TeamState t = this.profile.team;
      // kommt ein ueberlegener Gegner, baut er sich am Bett hoch (Hoehenvorteil statt sinnlos sterben)
      LivingEntity threat = this.enemy != null ? this.enemy : this.profile.taskEntity;
      if (threat != null && threat.isAlive() && this.pillarLeft == 0 && this.onGround() && this.ticks - this.pillaredAt > 400 && this.profile.blocks() >= 4) {
         double d = this.distanceTo(threat);
         if (d > 4.0 && d < 14.0 && this.advantageOver(threat) < -5.0 && Game.arena().islandAt(this.position(), 1.0) == t.team
            && RND.nextDouble() < this.profile.hands.pillar) {
            this.pillarLeft = 2 + RND.nextInt(2);
            this.pillaredAt = this.ticks;
            Game.count("hochbauen-verteidigung");
            return;
         }
      }

      if (this.ticks % 50 == 0 && t.bedAlive && this.profile.blocks() > 0) {
         this.stayUntil = 0;
      }

      if (this.upgradeDefense(level, t)) {
         return;
      }

      if (t.bedAlive && this.profile.blocks() + this.profile.obsidian + this.profile.glass + this.profile.terracotta > 0 && t.missingDefense(2) > 0
         && this.taskFortify(level, true)) {
         return;
      }

      Arena.Island is = t.island();
      BlockPos guard = t.bedAlive ? is.at(this.profile.name.hashCode() % 2 == 0 ? 2 : -2, 1, 1) : is.at(0, 1, -2);
      Nav nav = this.navigate(level, Pathfinder.near(guard, 1.5), "guard", false, false, 100);
      if (nav == Nav.ARRIVED || nav == Nav.FAILED) {
         this.idle(level);
         if (this.ticks % 80 == 0 && TeamBrain.wantsToShop(this.profile)) {
            this.gotoShop(BotProfile.Task.DEFEND);
         }
      }
   }

   private void taskRaid(ServerLevel level) {
      BotProfile p = this.profile;
      Game.TeamState target = p.taskTeam;
      if (target == null || !target.alive() || target == p.team) {
         this.finishTask();
      } else if (!target.bedAlive) {
         LivingEntity victim = Game.nearestMember(target, this.position());
         if (victim == null) {
            this.finishTask();
         } else {
            p.task = BotProfile.Task.HUNT;
            p.taskEntity = victim;
            this.path = null;
         }
      } else {
         List<BlockPos> bed = Game.arena().bedBlocks(target.team);
         if (bed.isEmpty()) {
            this.finishTask();
         } else {
            if (this.ticks < this.tntBackoffUntil && this.tntAt != null) {
               // vom eigenen TNT weg, dann zurueck ans Bett
               Vec3 away = this.position().subtract(this.tntAt).multiply(1.0, 0.0, 1.0);
               this.moveDir = this.safe(away.lengthSqr() < 1.0E-3 ? new Vec3(1.0, 0.0, 0.0) : away.normalize());
               this.sprint = true;
               this.hold(HeldItem.SWORD);
               return;
            }

            if (this.useRaidItems(level, target) || this.useSponge(level, target) || this.fireballDefense(level, target)) {
               return;
            }

            BlockPos reachable = this.bedInReach(level, bed);
            if (Game.debug && this.ticks % 20 == 0 && this.position().distanceTo(target.island().bedCenter()) < 9.0) {
               Pathfinder.Step st = this.path != null && this.pathIdx < this.path.size() ? this.path.get(this.pathIdx) : null;
               Platform.info("[BW raid] " + p.name + "->" + target.team.label + " feet=" + this.feet().subtract(bed.get(0)).toShortString() + " y=" + String.format("%.2f", this.getY())
                  + " reach=" + (reachable != null) + " path=" + (this.path == null ? "null" : this.pathIdx + "/" + this.path.size() + (this.pathComplete ? "" : "~"))
                  + " step=" + (st == null ? "-" : st.move + "@" + st.pos.subtract(bed.get(0)).toShortString() + " br" + st.breaks.size())
                  + " brk=" + (this.breakPos == null ? "-" : this.breakPos.subtract(bed.get(0)).toShortString() + " " + this.breakProgress + "/" + this.breakTotal)
                  + " fail=" + this.failedPlans + " bl=" + p.blocks() + " enemy=" + (this.enemy == null ? "-" : String.format("%.1f", this.distanceTo(this.enemy))));
            }

            if (reachable != null) {
               this.path = null;
               this.lookPos = Vec3.atCenterOf(reachable);
               this.hold(HeldItem.SWORD);
               this.bedMining++;
               if (this.bedMining % 4 == 1) {
                  this.swingArm();
               }

               level.destroyBlockProgress(this.getId(), reachable, Math.min(9, this.bedMining * 10 / 18));
               int need = 18 - (int)(this.profile.skill * 6.0);
               if (this.isEyeInFluid(net.minecraft.tags.FluidTags.WATER)) {
                  need *= 2;
               }

               if (this.bedMining >= need) {
                  level.destroyBlockProgress(this.getId(), reachable, -1);
                  this.bedMining = 0;
                  Game.destroyBed(target, this.profile.team, this.profile, null);
                  this.finishTask();
               }
            } else {
               this.bedMining = 0;
               boolean atHome = Game.arena().islandAt(this.position(), 2.0) == p.team.team;
               if (atHome && (p.blocks() < 12 || this.shortOfBlocks && p.blocks() < 64) && TeamBrain.canAfford(p, 4)) {
                  this.shortOfBlocks = false;
                  this.gotoShop(BotProfile.Task.RAID);
                  return;
               }

               if (this.useTnt(level, target)) {
                  return;
               }

               Nav nav = this.navigate(level, Pathfinder.adjacent(bed), "raid" + target.team.ordinal(), true, true, 70);
               if (nav == Nav.FAILED) {
                  if (p.blocks() < 6) {
                     if (TeamBrain.canAfford(p, 4)) {
                        this.gotoShop(BotProfile.Task.RAID);
                     } else if (atHome && this.ticks - p.taskSince < 1200) {
                        this.waitAtGenerator(level);
                     } else {
                        this.finishTask();
                     }
                  } else if (this.failedPlans > 5) {
                     this.finishTask();
                  }
               }
            }
         }
      }
   }

   /** Ein Bettblock, den er von hier aus abbauen kann (er beruehrt ihn oder sieht ihn frei). */
   private BlockPos bedInReach(ServerLevel level, List<BlockPos> bed) {
      BlockPos feet = this.feet();

      for (BlockPos b : bed) {
         int dx = Math.abs(feet.getX() - b.getX());
         int dz = Math.abs(feet.getZ() - b.getZ());
         int dy = feet.getY() - b.getY();
         if (dx + dz == 1 && dy == 0 || dx == 0 && dz == 0 && (dy == 0 || dy == 1)) {
            return b;
         }
      }

      Vec3 eye = this.getEyePosition();

      for (BlockPos b : bed) {
         for (Vec3 off : new Vec3[]{new Vec3(0.5, 0.45, 0.5), new Vec3(0.1, 0.3, 0.5), new Vec3(0.9, 0.3, 0.5), new Vec3(0.5, 0.3, 0.1), new Vec3(0.5, 0.3, 0.9)}) {
            Vec3 c = Vec3.atLowerCornerOf(b).add(off);
            if (eye.distanceTo(c) <= 4.2) {
               BlockHitResult hit = level.clip(new ClipContext(eye, c, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
               if (hit.getType() == HitResult.Type.MISS || level.getBlockState(hit.getBlockPos()).getBlock() instanceof BedBlock) {
                  return b;
               }
            }
         }
      }

      return null;
   }

   private void taskMid(ServerLevel level) {
      BotProfile p = this.profile;
      if (p.taskPos == null) {
         p.taskPos = TeamBrain.pickMidSpot(p);
      }

      BlockPos spot = p.taskPos;
      Nav nav = this.navigate(level, Pathfinder.near(spot, 1.0), "mid" + spot.asLong(), true, true, 90);
      if (nav == Nav.ARRIVED) {
         if (this.stayUntil < this.ticks - 1000) {
            this.stayUntil = this.ticks + 260 + RND.nextInt(200);
         }

         this.go(Vec3.atBottomCenterOf(spot), false);
         this.idle(level);
         if (this.ticks >= this.stayUntil) {
            this.stayUntil = 0;
            this.finishTask();
         }
      } else if (nav == Nav.FAILED) {
         if (p.blocks() < 8 && Game.arena().islandAt(this.position(), 2.0) == p.team.team && TeamBrain.canAfford(p, 4)) {
            this.gotoShop(BotProfile.Task.MID);
         } else if (this.failedPlans > 4) {
            this.finishTask();
         }
      }
   }

   private void taskHunt(ServerLevel level) {
      LivingEntity target = this.profile.taskEntity;
      if (target == null || !target.isAlive() || target.isRemoved() || !Game.isEnemy(this.profile.team, target)) {
         this.finishTask();
      } else if (target instanceof ServerPlayer sp && sp.isSpectator()) {
         this.finishTask();
      } else {
         boolean bridge = this.profile.blocks() > 0;
         Nav nav = this.navigate(level, Pathfinder.near(target.blockPosition(), 1.8), "hunt" + target.getId(), bridge, true, 25);
         this.hold(HeldItem.SWORD);
         if (nav == Nav.FAILED && this.failedPlans > 6) {
            this.finishTask();
         }
      }
   }

   private void taskEscort(ServerLevel level) {
      LivingEntity lead = this.profile.taskEntity;
      if (lead == null || !lead.isAlive() || lead.isRemoved() || lead instanceof ServerPlayer sp && sp.isSpectator()) {
         this.finishTask();
      } else {
         double d = this.distanceTo(lead);
         if (d > 4.0) {
            Nav nav = this.navigate(level, Pathfinder.near(lead.blockPosition(), 2.5), "escort" + lead.getId(), true, true, 25);
            if (nav == Nav.FAILED && this.failedPlans > 8) {
               this.finishTask();
            }
         } else {
            this.path = null;
            this.lookPos = lead.getEyePosition();
            this.idle(level);
         }
      }
   }

   private void taskHome(ServerLevel level) {
      Arena.Island is = this.profile.team.island();
      BlockPos spot = BlockPos.containing(is.spawn());
      Nav nav = this.navigate(level, Pathfinder.near(spot, 2.0), "home", true, true, 80);
      if (nav == Nav.ARRIVED || nav == Nav.FAILED && this.failedPlans > 4) {
         this.idle(level);
         if (this.getHealth() > 15.0F && this.ticks % 40 == 0) {
            if (TeamBrain.wantsToShop(this.profile)) {
               this.gotoShop(BotProfile.Task.IDLE);
            } else {
               this.finishTask();
            }
         }
      }
   }

   /** Eine Stelle halten (auf Befehl): hinlaufen, dort stehen, Gegner in der Naehe bekaempfen. */
   private void taskHold(ServerLevel level) {
      BlockPos spot = this.profile.taskPos;
      if (spot == null) {
         this.finishTask();
         return;
      }

      Nav nav = this.navigate(level, Pathfinder.near(spot, 1.2), "hold" + spot.asLong(), true, false, 80);
      if (nav == Nav.ARRIVED || nav == Nav.FAILED && this.failedPlans > 4) {
         this.idle(level);
      }
   }

   /** Fuer Befehle: Pop-Up-Turm, Golem oder Hochbauen sofort. */
   public boolean commandItem(String what) {
      if (!(this.level() instanceof ServerLevel level)) {
         return false;
      }

      BotProfile p = this.profile;
      switch (what) {
         case "golem" -> {
            if (p.golems <= 0) {
               return false;
            }

            BwItems.summonGolem(level, p.team, this.blockPosition(), "[" + p.team.team.label + "] " + p.name);
            p.golems--;
            return true;
         }
         case "turm" -> {
            if (p.popupTowers <= 0 || !BwItems.buildTower(level, this.blockPosition(), this.getDirection(), p.team)) {
               return false;
            }

            p.popupTowers--;
            return true;
         }
         case "hochbauen" -> {
            if (p.blocks() < 3) {
               return false;
            }

            this.pillarLeft = Math.min(5, p.blocks());
            return true;
         }
         default -> {
            return false;
         }
      }
   }

   /** Fuer den Befehl "feuerball": sofort auf dieses Ziel werfen, wenn er einen hat. */
   public boolean commandFireball(LivingEntity target) {
      if (this.profile.fireballs <= 0 || !(this.level() instanceof ServerLevel level) || this.distanceTo(target) > 40.0) {
         return false;
      }

      this.throwFireball(level, target);
      return true;
   }

   private void taskCutBridge(ServerLevel level) {
      BlockPos target = this.profile.taskPos;
      if (target == null || level.getBlockState(target).isAir() || Game.arena().isMap(target)) {
         this.finishTask();
      } else {
         double reach = this.getEyePosition().distanceTo(Vec3.atCenterOf(target));
         if (reach <= 4.3) {
            this.path = null;
            this.mine(level, target);
         } else {
            Nav nav = this.navigate(level, Pathfinder.near(target.above(), 2.5), "cut" + target.asLong(), false, false, 60);
            if (nav == Nav.FAILED && this.failedPlans > 3) {
               this.finishTask();
            }
         }
      }
   }

   // ======================================================================== Gegenstaende

   private void collectItems(ServerLevel level) {
      // am eigenen Spawner lassen Bots echten Teamkollegen den Vortritt
      boolean yield = this.humanAtGenerator() && this.profile.team.island().generatorArea().inflate(1.5, 1.0, 1.5).contains(this.position());
      for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, this.getBoundingBox().inflate(1.0, 0.8, 1.0))) {
         if (yield || item.tickCount < 10) {
            continue;
         }

         ItemStack stack = item.getItem();
         int n = stack.getCount();
         Game.TeamState t = this.profile.team;
         if (stack.is(Items.IRON_INGOT)) {
            this.profile.iron += n;
         } else if (stack.is(Items.GOLD_INGOT)) {
            this.profile.gold += n;
         } else if (stack.is(Items.DIAMOND)) {
            this.profile.diamond += n;
         } else if (stack.is(Items.EMERALD)) {
            this.profile.emerald += n;
         } else {
            continue;
         }

         level.playSound(null, this.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.2F, 1.4F + RND.nextFloat() * 0.4F);
         item.discard();
      }
   }

   private void hold(HeldItem item) {
      if (item != this.held || item == HeldItem.SWORD && !this.getMainHandItem().is(this.profile.swordStack().getItem())) {
         this.held = item;
         ItemStack stack = switch (item) {
            case NONE -> ItemStack.EMPTY;
            case SWORD -> this.profile.swordStack();
            case BLOCK -> new ItemStack(this.profile.team.team.wool.asItem());
            case SHEARS -> new ItemStack(Items.SHEARS);
            case PICKAXE -> new ItemStack(switch (this.profile.pickaxe) {
               case 1 -> Items.WOODEN_PICKAXE;
               case 2 -> Items.IRON_PICKAXE;
               default -> Items.DIAMOND_PICKAXE;
            });
            case FIREBALL -> new ItemStack(Items.FIRE_CHARGE);
            case GAPPLE -> new ItemStack(Items.GOLDEN_APPLE);
            case OTHER -> this.getMainHandItem();
         };
         this.setItemSlot(EquipmentSlot.MAINHAND, stack);
      }
   }

   public void refreshHeldItem() {
      HeldItem h = this.held;
      this.held = HeldItem.NONE;
      this.hold(h == HeldItem.NONE ? HeldItem.SWORD : h);
   }

   private void holdBlock(Block block) {
      if (this.held != HeldItem.BLOCK || !this.getMainHandItem().is(block.asItem())) {
         this.held = HeldItem.BLOCK;
         this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(block.asItem()));
      }
   }

   void swingArm() {
      this.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
   }

   // ======================================================================== Auskunft

   public void clearPath() {
      this.path = null;
   }

   public LivingEntity currentEnemy() {
      return this.enemy;
   }

   public boolean isFighting() {
      return this.enemy != null && this.distanceTo(this.enemy) < 8.0;
   }

   public String debugState() {
      return this.profile.task + (this.path == null ? "" : " p" + this.pathIdx + "/" + this.path.size() + (this.pathComplete ? "" : "~"))
         + (this.enemy != null ? " vs" + (int)this.distanceTo(this.enemy) : "")
         + (this.breakPos != null ? " brk" : "");
   }

   public static List<BedwarsBot> list(List<BotProfile> profiles) {
      List<BedwarsBot> out = new ArrayList<>();

      for (BotProfile p : profiles) {
         if (p.body != null && p.body.isAlive()) {
            out.add(p.body);
         }
      }

      return out;
   }
}
