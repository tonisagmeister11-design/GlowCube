package de.glowcube.bedwars;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * Befehle an die eigenen Bots: {@code /@ <wer> <befehl> [ziel]} (oder {@code /bot ...}).
 * <ul>
 *    <li>wer: {@code alle}, {@code einer} (der naechste), {@code zwei} (die zwei naechsten) oder der Name eines Bots</li>
 *    <li>befehl: siehe {@link #ACTIONS} - Tab zeigt alles an</li>
 * </ul>
 * Beispiele: {@code /@ alle verteidigen}, {@code /@ mila angreifen blau}, {@code /@ einer kaufen feuerball},
 * {@code /@ zwei folgen}, {@code /@ finn gib eisen}.
 */
public final class BotCommands {
   /** Befehl -> Beschreibung (fuer Hilfe und Tab). */
   public static final Map<String, String> ACTIONS = new LinkedHashMap<>();

   static {
      ACTIONS.put("verteidigen", "ans Bett stellen und es verteidigen");
      ACTIONS.put("bett-zubauen", "das Bett mit Bloecken zubauen");
      ACTIONS.put("angreifen", "<team> - Bett eines Teams holen");
      ACTIONS.put("rushen", "<team> - sofort und mit allen auf ein Team");
      ACTIONS.put("jagen", "<team|spieler|bot> - Gegner verfolgen");
      ACTIONS.put("folgen", "dir hinterherlaufen und mitkaempfen");
      ACTIONS.put("beschuetzen", "bei dir bleiben und dich verteidigen");
      ACTIONS.put("komm", "einmal zu dir kommen");
      ACTIONS.put("hierbleiben", "an deiner Stelle stehen bleiben und sie halten");
      ACTIONS.put("warte", "genau dort stehen bleiben, wo er gerade ist");
      ACTIONS.put("mitte", "Smaragde in der Mitte holen");
      ACTIONS.put("diamanten", "Diamanten von der naechsten Diamant-Insel holen");
      ACTIONS.put("sammeln", "am eigenen Spawner Eisen und Gold sammeln");
      ACTIONS.put("einkaufen", "zum Haendler gehen und sich ausruesten");
      ACTIONS.put("kaufen", "<item> - beim naechsten Einkauf genau das kaufen");
      ACTIONS.put("upgrade", "<upgrade> - ein Team-Upgrade mit eigenen Diamanten kaufen");
      ACTIONS.put("rueckzug", "sofort zurueck nach Hause");
      ACTIONS.put("heim", "zur Insel zurueck und sammeln");
      ACTIONS.put("bruecke-abreissen", "die naechste gegnerische Bruecke zur Insel abbauen");
      ACTIONS.put("feuerball", "<ziel> - einen Feuerball auf das Ziel werfen");
      ACTIONS.put("golem", "seinen Traumverteidiger rufen");
      ACTIONS.put("turm", "seinen Pop-Up-Turm bauen");
      ACTIONS.put("hochbauen", "sich hochbauen");
      ACTIONS.put("gib", "<eisen|gold|diamanten|smaragde> - dir sein Geld geben (er muss nah sein)");
      ACTIONS.put("aggressiv", "ab jetzt mutig kaempfen");
      ACTIONS.put("vorsichtig", "ab jetzt lieber zurueckziehen");
      ACTIONS.put("normal", "wieder normal spielen");
      ACTIONS.put("frei", "Befehl aufheben - wieder selbst entscheiden");
      ACTIONS.put("status", "sagen, was er gerade macht");
      ACTIONS.put("geld", "sagen, wie viel Geld er hat");
      ACTIONS.put("ausruestung", "sagen, was er dabei hat");
      ACTIONS.put("hilfe", "alle Befehle anzeigen");
   }

   private static final List<String> MONEY = List.of("eisen", "gold", "diamanten", "smaragde");

   private BotCommands() {
   }

   // ====================================================================== Tab

   public static List<String> suggest(ServerPlayer p, String[] args) {
      List<String> out = new ArrayList<>();
      Game.TeamState t = p == null ? null : Game.teamOfPlayer(p);
      String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
      if (args.length <= 1) {
         List<String> who = new ArrayList<>(List.of("alle", "einer", "zwei"));
         if (t != null) {
            for (BotProfile b : t.bots) {
               if (!b.eliminated) {
                  who.add(b.name.toLowerCase(Locale.ROOT));
               }
            }
         }

         who.add("hilfe");
         filter(out, who, last);
      } else if (args.length == 2) {
         filter(out, new ArrayList<>(ACTIONS.keySet()), last);
      } else if (args.length == 3) {
         String a = args[1].toLowerCase(Locale.ROOT);
         switch (a) {
            case "angreifen", "rushen" -> filter(out, enemyTeams(t), last);
            case "jagen", "feuerball" -> {
               List<String> l = enemyTeams(t);
               l.addAll(enemyNames(t));
               filter(out, l, last);
            }
            case "kaufen" -> filter(out, new ArrayList<>(BotProfile.WISHES.stream().filter(w -> !w.startsWith("upgrade-")).toList()), last);
            case "upgrade" -> filter(out, new ArrayList<>(BotProfile.WISHES.stream().filter(w -> w.startsWith("upgrade-")).map(w -> w.substring(8)).toList()), last);
            case "gib" -> filter(out, new ArrayList<>(MONEY), last);
            default -> {
            }
         }
      }

      return out;
   }

   private static void filter(List<String> out, List<String> all, String prefix) {
      for (String s : all) {
         if (s.startsWith(prefix)) {
            out.add(s);
         }
      }
   }

   private static List<String> enemyTeams(Game.TeamState mine) {
      List<String> l = new ArrayList<>();
      for (Game.TeamState o : Game.teams()) {
         if (o != mine && o.alive()) {
            l.add(o.team.label.toLowerCase(Locale.ROOT));
         }
      }

      return l;
   }

   private static List<String> enemyNames(Game.TeamState mine) {
      List<String> l = new ArrayList<>();
      for (Game.TeamState o : Game.teams()) {
         if (o == mine) {
            continue;
         }

         for (Game.Human h : o.humans) {
            if (!h.out) {
               l.add(h.name.toLowerCase(Locale.ROOT));
            }
         }

         for (BotProfile b : o.bots) {
            if (!b.eliminated) {
               l.add(b.name.toLowerCase(Locale.ROOT));
            }
         }
      }

      return l;
   }

   // ====================================================================== Ausfuehren

   private static void tell(ServerPlayer p, String msg, ChatFormatting c) {
      p.sendSystemMessage(Component.literal(msg).withStyle(c));
   }

   public static void run(ServerPlayer p, String[] args) {
      if (args.length == 0 || args.length == 1 && args[0].equalsIgnoreCase("hilfe") || args.length == 2 && args[1].equalsIgnoreCase("hilfe")) {
         help(p);
         return;
      }

      Game.TeamState t = Game.teamOfPlayer(p);
      if (!Game.running() || t == null) {
         tell(p, "Befehle an Bots gehen nur, waehrend du Bedwars spielst.", ChatFormatting.RED);
         return;
      }

      String whoKey;
      String action;
      String arg;
      String first = args[0].toLowerCase(Locale.ROOT);
      boolean structured = args.length >= 2 && ACTIONS.containsKey(args[1].toLowerCase(Locale.ROOT)) && args.length <= 3
         && (first.equals("alle") || first.equals("einer") || first.equals("zwei") || t.bots.stream().anyMatch(b -> b.name.equalsIgnoreCase(first)));
      if (structured) {
         whoKey = first;
         action = args[1].toLowerCase(Locale.ROOT);
         arg = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : null;
      } else {
         // frei formuliert: "greift mal blau an", "mila hol dir nen feuerball", "kommt her" ...
         String text = String.join(" ", args);
         List<String> names = new ArrayList<>();
         for (BotProfile b : t.bots) {
            if (!b.eliminated) {
               names.add(b.name.toLowerCase(Locale.ROOT));
            }
         }

         List<String> targets = new ArrayList<>();
         for (Game.TeamState o : Game.teams()) {
            if (o != t && o.alive()) {
               targets.addAll(List.of(o.team.words));
            }
         }

         targets.addAll(enemyNames(t));
         BotLanguage.Parsed q = BotLanguage.parse(text, names, targets);
         if (q == null) {
            // kein Befehl erkannt: die Chat-KI der Bots versucht es (Fragen, Gruesse, Teamplanung ...)
            BotChat.onPlayerChat(p, text);
            tell(p, "(an deine Bots weitergegeben - fuer feste Befehle: /@ hilfe)", ChatFormatting.DARK_GRAY);
            return;
         }

         whoKey = q.who();
         action = q.action();
         arg = q.arg();
         if (action.equals("hilfe")) {
            help(p);
            return;
         }

         p.sendSystemMessage(Component.literal("Verstanden: ").withStyle(ChatFormatting.DARK_GRAY)
            .append(Component.literal(whoKey + " -> " + action + (arg == null ? "" : " " + arg)).withStyle(ChatFormatting.GRAY)));
      }

      List<BotProfile> who = select(p, t, whoKey);
      if (who.isEmpty()) {
         tell(p, "Kein passender Bot in deinem Team (lebt er noch?).", ChatFormatting.RED);
         return;
      }

      if (action.equals("hilfe")) {
         help(p);
         return;
      }

      int done = 0;
      for (BotProfile b : who) {
         if (apply(p, t, b, action, arg)) {
            done++;
         }
      }

      if (done > 0) {
         BotProfile speaker = who.get(0);
         String reply = switch (action) {
            case "status", "geld", "ausruestung" -> null;
            default -> done == 1 ? "ok mach ich" : "ok wir machen das";
         };
         if (reply != null) {
            BotChat.sayPlain(speaker, reply, 10, true);
         }
      }
   }

   private static List<BotProfile> select(ServerPlayer p, Game.TeamState t, String who) {
      List<BotProfile> live = new ArrayList<>();
      for (BotProfile b : t.bots) {
         if (!b.eliminated) {
            live.add(b);
         }
      }

      live.sort((a, b) -> Double.compare(dist(p, a), dist(p, b)));
      return switch (who) {
         case "alle" -> live;
         case "einer" -> live.isEmpty() ? live : live.subList(0, 1);
         case "zwei" -> live.subList(0, Math.min(2, live.size()));
         default -> live.stream().filter(b -> b.name.equalsIgnoreCase(who)).toList();
      };
   }

   private static double dist(ServerPlayer p, BotProfile b) {
      return b.body == null ? 9999.0 : b.body.distanceTo(p);
   }

   /** Ein Befehl fuer einen Bot. Der Auftrag bleibt eine Weile bestehen (die Team-Planung ueberschreibt ihn nicht). */
   private static boolean apply(ServerPlayer p, Game.TeamState t, BotProfile b, String action, String arg) {
      int lock = Game.tick() + 20 * 90;
      switch (action) {
         case "verteidigen" -> order(b, BotProfile.Task.DEFEND, null, null, null, lock);
         case "bett-zubauen" -> {
            t.fortified = false;
            order(b, b.blocks() > 0 ? BotProfile.Task.FORTIFY : BotProfile.Task.SHOP, null, null, null, lock);
            b.afterShop = BotProfile.Task.FORTIFY;
         }
         case "angreifen", "rushen" -> {
            Game.TeamState target = arg == null ? TeamBrain.bestRaidTarget(t) : team(arg, t);
            if (target == null) {
               tell(p, "Welches Team? z.B. /@ alle " + action + " blau", ChatFormatting.RED);
               return false;
            }

            if (!target.bedAlive) {
               LivingEntity v = b.body == null ? null : Game.nearestMember(target, b.body.position());
               order(b, BotProfile.Task.HUNT, null, v, null, lock);
            } else if (action.equals("rushen") || b.blocks() >= 12) {
               order(b, BotProfile.Task.RAID, target, null, null, lock);
               b.mood = action.equals("rushen") ? 1 : b.mood;
            } else {
               order(b, BotProfile.Task.SHOP, target, null, null, lock);
               b.afterShop = BotProfile.Task.RAID;
            }
         }
         case "jagen" -> {
            LivingEntity v = arg == null ? nearestEnemy(t, b) : victim(arg, t, b);
            if (v == null) {
               tell(p, "Wen? z.B. /@ alle jagen gelb oder einen Namen.", ChatFormatting.RED);
               return false;
            }

            order(b, BotProfile.Task.HUNT, null, v, null, lock);
         }
         case "folgen", "beschuetzen" -> order(b, BotProfile.Task.FOLLOW_PLAYER, null, p, null, lock);
         case "komm" -> order(b, BotProfile.Task.FOLLOW_PLAYER, null, p, null, Game.tick() + 20 * 20);
         case "hierbleiben" -> order(b, BotProfile.Task.HOLD, null, null, p.blockPosition(), lock);
         case "warte" -> {
            if (b.body == null) {
               return false;
            }

            order(b, BotProfile.Task.HOLD, null, null, b.body.blockPosition(), lock);
         }
         case "mitte" -> order(b, BotProfile.Task.MID, null, null, Game.arena().emeraldGens.get(0).below(), lock);
         case "diamanten" -> {
            BlockPos best = null;
            for (BlockPos d : Game.arena().diamondGens) {
               if (best == null || b.body != null && d.distSqr(b.body.blockPosition()) < best.distSqr(b.body.blockPosition())) {
                  best = d;
               }
            }

            order(b, BotProfile.Task.MID, null, null, best, lock);
         }
         case "sammeln" -> order(b, BotProfile.Task.GATHER, null, null, null, lock);
         case "einkaufen" -> {
            order(b, BotProfile.Task.SHOP, null, null, null, Game.tick() + 600);
            b.afterShop = BotProfile.Task.IDLE;
         }
         case "kaufen", "upgrade" -> {
            String w = action.equals("upgrade") ? "upgrade-" + arg : arg;
            if (arg == null && action.equals("kaufen")) {
               // "geh einkaufen" ohne bestimmtes Item
               order(b, BotProfile.Task.SHOP, null, null, null, Game.tick() + 600);
               b.afterShop = BotProfile.Task.IDLE;
               return true;
            }

            if (arg == null || !BotProfile.WISHES.contains(w)) {
               tell(p, "Was denn? Tab zeigt alles, z.B. /@ einer kaufen feuerball", ChatFormatting.RED);
               return false;
            }

            b.wish = w;
            order(b, BotProfile.Task.SHOP, null, null, null, Game.tick() + 600);
            b.afterShop = BotProfile.Task.IDLE;
         }
         case "rueckzug" -> order(b, BotProfile.Task.RETREAT, null, null, null, Game.tick() + 400);
         case "heim" -> order(b, BotProfile.Task.REGROUP, null, null, null, Game.tick() + 400);
         case "bruecke-abreissen" -> {
            BlockPos cut = bridgeBlock(t);
            if (cut == null) {
               tell(p, "Ich sehe keine fremde Bruecke an unserer Insel.", ChatFormatting.YELLOW);
               return false;
            }

            order(b, BotProfile.Task.CUT_BRIDGE, null, null, cut, Game.tick() + 400);
         }
         case "feuerball" -> {
            LivingEntity v = arg == null ? nearestEnemy(t, b) : victim(arg, t, b);
            if (v == null || b.body == null || !b.body.commandFireball(v)) {
               tell(p, b.name + ": hab keinen feuerball oder kein ziel", ChatFormatting.YELLOW);
               return false;
            }
         }
         case "golem", "turm", "hochbauen" -> {
            if (b.body == null || !b.body.commandItem(action)) {
               tell(p, b.name + ": geht nicht (" + (action.equals("hochbauen") ? "zu wenig bloecke" : "hab keinen") + ")", ChatFormatting.YELLOW);
               return false;
            }
         }
         case "gib" -> {
            return give(p, b, arg);
         }
         case "aggressiv" -> b.mood = 1;
         case "vorsichtig" -> b.mood = 2;
         case "normal" -> b.mood = 0;
         case "frei" -> {
            b.taskLockUntil = 0;
            b.task = BotProfile.Task.IDLE;
            b.mood = 0;
            TeamBrain.requestThink(t);
         }
         case "status" -> say(b, b.body == null ? "bin gerade tot" : (b.taskLabel() + ", " + (int)b.body.getHealth() + " herzen"));
         case "geld" -> say(b, "ich hab " + b.walletText());
         case "ausruestung" -> say(b, gear(b));
         default -> {
            return false;
         }
      }

      return true;
   }

   private static void order(BotProfile b, BotProfile.Task task, Game.TeamState team, LivingEntity entity, BlockPos pos, int until) {
      b.task = task;
      b.taskTeam = team;
      b.taskEntity = entity;
      b.taskPos = pos;
      b.taskSince = Game.tick();
      b.taskLockUntil = until;
      if (b.body != null) {
         b.body.clearPath();
      }
   }

   private static void say(BotProfile b, String text) {
      BotChat.sayPlain(b, text, 5, true);
   }

   private static String gear(BotProfile b) {
      String[] sw = {"holzschwert", "steinschwert", "eisenschwert", "diaschwert"};
      String[] ar = {"leder", "kette", "eisen", "dia"};
      StringBuilder s = new StringBuilder(sw[b.swordTier] + ", " + ar[b.armorTier] + "ruestung, " + b.blocks() + " bloecke");
      if (b.fireballs > 0) {
         s.append(", ").append(b.fireballs).append(" feuerball");
      }

      if (b.tnt > 0) {
         s.append(", ").append(b.tnt).append(" tnt");
      }

      if (b.gapples > 0) {
         s.append(", ").append(b.gapples).append(" goldapfel");
      }

      if (b.bow) {
         s.append(", bogen mit ").append(b.arrows).append(" pfeilen");
      }

      if (b.golems > 0) {
         s.append(", golem");
      }

      if (b.popupTowers > 0) {
         s.append(", pop-up-turm");
      }

      if (b.snowballs > 0) {
         s.append(", ").append(b.snowballs).append(" schneebaelle");
      }

      if (b.shield) {
         s.append(", schild");
      }

      if (b.axe > 0) {
         s.append(", axt");
      }

      if (b.sponges > 0) {
         s.append(", schwamm");
      }

      if (b.waterBuckets > 0) {
         s.append(", wassereimer");
      }

      s.append(" (pvp ").append(Hands.rating(b.hands.pvp)).append(", bauen ").append(Hands.rating(b.hands.build));
      if (b.favorite != null) {
         s.append(", lieblings-item ").append(b.favorite);
      }

      s.append(")");

      return s.toString();
   }

   private static Game.TeamState team(String name, Game.TeamState mine) {
      if (name == null) {
         return null;
      }

      for (Game.TeamState o : Game.teams()) {
         if (o != mine) {
            for (String w : o.team.words) {
               if (w.equalsIgnoreCase(name)) {
                  return o;
               }
            }
         }
      }

      return null;
   }

   private static LivingEntity nearestEnemy(Game.TeamState t, BotProfile b) {
      if (b.body == null) {
         return null;
      }

      LivingEntity best = null;
      double bd = Double.MAX_VALUE;
      for (LivingEntity e : Game.enemiesOf(t)) {
         double d = e.distanceTo(b.body);
         if (!(e instanceof BwEntities.TeamMob) && d < bd) {
            bd = d;
            best = e;
         }
      }

      return best;
   }

   private static LivingEntity victim(String name, Game.TeamState mine, BotProfile b) {
      if (name == null) {
         return null;
      }

      Game.TeamState team = team(name, mine);
      if (team != null) {
         return b.body == null ? null : Game.nearestMember(team, b.body.position());
      }

      for (Game.TeamState o : Game.teams()) {
         if (o == mine) {
            continue;
         }

         for (Game.Human h : o.humans) {
            if (h.name.equalsIgnoreCase(name) && h.active()) {
               return h.p;
            }
         }

         for (BotProfile x : o.bots) {
            if (x.name.equalsIgnoreCase(name) && x.body != null && x.body.isAlive()) {
               return x.body;
            }
         }
      }

      return null;
   }

   /** Ein von Gegnern gesetzter Block am Rand unserer Insel (Bruecke). */
   private static BlockPos bridgeBlock(Game.TeamState t) {
      Arena a = Game.arena();
      Vec3 home = t.island().centerVec();
      BlockPos best = null;
      double bd = Double.MAX_VALUE;
      BlockPos c = BlockPos.containing(home);
      for (BlockPos q : BlockPos.betweenClosed(c.offset(-16, -3, -16), c.offset(16, 1, 16))) {
         double d = Math.hypot(q.getX() + 0.5 - home.x, q.getZ() + 0.5 - home.z);
         if (d > Arena.ISLAND_RADIUS - 0.5 && d < Arena.ISLAND_RADIUS + 8 && d < bd && !a.isMap(q) && !a.level.getBlockState(q).isAir()
            && a.level.getBlockState(q).getFluidState().isEmpty() && a.level.getBlockState(q).getBlock() != t.team.wool) {
            bd = d;
            best = q.immutable();
         }
      }

      return best;
   }

   /** Der Bot gibt dem Spieler Geld aus seiner Tasche. */
   private static boolean give(ServerPlayer p, BotProfile b, String what) {
      if (b.body == null || b.body.distanceTo(p) > 8.0) {
         tell(p, b.name + ": komm erst naeher (hoechstens 8 bloecke)", ChatFormatting.YELLOW);
         return false;
      }

      String w = what == null ? "eisen" : what;
      int n;
      Item item;
      switch (w) {
         case "gold" -> {
            n = b.gold;
            b.gold = 0;
            item = Items.GOLD_INGOT;
         }
         case "diamanten" -> {
            n = b.diamond;
            b.diamond = 0;
            item = Items.DIAMOND;
         }
         case "smaragde" -> {
            n = b.emerald;
            b.emerald = 0;
            item = Items.EMERALD;
         }
         default -> {
            n = b.iron;
            b.iron = 0;
            item = Items.IRON_INGOT;
         }
      }

      if (n <= 0) {
         say(b, "hab keine " + w);
         return false;
      }

      while (n > 0) {
         int k = Math.min(64, n);
         ItemStack s = new ItemStack(item, k);
         if (!p.getInventory().add(s)) {
            p.spawnAtLocation(p.level(), s);
         }

         n -= k;
      }

      say(b, "hier hast du meine " + w);
      return true;
   }

   private static void help(ServerPlayer p) {
      p.sendSystemMessage(Lobby.header("BOT-BEFEHLE"));
      p.sendSystemMessage(Component.literal("/@ <alle|einer|zwei|botname> <befehl> [ziel]   (Tab zeigt alles)").withStyle(ChatFormatting.GOLD));
      p.sendSystemMessage(Component.literal("Du kannst auch frei schreiben, z.B. \"/@ greift mal blau an\", \"/@ mila hol dir nen feuerball\", \"/@ kommt alle her\".")
         .withStyle(ChatFormatting.AQUA));
      for (var e : ACTIONS.entrySet()) {
         p.sendSystemMessage(Component.literal(e.getKey()).withStyle(ChatFormatting.YELLOW).append(Component.literal(" - " + e.getValue()).withStyle(ChatFormatting.GRAY)));
      }
   }
}
