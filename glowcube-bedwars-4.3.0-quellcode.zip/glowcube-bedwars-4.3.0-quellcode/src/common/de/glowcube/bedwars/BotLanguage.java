package de.glowcube.bedwars;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Versteht Befehle an die Bots auch frei formuliert: "greift mal blau an", "bitte alle das bett verteidigen",
 * "mila hol dir nen feuerball", "kommt her", "verteidgt" (Tippfehler) ...
 * Liefert, wer gemeint ist, welcher Befehl und welches Ziel - oder null, wenn kein Befehl erkannt wurde.
 */
public final class BotLanguage {
   public record Parsed(String who, String action, String arg) {
   }

   /** Befehl -> Woerter und Wendungen dafuer (ohne Umlaute, klein). Reihenfolge = Vorrang. */
   private static final Map<String, List<String>> ACTION_WORDS = new LinkedHashMap<>();
   /** Item/Upgrade fuer "kaufen" -> Woerter dafuer. */
   private static final Map<String, List<String>> ITEM_WORDS = new LinkedHashMap<>();
   private static final Map<String, List<String>> MONEY_WORDS = new LinkedHashMap<>();

   private static void a(String action, String... words) {
      ACTION_WORDS.put(action, List.of(words));
   }

   private static void i(String item, String... words) {
      ITEM_WORDS.put(item, List.of(words));
   }

   static {
      // zuerst die mit Ziel/Item, damit "kauf dir einen feuerball" kein "feuerball werfen" wird
      a("gib", "gib mir", "gib uns", "gibt mir", "gebt mir", "schick mir", "schickt mir", "rueber geben", "mir geben", "uns geben", "eisen geben", "gold geben", "dias geben", "diamanten geben", "smaragde geben", "geld geben", "gib", "gebt", "give");
      a("upgrade", "upgrade", "aufwerten", "verbessern", "verbesser");
      a("kaufen", "kauf", "kaeuf", "hol dir", "holt euch", "hol euch", "besorg", "buy", "shoppt", "shop dir");
      a("bett-zubauen", "bett zubauen", "bett zu bauen", "baut das bett zu", "bau das bett zu", "bett zu", "zubauen", "zumauern", "einbauen", "einmauern",
         "bett schuetzen mit", "cover", "verteidigung bauen");
      a("bruecke-abreissen", "bruecke abreissen", "bruecke abbauen", "bruecke weg", "bruecke kaputt", "reisst die bruecke", "reiss die bruecke", "abreissen",
         "bruecke");
      a("rueckzug", "rueckzug", "zieht euch zurueck", "zieh dich zurueck", "zurueckziehen", "flieh", "lauf weg", "renn weg", "haut ab", "hau ab", "abhauen",
         "retreat", "raus da");
      a("heim", "nach hause", "geht heim", "geh heim", "heim", "home", "zurueck zur insel", "zurueck auf die insel", "kommt zurueck", "komm zurueck");
      a("rushen", "rush", "rusht", "rushen", "alle auf", "sofort angreifen", "voll drauf");
      a("verteidigen", "verteidig", "defend", "bewach", "bett schuetzen", "schuetzt das bett", "schuetz das bett", "am bett bleiben", "bleibt am bett",
         "bleib am bett", "passt aufs bett auf", "pass aufs bett auf", "aufs bett aufpassen", "haltet das bett", "deff", "def");
      a("beschuetzen", "beschuetz", "schuetz mich", "schuetzt mich", "pass auf mich auf", "passt auf mich auf", "deck mich", "deckt mich", "bodyguard",
         "begleite mich", "begleitet mich");
      a("folgen", "folg", "follow", "kommt mit", "komm mit", "geht mit", "geh mit", "hinter mir", "mir nach", "mitkommen");
      a("komm", "komm her", "kommt her", "kommt mal her", "komm mal her", "alle her", "zu mir", "hilf mir", "helft mir", "hilfe", "help", "her kommen", "herkommen");
      a("hierbleiben", "bleib hier", "bleibt hier", "hier bleiben", "hierbleiben", "halt die stellung", "haltet die stellung", "haltet die position",
         "halt die position", "stellung halten");
      a("warte", "warte", "wartet", "stopp", "stop", "bleib stehen", "bleibt stehen", "steh still", "stehen bleiben", "nicht bewegen", "halt");
      a("diamanten", "diamant", "dias", "dia", "diamond");
      a("mitte", "mitte", "mid", "smaragd", "emerald", "ems", "emis");
      a("sammeln", "sammel", "farm", "eisen holen", "gold holen", "geld holen", "am spawner", "generator", "resourcen", "ressourcen");
      a("einkaufen", "einkauf", "ausruesten", "ruest dich aus", "ruestet euch aus", "geht shoppen", "geh shoppen", "shop", "shoppen", "einkaufen");
      a("feuerball", "feuerball", "fireball", "fb auf");
      a("golem", "golem", "traumverteidiger", "dream defender", "verteidiger rufen");
      a("turm", "turm", "tower", "popup", "pop up");
      a("hochbauen", "hochbau", "baut euch hoch", "bau dich hoch", "bau hoch", "baut hoch", "pillar", "pillern", "nach oben bauen");
      a("jagen", "jag", "verfolg", "toet", "kill", "hunt", "erledig", "macht platt", "mach platt", "hau um", "haut um", "boxt", "box", "schlag");
      a("angreifen", "greif", "angriff", "attack", "attacke", "zerstoer", "kaputt machen", "holt das bett", "hol das bett", "holt bett", "hol bett",
         "bett holen", "geht auf", "geh auf", "auf die", "auf den");
      a("aggressiv", "aggressiv", "aggro", "mutig", "offensiv", "tryhard", "sweat", "gebt gas", "gib gas", "voll rein");
      a("vorsichtig", "vorsichtig", "defensiv", "safe spielen", "spielt safe", "spiel safe", "passt auf euch auf", "pass auf dich auf");
      a("normal", "normal spielen", "spielt normal", "spiel normal", "normal");
      a("frei", "frei", "macht was ihr wollt", "mach was du willst", "egal", "selbst entscheiden", "wie ihr wollt", "vergesst es", "vergiss es",
         "befehl aufheben");
      a("geld", "wie viel geld", "wieviel geld", "geld", "money", "kohle", "wie viel eisen", "wieviel eisen", "wie viel gold", "wieviel gold");
      a("ausruestung", "ausruestung", "gear", "was habt ihr", "was hast du", "inventar", "items");
      a("status", "status", "was machst du", "was macht ihr", "was tut ihr", "wo seid ihr", "wo bist du", "wie gehts", "lage");

      i("wolle", "wolle", "wool", "bloecke", "blocks");
      i("endstein", "endstein", "endstone", "end stein");
      i("holz", "holz", "planks", "bretter");
      i("obsidian", "obsidian", "obsi");
      i("diamantschwert", "diaschwert", "diamantschwert", "dia schwert", "diamond sword");
      i("eisenschwert", "eisenschwert", "eisen schwert", "iron sword");
      i("steinschwert", "steinschwert", "stein schwert", "schwert");
      i("diamantruestung", "diaruestung", "diamantruestung", "dia ruestung", "diamond armor");
      i("eisenruestung", "eisenruestung", "eisen ruestung", "iron armor");
      i("kettenruestung", "kettenruestung", "kette", "chain", "ruestung");
      i("schere", "schere", "shears");
      i("spitzhacke", "spitzhacke", "picke", "pickaxe", "spitzhacken");
      i("goldapfel", "goldapfel", "goldaepfel", "gapple", "apfel", "gaps");
      i("feuerball", "feuerball", "feuerbaelle", "fireball", "fb");
      i("tnt", "tnt", "sprengstoff", "dynamit");
      i("enderperle", "enderperle", "perle", "pearl", "perlen");
      i("brueckenei", "brueckenei", "bruecken ei", "ei", "egg", "bridge egg");
      i("popupturm", "popupturm", "pop up turm", "turm", "tower");
      i("bettwanze", "bettwanze", "bedbug", "silberfisch", "wanze");
      i("traumverteidiger", "traumverteidiger", "golem", "dream defender");
      i("tempotrank", "tempotrank", "tempo", "speed", "schnelligkeit");
      i("milch", "milch", "magische milch", "milk");
      i("rettungsplattform", "rettungsplattform", "plattform", "rettung", "platform");
      i("pfeile", "pfeile", "pfeil", "arrows");
      i("bogen", "bogen", "boegen", "bow");
      i("rueckstossstock", "rueckstossstock", "rueckstoss stock", "stock", "kb stick", "knockback");
      i("glas", "glas", "glass", "explosionsfestes glas");
      i("terrakotta", "terrakotta", "terracotta", "ton");
      i("wassereimer", "wassereimer", "wasser", "eimer", "water bucket");
      i("schwamm", "schwamm", "schwaemme", "sponge");
      i("axt", "axt", "aexte", "axe");
      i("schneebaelle", "schneebaelle", "schneeball", "snowball", "snowballs");
      i("schild", "schild", "shield");
      i("powerbogen", "powerbogen", "power bogen", "power bow", "staerke bogen");
      i("unsichtbarkeitstrank", "unsichtbarkeitstrank", "unsichtbarkeit", "invis", "unsichtbar");
      i("upgrade-schaerfe", "schaerfe", "sharpness", "klingen", "scharfe");
      i("upgrade-schutz", "schutz", "protection", "prot");
      i("upgrade-eisenschmiede", "eisenschmiede", "schmiede", "forge");
      i("upgrade-heilfeld", "heilfeld", "heal pool", "heilen");
      i("upgrade-eile", "eile", "haste", "bergarbeiter");
      i("upgrade-falle", "falle", "trap", "fallen");

      MONEY_WORDS.put("eisen", List.of("eisen", "iron"));
      MONEY_WORDS.put("gold", List.of("gold"));
      MONEY_WORDS.put("diamanten", List.of("diamant", "dia", "diamond"));
      MONEY_WORDS.put("smaragde", List.of("smaragd", "emerald", "ems"));
   }

   private BotLanguage() {
   }

   /** klein, Umlaute ausgeschrieben, Satzzeichen weg, Leerzeichen am Rand fuer Wortsuche. */
   public static String norm(String s) {
      String t = s.toLowerCase(Locale.ROOT)
         .replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
         .replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
      return " " + t + " ";
   }

   /** Abstand zweier Woerter (Tippfehler). */
   static int distance(String a, String b) {
      int[] prev = new int[b.length() + 1];
      int[] cur = new int[b.length() + 1];
      for (int j = 0; j <= b.length(); j++) {
         prev[j] = j;
      }

      for (int i = 1; i <= a.length(); i++) {
         cur[0] = i;
         for (int j = 1; j <= b.length(); j++) {
            int c = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
            cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c);
         }

         int[] tmp = prev;
         prev = cur;
         cur = tmp;
      }

      return prev[b.length()];
   }

   /** Kommt dieses Wort (oder diese Wendung) im Text vor - bei einzelnen Woertern auch mit kleinem Tippfehler? */
   static boolean has(String text, String word) {
      if (word.contains(" ")) {
         return text.contains(" " + word + " ");
      }

      for (String tok : text.trim().split(" ")) {
         if (tok.equals(word)) {
            return true;
         }

         // Wortanfang reicht ab 4 Buchstaben ("verteidigt", "greift", "kauft")
         if (word.length() >= 4 && tok.startsWith(word)) {
            return true;
         }

         // kleine Tippfehler bei laengeren Woertern
         if (word.length() >= 6 && tok.length() >= 5) {
            String cut = tok.length() > word.length() + 2 ? tok.substring(0, word.length() + 1) : tok;
            // zwei Fehler nur bei langen Woertern mit gleichem Anfang ("verteidgt", aber nicht "einbauen" fuer "einkaufen")
            int allowed = word.length() >= 8 && cut.length() >= 4 && cut.regionMatches(0, word, 0, 4) ? 2 : 1;
            if (distance(cut, word) <= allowed) {
               return true;
            }
         }
      }

      return false;
   }

   /**
    * @param botNames die Namen der eigenen Bots (klein)
    * @param targets  moegliche Ziele: Teamwoerter und Namen der Gegner (klein)
    */
   public static Parsed parse(String raw, List<String> botNames, List<String> targets) {
      String text = norm(raw);
      // wer?
      String who = null;
      for (String n : botNames) {
         if (has(text, n)) {
            who = n;
            break;
         }
      }

      if (who == null) {
         if (text.contains(" zwei ") || text.contains(" beide ") || text.contains(" ihr beide ") || text.contains(" zu zweit ")) {
            who = "zwei";
         } else if (text.contains(" einer ") || text.contains(" jemand ") || text.contains(" irgendwer ") || text.contains(" irgendjemand ")) {
            who = "einer";
         } else {
            who = "alle";
         }
      }

      // was? Erst ganze Wendungen ("gebt gas", "kommt her"), dann einzelne Woerter
      String action = null;
      for (int pass = 0; pass < 2 && action == null; pass++) {
         for (var e : ACTION_WORDS.entrySet()) {
            for (String w : e.getValue()) {
               if (w.contains(" ") == (pass == 0) && has(text, w)) {
                  action = e.getKey();
                  break;
               }
            }

            if (action != null) {
               break;
            }
         }
      }

      // "kommt alle mal her", "komm schnell her"
      if (action == null || action.equals("folgen")) {
         if (has(text, "komm") && text.contains(" her ")) {
            action = "komm";
         }
      }

      // ein Teamname allein ("blau!") heisst angreifen
      String target = findTarget(text, targets);
      if (action == null && target != null) {
         action = "angreifen";
      }

      if (action == null) {
         return null;
      }

      String arg = null;
      switch (action) {
         case "kaufen", "upgrade" -> {
            arg = findItem(text, action.equals("upgrade"));
            if (arg != null && arg.startsWith("upgrade-")) {
               action = "upgrade";
               arg = arg.substring(8);
            } else if (arg == null && action.equals("kaufen")) {
               action = "einkaufen";
            }
         }
         case "gib" -> {
            for (var e : MONEY_WORDS.entrySet()) {
               for (String w : e.getValue()) {
                  if (has(text, w)) {
                     arg = e.getKey();
                  }
               }
            }
         }
         case "angreifen", "rushen", "jagen", "feuerball" -> arg = target;
         default -> {
         }
      }

      return new Parsed(who, action, arg);
   }

   private static String findTarget(String text, List<String> targets) {
      // Teams und Namen nur genau (sonst wird aus "geben" schnell "gelben")
      for (String t : targets) {
         if (t.length() >= 3 && text.contains(" " + BotLanguage.norm(t).trim() + " ")) {
            return t;
         }
      }

      return null;
   }

   private static String findItem(String text, boolean upgradesOnly) {
      // laengste Treffer zuerst (damit "diaschwert" nicht nur "schwert" wird)
      String best = null;
      int bestLen = 0;
      for (var e : ITEM_WORDS.entrySet()) {
         if (upgradesOnly && !e.getKey().startsWith("upgrade-")) {
            continue;
         }

         for (String w : e.getValue()) {
            if (w.length() > bestLen && has(text, w)) {
               best = e.getKey();
               bestLen = w.length();
            }
         }
      }

      return best;
   }

   /** Alle Wendungen zu einem Befehl (fuer die Hilfe). */
   public static List<String> examples(String action) {
      List<String> l = ACTION_WORDS.get(action);
      return l == null ? List.of() : new ArrayList<>(l.subList(0, Math.min(3, l.size())));
   }
}
