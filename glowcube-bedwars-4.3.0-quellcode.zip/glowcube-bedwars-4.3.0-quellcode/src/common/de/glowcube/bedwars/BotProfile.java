package de.glowcube.bedwars;

import java.util.Random;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.DyedItemColor;

/**
 * Alles, was einen Bot ueber seinen Tod hinaus ausmacht: Name, Aussehen, Charakter,
 * Inventar und sein aktueller Auftrag vom Team.
 */
public final class BotProfile {
   private static final Identifier VIRTUAL_LEATHER = Identifier.fromNamespaceAndPath("glowcube_bedwars", "virtual_leather");

   public enum Role {
      /** Stuermt frueh los und zerstoert Betten. */
      RUSHER,
      /** Baut das Bett zu und bleibt eher zu Hause. */
      BUILDER,
      /** Sammelt, holt Diamanten und Smaragde. */
      COLLECTOR,
      /** Sucht den Kampf und jagt Gegner. */
      FIGHTER
   }

   public enum Task {
      IDLE,
      GATHER,
      SHOP,
      FORTIFY,
      DEFEND,
      RAID,
      MID,
      HUNT,
      ESCORT,
      FOLLOW_PLAYER,
      RETREAT,
      REGROUP,
      CUT_BRIDGE,
      /** Eine Stelle halten (Befehl "hierbleiben"/"warte"). */
      HOLD
   }

   /** Spielweise auf Befehl: 0 normal, 1 aggressiv, 2 vorsichtig. */
   public int mood;
   /** Was er beim naechsten Einkauf zuerst kaufen soll (Befehl "kaufen"). */
   public String wish;

   public final String name;
   public final Game.TeamState team;
   public final boolean alex;
   public final Role role;
   /** 0..1: wie gerne er kaempft. */
   public final double aggression;
   /** 0..1: grobes Koennen (aus dem Spielertyp). */
   public final double skill;
   /** Wie er an Maus und Tastatur ist. */
   public final Hands hands;
   /** Wie genervt er gerade ist (steigt bei Toden kurz hintereinander). */
   public double tilt;
   /** Wie er im Chat schreibt. */
   public final ChatBrain.Voice voice;
   public int lastDeathTick = -100000;
   /** 0..1: wie oft er im Chat schreibt. */
   public final double chattiness;
   /** 0..1: wie frech er im Chat ist. */
   public final double cheek;
   /** 0..1: wie vorsichtig er spielt. */
   public final double caution;

   public boolean eliminated;
   public int respawnAt = -1;
   public BedwarsBot body;

   // Eigene Geldboerse: was er selbst aufsammelt (oder einem Gegner abnimmt), gibt nur er aus
   public int iron;
   public int gold;
   public int diamond;
   public int emerald;

   // Inventar
   public int terracotta;
   public int glass;
   public int waterBuckets;
   public int sponges;
   /** Axt-Stufe 0..4 (Holz, Stein, Eisen, Diamant). */
   public int axe;
   public int snowballs;
   public boolean shield;
   public boolean powerBow;
   public int invisPotions;

   // Persoenlichkeit
   /** So baut er sein Bett ein, wenn er dran ist. */
   public final DefenseStyle defensePref;
   /** Kommt bei ihm Wasser aufs Bett? */
   public final boolean waterPref;
   /** Schleicht gern unsichtbar zum Bett. */
   public final boolean sneaky;
   /** Traegt einen Schild gegen Pfeile. */
   public final boolean tank;
   /** Wirft gern Schneebaelle auf Brueckenbauer. */
   public final boolean snowballer;
   /** Sein Lieblings-Item (wie bei Spielern: der eine spielt immer mit Feuerbaellen, der andere mit Bogen) - oder null. */
   public final String favorite;
   public int obsidian;
   public int tnt;
   public int pearls;
   public int bridgeEggs;
   public int popupTowers;
   public int bedbugs;
   public int golems;
   public int speedPotions;
   public int milk;
   public int rescue;
   public boolean bow;
   public int arrows;
   public boolean kbStick;
   public int wool;
   public int endStone;
   public int planks;
   public int gapples;
   public int fireballs;
   public int swordTier;
   public int armorTier;
   public int pickaxe;
   public boolean shears;

   // Auftrag vom Team
   public Task task = Task.IDLE;
   public Game.TeamState taskTeam;
   public net.minecraft.world.entity.LivingEntity taskEntity;
   public net.minecraft.core.BlockPos taskPos;
   public int taskSince;
   public int taskLockUntil;
   /** Was er nach dem Einkaufen weitermacht. */
   public Task afterShop = Task.IDLE;

   // Statistik und Gedaechtnis
   public int kills;
   public int finals;
   public int deaths;
   public int beds;
   public int lastSpoke = -10000;

   public BotProfile(String name, Game.TeamState team, Random rnd, boolean alex, int difficulty) {
      this.name = name;
      this.team = team;
      this.alex = alex;
      double r = rnd.nextDouble();
      this.role = r < 0.28 ? Role.RUSHER : (r < 0.52 ? Role.BUILDER : (r < 0.74 ? Role.COLLECTOR : Role.FIGHTER));
      this.hands = Hands.roll(rnd, difficulty);
      this.skill = this.hands.skill();
      this.aggression = clamp(
         (this.role == Role.RUSHER || this.role == Role.FIGHTER ? 0.55 : 0.25) + rnd.nextDouble() * 0.45 - (this.role == Role.BUILDER ? 0.1 : 0.0)
      );
      this.caution = clamp(1.0 - this.aggression * 0.7 + (rnd.nextDouble() - 0.5) * 0.4);
      this.chattiness = 0.25 + rnd.nextDouble() * 0.75;
      this.cheek = rnd.nextDouble();
      this.voice = new ChatBrain.Voice(rnd, this.cheek, this.hands.style);
      this.defensePref = DefenseStyle.pick(this.hands.build, rnd);
      this.waterPref = DefenseStyle.pickWater(this.hands.build, rnd);
      this.sneaky = (this.role == Role.RUSHER || this.role == Role.FIGHTER) && rnd.nextDouble() < 0.35;
      this.tank = rnd.nextDouble() < 0.12 + this.caution * 0.15;
      this.snowballer = rnd.nextDouble() < 0.2 + this.hands.sense * 0.3;
      this.favorite = this.pickFavorite(rnd);
   }

   private String pickFavorite(Random rnd) {
      if (rnd.nextDouble() < 0.15) {
         return null;
      }

      java.util.List<String> pool = new java.util.ArrayList<>(java.util.List.of("feuerball", "feuerball"));
      switch (this.role) {
         case RUSHER -> {
            pool.addAll(java.util.List.of("feuerball", "tnt", "tnt", "brueckenei", "tempotrank"));
            if (this.hands.sense > 0.55) {
               pool.add("enderperle");
            }
         }
         case FIGHTER -> pool.addAll(java.util.List.of("bogen", "bogen", "rueckstossstock", "bettwanze"));
         case BUILDER -> pool.addAll(java.util.List.of("popupturm", "popupturm", "bogen"));
         case COLLECTOR -> pool.addAll(java.util.List.of("bogen", "bettwanze", "popupturm"));
      }

      if (this.sneaky) {
         pool.add("unsichtbarkeitstrank");
      }

      return pool.get(rnd.nextInt(pool.size()));
   }

   /** Lohnt sich ein Gang zum Haendler fuer das Lieblings-Item? (Preise wie im Shop) */
   public boolean wantsFavorite() {
      if (this.favorite == null || this.swordTier < 1 || this.have(this.favorite) >= (this.armorTier >= 1 ? 2 : 1)) {
         return false;
      }

      return switch (this.favorite) {
         case "feuerball" -> this.iron >= 40;
         case "popupturm", "bettwanze" -> this.iron >= 24;
         case "tnt" -> this.gold >= 4;
         case "bogen" -> this.gold >= 14;
         case "rueckstossstock" -> this.gold >= 5;
         case "enderperle" -> this.emerald >= 4;
         case "brueckenei", "tempotrank" -> this.emerald >= 1;
         case "unsichtbarkeitstrank" -> this.emerald >= 2;
         default -> false;
      };
   }

   /** Material, das ihm als Bauer gerade fehlt: fuers Nachbessern oder die naechste offene Schicht (oder null). */
   public DefenseStyle.Mat materialNeeded() {
      Game.TeamState t = this.team;
      if (t.defenseStyle == null || !t.bedAlive) {
         return null;
      }

      for (int layer = 1; layer <= t.defenseStyle.layers(); layer++) {
         if (t.missingInLayer(layer) > 0) {
            DefenseStyle.Mat m = t.defenseStyle.mat(layer);
            return this.count(m) == 0 ? m : null;
         }
      }

      DefenseStyle.Mat up = t.upgradeMat();
      return up != null && this.count(up) == 0 ? up : null;
   }

   public int money(int currency) {
      return currency == 0 ? this.iron : (currency == 1 ? this.gold : this.emerald);
   }

   /** Geld an einen Teamkollegen abgeben (wie Barren fallen lassen). */
   public void give(BotProfile to, int currency, int n) {
      switch (currency) {
         case 0 -> {
            this.iron -= n;
            to.iron += n;
         }
         case 1 -> {
            this.gold -= n;
            to.gold += n;
         }
         default -> {
            this.emerald -= n;
            to.emerald += n;
         }
      }
   }

   /** Ist er der Bauer seines Teams und wartet improvisierte Wolle auf besseres Material, das er bezahlen kann? */
   public boolean wantsDefenseUpgrade() {
      if (!this.name.equals(this.team.builderName)) {
         return false;
      }

      DefenseStyle.Mat m = this.team.upgradeMat();
      return m != null && this.count(m) == 0 && this.canAffordMaterial(m);
   }

   /** Wie viel er von einem Item schon dabei hat (fuer das Lieblings-Item). */
   private int have(String w) {
      return switch (w) {
         case "feuerball" -> this.fireballs;
         case "tnt" -> this.tnt;
         case "bogen" -> this.bow ? (this.arrows > 0 ? 2 : 1) : 0;
         case "rueckstossstock" -> this.kbStick ? 2 : 0;
         case "popupturm" -> this.popupTowers;
         case "bettwanze" -> this.bedbugs;
         case "enderperle" -> this.pearls;
         case "brueckenei" -> this.bridgeEggs;
         case "tempotrank" -> this.speedPotions;
         case "unsichtbarkeitstrank" -> this.invisPotions;
         default -> 2;
      };
   }

   private static double clamp(double v) {
      return Math.max(0.0, Math.min(1.0, v));
   }

   public int blocks() {
      return this.wool + this.endStone + this.planks;
   }

   public int gearScore() {
      return this.swordTier * 2 + this.armorTier * 2 + (this.gapples > 0 ? 1 : 0);
   }

   /** Verbraucht einen Baublock; liefert den Block oder null. Wolle zum Bruecken, Endstein zum Schuetzen. */
   public net.minecraft.world.level.block.Block takeBlock(boolean defensive, int layer) {
      if (defensive) {
         DefenseStyle st = this.team.defenseStyle != null ? this.team.defenseStyle : this.defensePref;
         net.minecraft.world.level.block.Block b = this.take(st.mat(layer));
         if (b != null) {
            return b;
         }

         // gewuenschtes Material fehlt: improvisieren, wie ein Mensch - erst das Haerteste, was da ist
         for (DefenseStyle.Mat m : new DefenseStyle.Mat[]{DefenseStyle.Mat.OBSIDIAN, DefenseStyle.Mat.END_STONE, DefenseStyle.Mat.GLASS,
            DefenseStyle.Mat.TERRACOTTA, DefenseStyle.Mat.WOOD, DefenseStyle.Mat.WOOL}) {
            b = this.take(m);
            if (b != null) {
               return b;
            }
         }

         return null;
      }

      // Bruecken: Wolle zuerst (billig), dann was sonst da ist - Obsidian und Glas nie
      for (DefenseStyle.Mat m : new DefenseStyle.Mat[]{DefenseStyle.Mat.WOOL, DefenseStyle.Mat.TERRACOTTA, DefenseStyle.Mat.END_STONE, DefenseStyle.Mat.WOOD}) {
         net.minecraft.world.level.block.Block b = this.take(m);
         if (b != null) {
            return b;
         }
      }

      return null;
   }

   public int count(DefenseStyle.Mat m) {
      return switch (m) {
         case WOOL -> this.wool;
         case END_STONE -> this.endStone;
         case WOOD -> this.planks;
         case GLASS -> this.glass;
         case TERRACOTTA -> this.terracotta;
         case OBSIDIAN -> this.obsidian;
      };
   }

   private net.minecraft.world.level.block.Block take(DefenseStyle.Mat m) {
      if (this.count(m) <= 0) {
         return null;
      }

      switch (m) {
         case WOOL -> this.wool--;
         case END_STONE -> this.endStone--;
         case WOOD -> this.planks--;
         case GLASS -> this.glass--;
         case TERRACOTTA -> this.terracotta--;
         case OBSIDIAN -> this.obsidian--;
      }

      return switch (m) {
         case WOOL -> this.team.team.wool;
         case END_STONE -> net.minecraft.world.level.block.Blocks.END_STONE;
         case WOOD -> net.minecraft.world.level.block.Blocks.OAK_PLANKS;
         case GLASS -> this.team.team.glass;
         case TERRACOTTA -> this.team.team.terracotta;
         case OBSIDIAN -> net.minecraft.world.level.block.Blocks.OBSIDIAN;
      };
   }

   /** Ein Paket Baumaterial kaufen (Preise wie im Shop). */
   public boolean buyMaterial(DefenseStyle.Mat m) {
      return switch (m) {
         case WOOL -> this.pay(Items.IRON_INGOT, 4) && (this.wool += 16) > 0;
         case END_STONE -> this.pay(Items.IRON_INGOT, 24) && (this.endStone += 12) > 0;
         case WOOD -> this.pay(Items.GOLD_INGOT, 4) && (this.planks += 16) > 0;
         case GLASS -> this.pay(Items.IRON_INGOT, 12) && (this.glass += 4) > 0;
         case TERRACOTTA -> this.pay(Items.IRON_INGOT, 12) && (this.terracotta += 16) > 0;
         case OBSIDIAN -> this.pay(Items.EMERALD, 4) && (this.obsidian += 4) > 0;
      };
   }

   public boolean canAffordMaterial(DefenseStyle.Mat m) {
      return switch (m) {
         case WOOL -> this.iron >= 4;
         case END_STONE -> this.iron >= 24;
         case WOOD -> this.gold >= 4;
         case GLASS, TERRACOTTA -> this.iron >= 12;
         case OBSIDIAN -> this.emerald >= 4;
      };
   }

   /** Kauft die Bloecke fuer die eigene Bett-Verteidigung (so viele Pakete, wie noch fehlen). */
   private String buyDefense() {
      Game.TeamState t = this.team;
      if (!t.bedAlive) {
         return null;
      }

      DefenseStyle st = t.defenseStyle != null ? t.defenseStyle : this.defensePref;
      String bought = null;
      for (int layer = 1; layer <= st.layers(); layer++) {
         DefenseStyle.Mat m = st.mat(layer);
         // fehlende Zellen plus improvisierte Wolle, die er gegen das richtige Material tauschen will
         int need = t.missingInLayer(layer) + t.improvisedInLayer(layer);
         int guard = 0;
         while (this.count(m) < need && guard++ < 4 && this.buyMaterial(m)) {
            bought = m.label;
         }
      }

      boolean water = t.defenseStyle != null ? t.defenseWater : this.waterPref;
      if (water && !t.waterPlaced && this.waterBuckets == 0 && this.pay(Items.GOLD_INGOT, 3)) {
         this.waterBuckets++;
         bought = "Wassereimer";
      }

      return bought;
   }

   // ------------------------------------------------------------------ Einkaufen

   private boolean pay(Item currency, int price) {
      if (currency == Items.IRON_INGOT && this.iron >= price) {
         this.iron -= price;
         return true;
      } else if (currency == Items.GOLD_INGOT && this.gold >= price) {
         this.gold -= price;
         return true;
      } else if (currency == Items.EMERALD && this.emerald >= price) {
         this.emerald -= price;
         return true;
      } else if (currency == Items.DIAMOND && this.diamond >= price) {
         this.diamond -= price;
         return true;
      } else {
         return false;
      }
   }

   /** Was er bei sich hat, als Text (fuer den Chat). */
   public String walletText() {
      return this.iron + " eisen, " + this.gold + " gold, " + this.diamond + " dias, " + this.emerald + " smaragde";
   }

   /**
    * Kauft ein, was fuer seine Rolle und die Lage am meisten bringt.
    * Liefert eine kurze Beschreibung des wichtigsten Kaufs (fuer den Chat) oder null.
    */
   public String shop() {
      String best = null;
      Game.TeamState t = this.team;
      boolean bedAlive = t.bedAlive;
      boolean raider = this.task == Task.RAID || this.afterShop == Task.RAID || this.role == Role.RUSHER;
      boolean defender = this.task == Task.FORTIFY || this.afterShop == Task.FORTIFY || this.task == Task.DEFEND || this.afterShop == Task.DEFEND
         || this.role == Role.BUILDER;
      boolean fighter = this.role == Role.FIGHTER || this.task == Task.HUNT;
      if (this.wish != null) {
         String w = this.buyWish(this.wish);
         if (w != null) {
            best = w;
            this.wish = null;
         }
      }

      // geht er extra fuers Bett einkaufen (oder ist er der Bauer und spart auf Endstein & Co.), kauft er zuerst das
      // Material dafuer - nicht erst Schwert und Ruestung
      if (this.task == Task.FORTIFY || this.afterShop == Task.FORTIFY || this.wantsDefenseUpgrade()) {
         String mat = this.buyDefense();
         if (mat != null) {
            Game.count("kauf " + mat);
            if (best == null) {
               best = mat;
            }
         }
      }

      // Preise wie im Shop der Spieler - jeder bezahlt aus seiner eigenen Tasche
      for (int round = 0; round < 10; round++) {
         String bought = null;
         if (this.swordTier < 3 && this.emerald >= 4 && this.pay(Items.EMERALD, 4)) {
            this.swordTier = 3;
            bought = "Diamantschwert";
         } else if (this.armorTier < 3 && this.emerald >= 6 && this.pay(Items.EMERALD, 6)) {
            this.armorTier = 3;
            bought = "Diamantruestung";
         } else if (this.armorTier < 2 && this.gold >= 12 && (this.swordTier >= 1 || !bedAlive) && this.pay(Items.GOLD_INGOT, 12)) {
            this.armorTier = 2;
            bought = "Eisenruestung";
         } else if (this.swordTier < 2 && this.gold >= 7 && this.pay(Items.GOLD_INGOT, 7)) {
            this.swordTier = 2;
            bought = "Eisenschwert";
         } else if (this.swordTier < 1 && this.pay(Items.IRON_INGOT, 10)) {
            this.swordTier = 1;
            bought = "Steinschwert";
         } else if (this.wool < (raider ? 32 : 16) && this.pay(Items.IRON_INGOT, 4)) {
            this.wool += 16;
            bought = "Wolle";
         } else if (this.favorite != null && this.swordTier >= 1 && this.wool >= 16 && this.have(this.favorite) < (this.armorTier >= 1 ? 2 : 1)
            && (bought = this.buyWish(this.favorite)) != null) {
            // sein Lieblings-Item kauft er frueher als andere (manche sogar vor der Ruestung)
            if (this.favorite.equals("bogen") && this.arrows == 0 && this.pay(Items.GOLD_INGOT, 2)) {
               this.arrows += 8;
            }
         } else if (this.armorTier < 1 && this.iron >= 40 && (this.swordTier >= 1 || !bedAlive) && this.pay(Items.IRON_INGOT, 40)) {
            this.armorTier = 1;
            bought = "Kettenruestung";
         } else if (defender && round == 0 && (bought = this.buyDefense()) != null) {
            // Material fuer die eigene Bauweise
         } else if (this.buyUpgrade()) {
            bought = "Team-Upgrade";
         } else if (defender && bedAlive && this.endStone < 12 && this.iron >= 24 && this.pay(Items.IRON_INGOT, 24)) {
            this.endStone += 12;
            bought = "Endstein";
         } else if (defender && bedAlive && this.obsidian < 4 && this.emerald >= 4 && this.armorTier >= 2 && this.pay(Items.EMERALD, 4)) {
            this.obsidian += 4;
            bought = "Obsidian";
         } else if (raider && !this.shears && this.iron >= 20 && this.pay(Items.IRON_INGOT, 20)) {
            this.shears = true;
            bought = "Schere";
         } else if (raider && this.pickaxe < 1 && this.iron >= 10 && this.pay(Items.IRON_INGOT, 10)) {
            this.pickaxe = 1;
            bought = "Holzspitzhacke";
         } else if (raider && this.pickaxe == 1 && this.iron >= 10 && this.pay(Items.IRON_INGOT, 10)) {
            this.pickaxe = 2;
            bought = "Eisenspitzhacke";
         } else if (this.gapples < 2 && this.gold >= 3 && (this.armorTier >= 1 || this.gold >= 8) && this.pay(Items.GOLD_INGOT, 3)) {
            this.gapples++;
            bought = "Goldapfel";
         } else if (raider && this.tnt < 1 && this.gold >= 6 && this.swordTier >= 1 && this.pay(Items.GOLD_INGOT, 4)) {
            this.tnt++;
            bought = "TNT";
         } else if (raider && this.speedPotions < 1 && this.emerald >= 1 && this.armorTier >= 1 && this.pay(Items.EMERALD, 1)) {
            this.speedPotions++;
            bought = "Tempotrank";
         } else if (raider && this.bridgeEggs < 1 && this.emerald >= 1 && this.pay(Items.EMERALD, 1)) {
            this.bridgeEggs++;
            bought = "Bruecken-Ei";
         } else if (raider && this.pearls < 1 && this.emerald >= 4 && this.aggression > 0.55 && this.armorTier >= 2 && this.pay(Items.EMERALD, 4)) {
            this.pearls++;
            bought = "Enderperle";
         } else if (raider && this.milk < 1 && this.gold >= 6 && this.armorTier >= 1 && this.pay(Items.GOLD_INGOT, 4)) {
            this.milk++;
            bought = "Magische Milch";
         } else if (defender && bedAlive && this.popupTowers < 1 && this.iron >= 30 && this.pay(Items.IRON_INGOT, 24)) {
            this.popupTowers++;
            bought = "Pop-Up-Turm";
         } else if (defender && bedAlive && this.golems < 1 && this.iron >= 140 && this.armorTier >= 1 && this.pay(Items.IRON_INGOT, 120)) {
            this.golems++;
            bought = "Traumverteidiger";
         } else if (defender && bedAlive && this.planks < 16 && this.gold >= 6 && this.endStone >= 12 && this.pay(Items.GOLD_INGOT, 4)) {
            this.planks += 16;
            bought = "Holz";
         } else if (this.fireballs < (bedAlive ? 2 : 4) && this.iron >= (bedAlive ? 60 : 45) && this.armorTier >= 1 && this.pay(Items.IRON_INGOT, 40)) {
            this.fireballs++;
            bought = "Feuerball";
         } else if ((fighter || this.role == Role.COLLECTOR) && !this.bow && this.gold >= 14 && this.swordTier >= 2 && this.pay(Items.GOLD_INGOT, 12)) {
            this.bow = true;
            bought = "Bogen";
         } else if (this.bow && this.arrows < 8 && this.gold >= 2 && this.pay(Items.GOLD_INGOT, 2)) {
            this.arrows += 8;
            bought = "Pfeile";
         } else if (fighter && this.bedbugs < 2 && this.iron >= 34 && this.swordTier >= 1 && this.pay(Items.IRON_INGOT, 24)) {
            this.bedbugs++;
            bought = "Bettwanze";
         } else if (fighter && !this.kbStick && this.gold >= 8 && this.swordTier >= 2 && this.pay(Items.GOLD_INGOT, 5)) {
            this.kbStick = true;
            bought = "Rueckstoss-Stock";
         } else if (raider && this.sponges < 2 && this.gold >= 5 && this.raidTargetHasWater() && this.pay(Items.GOLD_INGOT, 3)) {
            this.sponges += 4;
            bought = "Schwamm";
         } else if (raider && this.axe < 2 && this.iron >= 12 && this.raidTargetUses(DefenseStyle.Mat.WOOD) && this.pay(Items.IRON_INGOT, 10)) {
            this.axe++;
            bought = this.axe == 1 ? "Holzaxt" : "Steinaxt";
         } else if (raider && this.axe >= 2 && this.axe < 4 && this.gold >= 8 && this.raidTargetUses(DefenseStyle.Mat.WOOD) && this.pay(Items.GOLD_INGOT, this.axe == 2 ? 3 : 6)) {
            this.axe++;
            bought = this.axe == 3 ? "Eisenaxt" : "Diamantaxt";
         } else if (this.sneaky && raider && this.invisPotions < 1 && this.emerald >= 3 && this.armorTier >= 1 && this.pay(Items.EMERALD, 2)) {
            this.invisPotions++;
            bought = "Unsichtbarkeitstrank";
         } else if (this.snowballer && this.snowballs < 8 && this.iron >= 20 && this.armorTier >= 1 && this.pay(Items.IRON_INGOT, 8)) {
            this.snowballs += 16;
            bought = "Schneebaelle";
         } else if (this.tank && !this.shield && this.gold >= 9 && this.armorTier >= 1 && this.pay(Items.GOLD_INGOT, 6)) {
            this.shield = true;
            bought = "Schild";
         } else if (this.bow && !this.powerBow && this.gold >= 24 && this.pay(Items.GOLD_INGOT, 20)) {
            this.powerBow = true;
            bought = "Power-Bogen";
         } else if (this.rescue < 1 && this.emerald >= 2 && this.armorTier >= 2 && this.pay(Items.EMERALD, 1)) {
            this.rescue++;
            bought = "Rettungsplattform";
         } else if (raider && this.pickaxe == 2 && this.gold >= 9 && this.pay(Items.GOLD_INGOT, 6)) {
            this.pickaxe = 3;
            bought = "Diamantspitzhacke";
         }

         if (bought == null) {
            break;
         }

         Game.count("kauf " + bought);

         if (best == null || bought.startsWith("Diamant") || bought.startsWith("Eisen")) {
            best = bought;
         }
      }

      return best;
   }

   /** Alles, was man einem Bot mit "/@ <bot> kaufen <item>" auftragen kann. */
   public static final java.util.List<String> WISHES = java.util.List.of(
      "wolle", "endstein", "holz", "obsidian", "steinschwert", "eisenschwert", "diamantschwert", "kettenruestung", "eisenruestung",
      "diamantruestung", "schere", "spitzhacke", "goldapfel", "feuerball", "tnt", "enderperle", "brueckenei", "popupturm", "bettwanze",
      "traumverteidiger", "tempotrank", "milch", "rettungsplattform", "bogen", "pfeile", "rueckstossstock",
      "glas", "terrakotta", "wassereimer", "schwamm", "axt", "schneebaelle", "schild", "powerbogen", "unsichtbarkeitstrank",
      "upgrade-schaerfe", "upgrade-schutz", "upgrade-eisenschmiede", "upgrade-heilfeld", "upgrade-eile", "upgrade-falle"
   );

   /** Kauft einen bestimmten Wunsch (gleiche Preise wie fuer Spieler). @return Name des Gekauften oder null */
   public String buyWish(String w) {
      Game.TeamState t = this.team;
      boolean ok = switch (w) {
         case "wolle" -> this.pay(Items.IRON_INGOT, 4) && (this.wool += 16) > 0;
         case "endstein" -> this.pay(Items.IRON_INGOT, 24) && (this.endStone += 12) > 0;
         case "holz" -> this.pay(Items.GOLD_INGOT, 4) && (this.planks += 16) > 0;
         case "obsidian" -> this.pay(Items.EMERALD, 4) && (this.obsidian += 4) > 0;
         case "steinschwert" -> this.swordTier < 1 && this.pay(Items.IRON_INGOT, 10) && (this.swordTier = 1) > 0;
         case "eisenschwert" -> this.swordTier < 2 && this.pay(Items.GOLD_INGOT, 7) && (this.swordTier = 2) > 0;
         case "diamantschwert" -> this.swordTier < 3 && this.pay(Items.EMERALD, 4) && (this.swordTier = 3) > 0;
         case "kettenruestung" -> this.armorTier < 1 && this.pay(Items.IRON_INGOT, 40) && (this.armorTier = 1) > 0;
         case "eisenruestung" -> this.armorTier < 2 && this.pay(Items.GOLD_INGOT, 12) && (this.armorTier = 2) > 0;
         case "diamantruestung" -> this.armorTier < 3 && this.pay(Items.EMERALD, 6) && (this.armorTier = 3) > 0;
         case "schere" -> !this.shears && this.pay(Items.IRON_INGOT, 20) && (this.shears = true);
         case "spitzhacke" -> this.pickaxe < 3 && this.pay(this.pickaxe < 2 ? Items.IRON_INGOT : Items.GOLD_INGOT, this.pickaxe < 2 ? 10 : 6) && (++this.pickaxe) > 0;
         case "goldapfel" -> this.pay(Items.GOLD_INGOT, 3) && (++this.gapples) > 0;
         case "feuerball" -> this.pay(Items.IRON_INGOT, 40) && (++this.fireballs) > 0;
         case "tnt" -> this.pay(Items.GOLD_INGOT, 4) && (++this.tnt) > 0;
         case "enderperle" -> this.pay(Items.EMERALD, 4) && (++this.pearls) > 0;
         case "brueckenei" -> this.pay(Items.EMERALD, 1) && (++this.bridgeEggs) > 0;
         case "popupturm" -> this.pay(Items.IRON_INGOT, 24) && (++this.popupTowers) > 0;
         case "bettwanze" -> this.pay(Items.IRON_INGOT, 24) && (++this.bedbugs) > 0;
         case "traumverteidiger" -> this.pay(Items.IRON_INGOT, 120) && (++this.golems) > 0;
         case "tempotrank" -> this.pay(Items.EMERALD, 1) && (++this.speedPotions) > 0;
         case "milch" -> this.pay(Items.GOLD_INGOT, 4) && (++this.milk) > 0;
         case "rettungsplattform" -> this.pay(Items.EMERALD, 1) && (++this.rescue) > 0;
         case "bogen" -> !this.bow && this.pay(Items.GOLD_INGOT, 12) && (this.bow = true);
         case "pfeile" -> this.pay(Items.GOLD_INGOT, 2) && (this.arrows += 8) > 0;
         case "rueckstossstock" -> !this.kbStick && this.pay(Items.GOLD_INGOT, 5) && (this.kbStick = true);
         case "glas" -> this.buyMaterial(DefenseStyle.Mat.GLASS);
         case "terrakotta" -> this.buyMaterial(DefenseStyle.Mat.TERRACOTTA);
         case "wassereimer" -> this.pay(Items.GOLD_INGOT, 3) && (++this.waterBuckets) > 0;
         case "schwamm" -> this.pay(Items.GOLD_INGOT, 3) && (this.sponges += 4) > 0;
         case "axt" -> this.axe < 4 && this.pay(this.axe < 2 ? Items.IRON_INGOT : Items.GOLD_INGOT, this.axe < 2 ? 10 : (this.axe == 2 ? 3 : 6)) && (++this.axe) > 0;
         case "schneebaelle" -> this.pay(Items.IRON_INGOT, 8) && (this.snowballs += 16) > 0;
         case "schild" -> !this.shield && this.pay(Items.GOLD_INGOT, 6) && (this.shield = true);
         case "powerbogen" -> !this.powerBow && this.pay(Items.GOLD_INGOT, 20) && (this.bow = true) && (this.powerBow = true);
         case "unsichtbarkeitstrank" -> this.pay(Items.EMERALD, 2) && (++this.invisPotions) > 0;
         case "upgrade-schaerfe" -> !t.sharpness && this.pay(Items.DIAMOND, 8) && upgraded(t, "Geschaerfte Klingen", () -> t.sharpness = true);
         case "upgrade-schutz" -> t.protection < 4 && this.pay(Items.DIAMOND, new int[]{5, 10, 20, 30}[t.protection])
            && upgraded(t, "Verstaerkte Ruestung", () -> t.protection++);
         case "upgrade-eisenschmiede" -> t.forge < 4 && this.pay(Items.DIAMOND, new int[]{4, 8, 12, 16}[t.forge]) && upgraded(t, "Eisenschmiede", () -> t.forge++);
         case "upgrade-heilfeld" -> !t.healPool && this.pay(Items.DIAMOND, 3) && upgraded(t, "Heilfeld", () -> t.healPool = true);
         case "upgrade-eile" -> t.haste < 2 && this.pay(Items.DIAMOND, new int[]{4, 6}[t.haste]) && upgraded(t, "Wahnsinniger Bergarbeiter", () -> t.haste++);
         case "upgrade-falle" -> t.traps.size() < 3 && this.pay(Items.DIAMOND, 1 << t.traps.size())
            && upgraded(t, "Falle", () -> t.traps.add(BwItems.Trap.values()[t.traps.size() % BwItems.Trap.values().length]));
         default -> false;
      };
      return ok ? w : null;
   }

   private boolean upgraded(Game.TeamState t, String name, Runnable apply) {
      apply.run();
      Game.upgradeBought(t, name, this, null);
      return true;
   }

   private boolean raidTargetHasWater() {
      Game.TeamState target = this.taskTeam != null ? this.taskTeam : this.team.raidTarget;
      return target != null && target.defenseWater && target.waterPlaced;
   }

   private boolean raidTargetUses(DefenseStyle.Mat m) {
      Game.TeamState target = this.taskTeam != null ? this.taskTeam : this.team.raidTarget;
      return target != null && target.defenseStyle != null && target.defenseStyle.uses(m);
   }

   /** Team-Upgrades kauft ein Bot mit seinen eigenen Diamanten - in einer sinnvollen Reihenfolge. */
   private boolean buyUpgrade() {
      Game.TeamState t = this.team;
      String name = null;
      if (t.forge == 0 && this.pay(Items.DIAMOND, 4)) {
         t.forge = 1;
         name = "Eisenschmiede I";
      } else if (!t.sharpness && this.pay(Items.DIAMOND, 8)) {
         t.sharpness = true;
         name = "Geschaerfte Klingen";
      } else if (t.protection < 1 && this.pay(Items.DIAMOND, 5)) {
         t.protection = 1;
         name = "Verstaerkte Ruestung I";
      } else if (!t.healPool && this.pay(Items.DIAMOND, 3)) {
         t.healPool = true;
         name = "Heilfeld";
      } else if (t.bedAlive && t.traps.isEmpty() && this.pay(Items.DIAMOND, 1)) {
         t.traps.add(BwItems.Trap.values()[java.util.concurrent.ThreadLocalRandom.current().nextInt(BwItems.Trap.values().length)]);
         name = "Falle: " + t.traps.get(0).label;
      } else if (t.protection < 2 && this.pay(Items.DIAMOND, 10)) {
         t.protection = 2;
         name = "Verstaerkte Ruestung II";
      } else if (t.forge == 1 && this.pay(Items.DIAMOND, 8)) {
         t.forge = 2;
         name = "Eisenschmiede II";
      } else if (t.haste < 1 && this.pay(Items.DIAMOND, 4)) {
         t.haste = 1;
         name = "Wahnsinniger Bergarbeiter";
      } else if (t.protection < 3 && this.pay(Items.DIAMOND, 20)) {
         t.protection = 3;
         name = "Verstaerkte Ruestung III";
      }

      if (name == null) {
         return false;
      }

      Game.upgradeBought(t, name, this, null);
      return true;
   }

   private boolean swordTierUp(int tier) {
      this.swordTier = tier;
      return true;
   }

   /** Was er beim Tod verliert - wie im echten Bedwars: Schwert und Bloecke weg, Ruestung bleibt. */
   public void onDeath() {
      this.deaths++;
      int now = Game.tick();
      this.tilt = Math.min(1.0, this.tilt * Math.exp(-(now - this.lastDeathTick) / 1200.0) + 0.35);
      this.lastDeathTick = now;
      this.swordTier = 0;
      this.wool = 0;
      this.endStone = 0;
      this.planks = 0;
      this.fireballs = 0;
      this.gapples = 0;
      this.obsidian = 0;
      this.tnt = 0;
      this.pearls = 0;
      this.bridgeEggs = 0;
      this.popupTowers = 0;
      this.bedbugs = 0;
      this.golems = 0;
      this.speedPotions = 0;
      this.milk = 0;
      this.rescue = 0;
      this.bow = false;
      this.arrows = 0;
      this.kbStick = false;
      this.terracotta = 0;
      this.glass = 0;
      this.waterBuckets = 0;
      this.sponges = 0;
      this.snowballs = 0;
      this.shield = false;
      this.powerBow = false;
      this.invisPotions = 0;
      this.axe = Math.max(0, this.axe - 1);
      this.iron = 0;
      this.gold = 0;
      this.diamond = 0;
      this.emerald = 0;
      this.pickaxe = Math.max(0, this.pickaxe - 1);
   }

   // ------------------------------------------------------------------ Ausruestung

   public ItemStack swordStack() {
      Item item = switch (this.swordTier) {
         case 0 -> Items.WOODEN_SWORD;
         case 1 -> Items.STONE_SWORD;
         case 2 -> Items.IRON_SWORD;
         default -> Items.DIAMOND_SWORD;
      };
      ItemStack stack = new ItemStack(item);
      if (this.team.sharpness) {
         Game.enchant(stack, Enchantments.SHARPNESS, 1);
      }

      return stack;
   }

   public float swordDamage() {
      float base = switch (this.swordTier) {
         case 0 -> 4.0F;
         case 1 -> 5.0F;
         case 2 -> 6.0F;
         default -> 7.0F;
      };
      return this.team.sharpness ? base + 1.0F : base;
   }

   /**
    * Helm und Brustpanzer bleiben weg, damit man Steve und Alex sieht. Deren Ruestungswert
    * (Lederhelm 1 + Lederbrust 3) bekommt der Bot unsichtbar dazu.
    */
   public void equipArmor(BedwarsBot bot) {
      bot.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
      bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
      ItemStack legs = switch (this.armorTier) {
         case 0 -> this.dyed(Items.LEATHER_LEGGINGS);
         case 1 -> new ItemStack(Items.CHAINMAIL_LEGGINGS);
         case 2 -> new ItemStack(Items.IRON_LEGGINGS);
         default -> new ItemStack(Items.DIAMOND_LEGGINGS);
      };
      ItemStack boots = switch (this.armorTier) {
         case 0 -> this.dyed(Items.LEATHER_BOOTS);
         case 1 -> new ItemStack(Items.CHAINMAIL_BOOTS);
         case 2 -> new ItemStack(Items.IRON_BOOTS);
         default -> new ItemStack(Items.DIAMOND_BOOTS);
      };
      Game.enchant(legs, Enchantments.PROTECTION, this.team.protection);
      Game.enchant(boots, Enchantments.PROTECTION, this.team.protection);
      bot.setItemSlot(EquipmentSlot.LEGS, legs);
      bot.setItemSlot(EquipmentSlot.FEET, boots);
      AttributeInstance armor = bot.getAttribute(Attributes.ARMOR);
      if (armor != null) {
         armor.addOrUpdateTransientModifier(new AttributeModifier(VIRTUAL_LEATHER, 4.0 + this.team.protection, AttributeModifier.Operation.ADD_VALUE));
      }
   }

   private ItemStack dyed(Item item) {
      ItemStack stack = new ItemStack(item);
      stack.set(DataComponents.DYED_COLOR, new DyedItemColor(this.team.team.rgb));
      return stack;
   }

   public String taskLabel() {
      return switch (this.task) {
         case IDLE -> "nichts";
         case GATHER -> "Eisen sammeln";
         case SHOP -> "einkaufen";
         case FORTIFY -> "Bett zubauen";
         case DEFEND -> "Bett verteidigen";
         case RAID -> this.taskTeam == null ? "angreifen" : "Bett von " + this.taskTeam.team.label + " holen";
         case MID -> "Diamanten/Smaragde holen";
         case HUNT -> "jagen";
         case ESCORT -> "Teamkollegen begleiten";
         case FOLLOW_PLAYER -> "dir folgen";
         case RETREAT -> "zurueckziehen";
         case REGROUP -> "sammeln";
         case CUT_BRIDGE -> "Bruecke abreissen";
         case HOLD -> "Stelle halten";
      };
   }
}
