package de.glowcube.bedwars;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Der Befehl /bedwars - fuer Mod und Plugin derselbe. */
public final class BwCommands {
   private BwCommands() {
   }

   /** Wer den Befehl ausfuehrt. */
   public record Source(MinecraftServer server, ServerPlayer player, ServerLevel level, BlockPos pos, boolean admin, Consumer<Component> reply) {
   }

   public static List<String> subcommands(boolean admin) {
      List<String> list = new ArrayList<>(List.of("start", "multiplayer", "stop", "ja", "nein", "los", "teams", "abbrechen", "shop", "schwierigkeit", "status", "karten",
         "verlassen", "hilfe"));
      if (!Platform.get().isServerPlugin()) {
         list.add("auto");
      }

      if (admin) {
         list.add("test");
      }

      return list;
   }

   public static List<String> suggest(String[] args, boolean admin) {
      List<String> out = new ArrayList<>();
      if (args.length <= 1) {
         String pre = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
         for (String s : subcommands(admin)) {
            if (s.startsWith(pre)) {
               out.add(s);
            }
         }
      } else if (args.length == 2 && args[0].equalsIgnoreCase("schwierigkeit")) {
         for (String d : Config.DIFFICULTIES) {
            if (d.startsWith(args[1].toLowerCase(Locale.ROOT))) {
               out.add(d);
            }
         }
      } else if (args.length == 2 && args[0].equalsIgnoreCase("auto")) {
         out.addAll(List.of("an", "aus"));
      } else if (args.length == 2 && args[0].equalsIgnoreCase("test")) {
         for (MapTheme t : MapTheme.ALL) {
            out.add(t.key);
         }
      }

      return out;
   }

   private static void fail(Source src, String msg) {
      src.reply.accept(Component.literal(msg).withStyle(ChatFormatting.RED));
   }

   private static void ok(Source src, String msg, ChatFormatting color) {
      src.reply.accept(Component.literal(msg).withStyle(color));
   }

   public static boolean run(Source src, String[] args) {
      String sub = args.length == 0 ? "hilfe" : args[0].toLowerCase(Locale.ROOT);
      ServerPlayer p = src.player;
      boolean plugin = Platform.get().isServerPlugin();
      switch (sub) {
         case "start", "solo" -> {
            if (p == null) {
               fail(src, "Nur fuer Spieler.");
            } else {
               Lobby.startSolo(p);
            }
         }
         case "multiplayer", "mp" -> {
            if (p == null) {
               fail(src, "Nur fuer Spieler.");
            } else {
               Lobby.request(p);
            }
         }
         case "ja" -> {
            if (p != null) {
               Lobby.accept(p);
            }
         }
         case "nein" -> {
            if (p != null) {
               Lobby.decline(p);
            }
         }
         case "los" -> {
            if (p != null) {
               Lobby.startNow(p);
            }
         }
         case "teams" -> {
            if (p != null) {
               Lobby.openTeams(p);
            }
         }
         case "verlassen", "leave" -> {
            if (p != null) {
               Game.leave(p);
            }
         }
         case "abbrechen" -> {
            if (p != null) {
               Lobby.cancel(p);
            }
         }
         case "shop" -> {
            if (p == null) {
               fail(src, "Nur fuer Spieler.");
            } else {
               Shop.open(p);
            }
         }
         case "schwierigkeit", "difficulty" -> {
            if (args.length < 2) {
               ok(src, "Bot-Schwierigkeit: " + Config.DIFFICULTIES[Config.difficulty] + "  (moeglich: leicht, normal, schwer, profi)", ChatFormatting.AQUA);
               return true;
            }

            String want = args[1].toLowerCase(Locale.ROOT);
            for (int i = 0; i < Config.DIFFICULTIES.length; i++) {
               if (Config.DIFFICULTIES[i].equals(want)) {
                  Config.difficulty = i;
                  Config.save();
                  ok(src, "Bot-Schwierigkeit: " + want + " (gilt ab der naechsten Runde)", ChatFormatting.GREEN);
                  return true;
               }
            }

            fail(src, "Gibt es nicht. Moeglich: leicht, normal, schwer, profi");
         }
         case "status" -> ok(src, Game.status(), ChatFormatting.WHITE);
         case "karten", "maps" -> {
            src.reply.accept(Lobby.header("KARTEN"));
            for (int i = 0; i < MapTheme.ALL.size(); i++) {
               MapTheme t = MapTheme.ALL.get(i);
               src.reply.accept(Component.literal((i + 1) + ". ").withStyle(ChatFormatting.GRAY)
                  .append(Component.literal(t.name).withStyle(t.color, ChatFormatting.BOLD))
                  .append(Component.literal(" - " + t.description).withStyle(ChatFormatting.GRAY)));
            }
         }
         case "stop" -> {
            if (!Game.running()) {
               fail(src, "Gerade laeuft keine Runde.");
            } else if (p != null && Game.isHuman(p) && !Game.isRoundHost(p)) {
               // Mitspieler: nur er geht raus, ein Bot uebernimmt seinen Platz
               Game.leave(p);
            } else if (p == null || Game.isRoundHost(p) || src.admin || !plugin) {
               String who = p == null ? "Die Konsole" : p.getName().getString();
               Game.tell(Component.literal(who + " hat die Runde beendet.").withStyle(ChatFormatting.YELLOW));
               Game.stop(true);
               ok(src, "Runde beendet - alle haben ihre Sachen zurueck.", ChatFormatting.YELLOW);
            } else {
               fail(src, "Du spielst in dieser Runde nicht mit.");
            }
         }
         case "auto" -> {
            if (plugin) {
               fail(src, "Gibt es nur in der Mod.");
            } else {
               Game.autoStart = args.length > 1 && args[1].equalsIgnoreCase("an");
               ok(src, "Automatischer Start beim Betreten: " + (Game.autoStart ? "an" : "aus"), ChatFormatting.GREEN);
            }
         }
         case "verteidigung" -> {
            if (src.admin) {
               ok(src, Game.defenseReport(), ChatFormatting.WHITE);
            }
         }
         case "szenario" -> {
            if (src.admin) {
               ok(src, Game.scenarioBed(), ChatFormatting.YELLOW);
            }
         }
         case "reflex" -> {
            if (src.admin) {
               ok(src, Game.scenarioReflex(), ChatFormatting.YELLOW);
            }
         }
         case "test" -> {
            if (!src.admin) {
               fail(src, "Nur fuer Admins.");
               return false;
            }

            int map = MapWheel.pick();
            if (args.length > 1) {
               for (int i = 0; i < MapTheme.ALL.size(); i++) {
                  if (MapTheme.ALL.get(i).key.equalsIgnoreCase(args[1]) || String.valueOf(i + 1).equals(args[1])) {
                     map = i;
                  }
               }
            }

            ServerLevel level = Platform.get().arenaLevel(src.server, p);
            Game.startRound(src.server, level, Platform.get().arenaCenter(level, p), List.of(), null, map, true);
            ok(src, "Bot-Testrunde auf " + MapTheme.ALL.get(map).name + " gestartet (Protokoll in der Konsole). Stoppen: /bedwars stop", ChatFormatting.YELLOW);
         }
         case "export" -> {
            // Entwickler-Werkzeug: baut alle Karten nacheinander und schreibt ihre Bloecke in Dateien (fuer Vorschaubilder)
            if (!src.admin || Game.running()) {
               fail(src, "Nur fuer Admins und nur, wenn keine Runde laeuft.");
               return false;
            }

            ServerLevel level = Platform.get().arenaLevel(src.server, p);
            BlockPos center = Platform.get().arenaCenter(level, p);
            for (MapTheme t : MapTheme.ALL) {
               Arena a = new Arena(level, center, t);
               a.forceLoad(true);
               a.build();
               StringBuilder sb = new StringBuilder();
               for (var e : a.map.long2ObjectEntrySet()) {
                  BlockPos bp = BlockPos.of(e.getLongKey());
                  sb.append(bp.getX() - a.center.getX()).append(' ').append(bp.getY() - Arena.Y).append(' ').append(bp.getZ() - a.center.getZ()).append(' ')
                     .append(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(e.getValue().getBlock()).getPath()).append('\n');
               }

               try {
                  java.nio.file.Files.writeString(Platform.get().configDir().resolve("export_" + t.key + ".txt"), sb.toString());
               } catch (Exception ex) {
                  fail(src, "Export fehlgeschlagen: " + ex);
               }

               a.clear();
               a.forceLoad(false);
            }

            ok(src, "Karten exportiert nach " + Platform.get().configDir(), ChatFormatting.GREEN);
         }
         case "train", "record" -> {
            if (plugin || !src.admin || args.length < 2) {
               fail(src, "/bedwars " + sub + " <ordner> (nur Mod, nur Admins)");
               return false;
            }

            Game.startTraining(src.server, src.level, src.pos, Path.of(args[1]), sub.equals("record"));
         }
         case "say" -> {
            if (args.length > 1) {
               ServerPlayer who = p;
               if (who == null && !Game.humans().isEmpty()) {
                  who = Game.humans().get(0).p;
               }

               if (who != null && Game.isHuman(who)) {
                  BotChat.onPlayerChat(who, String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)));
               }
            }
         }
         default -> help(src);
      }

      return true;
   }

   private static void help(Source src) {
      src.reply.accept(Lobby.header("BEDWARS"));
      line(src, "/bedwars start", "allein mit 19 Bots spielen");
      line(src, "/bedwars multiplayer", "alle einladen (" + Config.inviteSeconds + " s zum Annehmen), Teams einteilen, Gluecksrad");
      line(src, "/bedwars stop", "Gastgeber: Runde fuer alle beenden - Mitspieler: nur selbst raus, ein Bot uebernimmt");
      line(src, "/bedwars shop", "Shop oeffnen (waehrend der Runde)");
      line(src, "/@ <wer> <befehl>", "deinen Bots Befehle geben (Tab zeigt alle)");
      line(src, "/bedwars schwierigkeit <stufe>", "leicht, normal, schwer oder profi");
      line(src, "/bedwars karten", "alle Karten");
      line(src, "/bedwars status", "Teams, Betten und was die Bots gerade tun");
   }

   private static void line(Source src, String cmd, String what) {
      src.reply.accept(Component.literal(cmd).withStyle(ChatFormatting.GOLD).append(Component.literal(" - " + what).withStyle(ChatFormatting.GRAY)));
   }
}
