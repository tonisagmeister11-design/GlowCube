package de.glowcube.bedwars;

import java.util.Random;

/**
 * Wie ein Bot sein Bett einbaut. Jede Schicht (1 = direkt am Bett, 3 = aussen) hat ihr Material.
 * Mit Wasser: zuerst die erste und zweite Schicht, dann kommt ein Wassereimer direkt aufs Bett (eingeschlossen,
 * es fliesst nicht weg), dann die aeussere Schicht. Wasser schuetzt die Bloecke daneben vor TNT und Feuerbaellen
 * und macht das Abbauen langsamer.
 */
public enum DefenseStyle {
   WOLLE("nur Wolle", Mat.WOOL),
   WOLLE_DOPPELT("doppelt Wolle", Mat.WOOL, Mat.WOOL),
   KLASSISCH("Wolle und Endstein", Mat.WOOL, Mat.END_STONE),
   TERRAKOTTA("Wolle und Terrakotta", Mat.WOOL, Mat.TERRACOTTA),
   ENDSTEIN("nur Endstein", Mat.END_STONE, Mat.END_STONE),
   HYPIXEL("Wolle, Endstein, Holz", Mat.WOOL, Mat.END_STONE, Mat.WOOD),
   GLAS("Glas, Endstein, Wolle", Mat.GLASS, Mat.END_STONE, Mat.WOOL),
   BUNKER("Holz, Endstein, Glas", Mat.WOOD, Mat.END_STONE, Mat.GLASS),
   OBSIDIAN("Obsidian, Endstein, Holz", Mat.OBSIDIAN, Mat.END_STONE, Mat.WOOD);

   /** Material einer Schicht - mit Preis, wie es im Shop steht. */
   public enum Mat {
      WOOL("Wolle", 0, 4),
      END_STONE("Endstein", 0, 24),
      WOOD("Holz", 1, 4),
      GLASS("Glas", 0, 12),
      TERRACOTTA("Terrakotta", 0, 12),
      OBSIDIAN("Obsidian", 2, 4);

      public final String label;
      /** Waehrung: 0 Eisen, 1 Gold, 2 Smaragd. */
      public final int currency;
      /** Preis fuer ein Paket. */
      public final int price;

      Mat(String label, int currency, int price) {
         this.label = label;
         this.currency = currency;
         this.price = price;
      }
   }

   public final String label;
   private final Mat[] layers;

   DefenseStyle(String label, Mat... layers) {
      this.label = label;
      this.layers = layers;
   }

   public int layers() {
      return this.layers.length;
   }

   /** Material fuer Schicht 1..n (darueber hinaus die aeusserste). */
   public Mat mat(int layer) {
      return this.layers[Math.max(0, Math.min(this.layers.length - 1, layer - 1))];
   }

   public boolean uses(Mat m) {
      for (Mat x : this.layers) {
         if (x == m) {
            return true;
         }
      }

      return false;
   }

   /** Was ein Bot mit diesem Bau-Talent am liebsten baut. */
   public static DefenseStyle pick(double build, Random r) {
      DefenseStyle[] pool;
      if (build < 0.3) {
         pool = new DefenseStyle[]{WOLLE, WOLLE, WOLLE_DOPPELT, KLASSISCH};
      } else if (build < 0.55) {
         pool = new DefenseStyle[]{WOLLE_DOPPELT, KLASSISCH, KLASSISCH, TERRAKOTTA, ENDSTEIN};
      } else if (build < 0.75) {
         pool = new DefenseStyle[]{KLASSISCH, HYPIXEL, HYPIXEL, GLAS, ENDSTEIN, TERRAKOTTA};
      } else {
         pool = new DefenseStyle[]{HYPIXEL, HYPIXEL, GLAS, BUNKER, ENDSTEIN, OBSIDIAN};
      }

      return pool[r.nextInt(pool.length)];
   }

   /** Macht er noch Wasser aufs Bett? Gute Bauer eher als Anfaenger. */
   public static boolean pickWater(double build, Random r) {
      return r.nextDouble() < 0.1 + build * 0.4;
   }
}
