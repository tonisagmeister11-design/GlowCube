package de.glowcube.bedwars;

import java.util.Random;

/**
 * Wie ein Mensch an Maus und Tastatur. Jeder Bot hat drei eigene Talente, unabhaengig voneinander:
 * <ul>
 *    <li><b>PvP</b> - Reaktion, Zielen, Klick-Rhythmus, Strafen, W-Tap, Krits, Feuerbaelle zurueckschlagen</li>
 *    <li><b>Bauen</b> - wie schnell und sicher er brueckt, hochbaut, clutcht, wie aufwendig er sein Bett einbaut</li>
 *    <li><b>Uebersicht</b> - bemerkt Gegner frueh, weicht Geschossen aus, macht wenige Aussetzer, vergisst nichts</li>
 * </ul>
 * So gibt es den PvP-Gott, der beim Bruecken runterfaellt, und den perfekten Bauer, der im Kampf daneben klickt.
 * Alle Werte haben dazu noch eine persoenliche Streuung - keine zwei Bots spielen gleich.
 */
public final class Hands {
   public enum Style {
      /** Laeuft geradeaus drauf, spammt Klicks, faellt beim Bruecken runter. */
      NOOB("Anfaenger"),
      /** Spielt ab und zu, mal gut, mal schlecht. */
      CASUAL("Gelegenheitsspieler"),
      /** Kann strafen, timt seine Schlaege meistens. */
      SOLID("solide"),
      /** Schwitzt: W-Tap, Krits, schnelles Bruecken - aber auch kein Roboter. */
      SWEAT("Schwitzer");

      public final String label;

      Style(String label) {
         this.label = label;
      }
   }

   public final Style style;
   /** 0..1 - Kampfgefuehl. */
   public final double pvp;
   /** 0..1 - Bauen, Bruecken, Hochbauen. */
   public final double build;
   /** 0..1 - Uebersicht und Entscheidungen. */
   public final double sense;

   /** Wie viele Ticks er hinterherhinkt, bis er eine Bewegung des Gegners sieht (4 = 200 ms). */
   public final int reaction;
   /** Wie viele Grad er pro Tick das Fadenkreuz hoechstens bewegt. */
   public final double aimSpeed;
   /** Wie stark er nachzieht (Anteil der Abweichung pro Tick). */
   public final double aimGain;
   /** Zittern beim Zielen in Grad. */
   public final double aimNoise;
   /** Ueberschiessen beim Herumreissen der Maus. */
   public final double overshoot;
   /** 0..1: wartet er die Schlag-Abklingzeit ab (1) oder spammt er (0)? */
   public final double timing;
   /** Klicks pro Sekunde, wenn er spammt. */
   public final double cps;
   /** Ab welcher Entfernung er schon (zu frueh) losklickt. */
   public final double clickRange;
   public final double strafe;
   public final double wtap;
   public final double crits;
   /** Wie gut er beim Kaempfen auf die Kante achtet (0 = gar nicht). */
   public final double edge;
   /** Ticks zwischen zwei gesetzten Bloecken beim Bruecken. */
   public final int bridgeDelay;
   /** Chance pro Bruecken-Block, sich zu verschaetzen und runterzufallen. */
   public final double bridgeSlip;
   public final double clutch;
   /** Chance, beim Kampf einen Moment abzuschalten (stehen bleiben, falsch laufen). */
   public final double brainfart;
   /** Chance, in Not den Goldapfel zu vergessen. */
   public final double forgetGapple;
   /** Entdeckt er Gegner frueh oder erst spaet? */
   public final double awareness;
   /** Kann er sich in Not hochbauen? */
   public final double pillar;
   /** Weicht er heranfliegenden Pfeilen und Feuerbaellen aus? */
   public final double dodge;
   /** Schlaegt er einen Feuerball zurueck, der auf ihn zufliegt? */
   public final double deflect;
   /** Ticks, die er nach einem Item-Wechsel braucht, bis er wieder zuschlaegt (Hotbar-Taste druecken). */
   public final int switchDelay;
   /** Wie oft er beim Sprinten springt (wie viele Spieler auf langen Wegen). */
   public final double sprintJump;
   private final double aimSpeedJitter;

   private static double lerp(double a, double b, double t) {
      return a + (b - a) * Math.max(0.0, Math.min(1.0, t));
   }

   private static double clamp01(double v) {
      return Math.max(0.03, Math.min(0.98, v));
   }

   private static double center(Style s) {
      return switch (s) {
         case NOOB -> 0.18;
         case CASUAL -> 0.42;
         case SOLID -> 0.66;
         case SWEAT -> 0.88;
      };
   }

   private Hands(Style s, Random r) {
      double c = center(s);
      // drei Talente, jedes fuer sich gestreut
      this.pvp = clamp01(c + r.nextGaussian() * 0.13);
      this.build = clamp01(c + r.nextGaussian() * 0.16);
      this.sense = clamp01(c + r.nextGaussian() * 0.13);
      double avg = (this.pvp + this.build + this.sense) / 3.0;
      this.style = avg < 0.3 ? Style.NOOB : (avg < 0.54 ? Style.CASUAL : (avg < 0.77 ? Style.SOLID : Style.SWEAT));
      double p = this.pvp;
      double b = this.build;
      double e = this.sense;
      // jede Eigenschaft bekommt noch ein wenig persoenliche Streuung
      this.reaction = (int)Math.round(lerp(12.5, 2.8, p) + r.nextGaussian() * 0.8);
      this.aimSpeed = lerp(7.0, 29.0, p) * (1.0 + r.nextGaussian() * 0.08);
      this.aimGain = lerp(0.22, 0.68, p) * (1.0 + r.nextGaussian() * 0.06);
      this.aimNoise = Math.max(0.6, lerp(7.5, 1.0, p) * (1.0 + r.nextGaussian() * 0.12));
      this.overshoot = lerp(0.36, 0.08, p);
      this.timing = clamp01(lerp(0.06, 0.95, p) + r.nextGaussian() * 0.06);
      this.cps = lerp(5.5, 11.0, p) + r.nextDouble() * 2.5;
      this.clickRange = lerp(4.5, 3.2, p);
      this.strafe = clamp01(lerp(0.06, 0.95, p) + r.nextGaussian() * 0.07);
      this.wtap = clamp01(lerp(0.0, 0.8, p * p));
      this.crits = clamp01(lerp(0.04, 0.75, p));
      this.edge = lerp(0.8, 0.99, e);
      this.bridgeDelay = Math.max(2, (int)Math.round(lerp(11.0, 2.0, b) + r.nextGaussian() * 0.6));
      this.bridgeSlip = lerp(0.012, 0.0002, b);
      this.clutch = lerp(0.03, 0.8, b);
      this.brainfart = lerp(0.02, 0.0008, e);
      this.forgetGapple = lerp(0.6, 0.02, e);
      this.awareness = lerp(0.6, 1.0, e);
      this.pillar = lerp(0.1, 0.92, b);
      this.dodge = clamp01(lerp(0.0, 0.85, (p + e) / 2.0 - 0.15));
      this.deflect = p < 0.55 ? 0.0 : lerp(0.0, 0.7, (p - 0.55) / 0.45);
      this.switchDelay = Math.max(1, (int)Math.round(lerp(9.0, 2.0, p) + r.nextGaussian()));
      this.sprintJump = r.nextDouble() < 0.25 + p * 0.5 ? lerp(0.02, 0.09, p) : 0.0;
      this.aimSpeedJitter = 1.0 + r.nextGaussian() * 0.1;
   }

   public double aimSpeed() {
      return this.aimSpeed * this.aimSpeedJitter;
   }

   /** Ein Wert 0..1 fuer alles, was grob "wie gut" heisst. */
   public double skill() {
      return (this.pvp + this.build + this.sense) / 3.0;
   }

   /** 1..10 fuer die Anzeige. */
   public static int rating(double v) {
      return Math.max(1, Math.min(10, (int)Math.round(v * 10.0)));
   }

   /** "PvP 7 / Bauen 4 / Uebersicht 6" */
   public String describe() {
      return "PvP " + rating(this.pvp) + ", Bauen " + rating(this.build) + ", Uebersicht " + rating(this.sense);
   }

   /** Wuerfelt einen Spielertyp passend zur eingestellten Schwierigkeit. */
   public static Hands roll(Random r, int difficulty) {
      double[] pr = switch (difficulty) {
         case 0 -> new double[]{0.45, 0.4, 0.13, 0.02};
         case 2 -> new double[]{0.05, 0.3, 0.45, 0.2};
         case 3 -> new double[]{0.0, 0.1, 0.45, 0.45};
         default -> new double[]{0.2, 0.45, 0.28, 0.07};
      };
      double x = r.nextDouble();
      Style s = Style.SWEAT;
      double acc = 0.0;

      for (int i = 0; i < 4; i++) {
         acc += pr[i];
         if (x < acc) {
            s = Style.values()[i];
            break;
         }
      }

      return new Hands(s, r);
   }
}
