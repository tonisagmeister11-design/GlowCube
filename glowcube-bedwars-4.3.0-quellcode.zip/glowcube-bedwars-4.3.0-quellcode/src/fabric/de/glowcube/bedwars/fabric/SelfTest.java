package de.glowcube.bedwars.fabric;

import com.mojang.authlib.GameProfile;
import de.glowcube.bedwars.Arena;
import de.glowcube.bedwars.BwEntities;
import de.glowcube.bedwars.BotCommands;
import de.glowcube.bedwars.BotProfile;
import de.glowcube.bedwars.BwItems;
import de.glowcube.bedwars.DefenseStyle;
import de.glowcube.bedwars.Hands;
import de.glowcube.bedwars.Game;
import de.glowcube.bedwars.Shop;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Entwickler-Selbsttest (/bedwars selbsttest, nur Mod, nur Admins): ein Test-Spieler spielt eine Runde,
 * kauft ein, benutzt jedes Spezial-Item und bekommt am Ende seine Sachen zurueck. Ergebnis in der Konsole.
 */
final class SelfTest {
   private static FakePlayer fake;
   private static int step = -1;
   private static int at;
   private static final List<String> fails = new ArrayList<>();
   private static int passes;

   private SelfTest() {
   }

   static void start(MinecraftServer server, ServerLevel level, BlockPos near) {
      fails.clear();
      passes = 0;
      List<net.minecraft.server.level.ServerPlayer> crowd = new ArrayList<>();
      for (int i = 0; i < 9; i++) {
         crowd.add(FakePlayer.get(level, new GameProfile(UUID.fromString("00000000-0000-4000-8000-0000000000" + (10 + i)), "Spieler" + i)));
      }

      List<String> ts = de.glowcube.bedwars.TeamSelect.selfTest(server, crowd);
      check("Teamwahl (Koepfe ziehen, tauschen, volle Teams, Zufall) " + ts, ts.isEmpty());
      List<String> mw = de.glowcube.bedwars.MapWheel.selfTest();
      check("Gluecksrad: keine Doppel, alle Karten kommen vor " + mw, mw.isEmpty());
      fake = FakePlayer.get(level, new GameProfile(UUID.fromString("00000000-0000-4000-8000-00000000beef"), "Tester"));
      fake.setGameMode(GameType.SURVIVAL);
      fake.setPos(near.getX() + 0.5, near.getY() + 1.0, near.getZ() + 0.5);
      fake.getInventory().clearContent();
      fake.getInventory().add(new ItemStack(Items.DIAMOND, 7));
      fake.getInventory().add(new ItemStack(Items.TORCH, 33));
      fake.experienceLevel = 5;
      Game.startRound(server, level, near, List.of(fake), Map.of(fake.getUUID(), 0), 1, false);
      check("Runde laeuft", Game.running());
      check("Test-Spieler spielt mit", Game.isHuman(fake));
      check("Inventar fuer die Runde geleert", Shop.count(fake.getInventory(), Items.DIAMOND) == 0);
      checks43(level);
      step = 0;
      at = server.getTickCount() + 20;
   }

   /** 4.3: Talente, Bauweisen, Lieblings-Items, Nachbessern der Verteidigung und Wasser gegen Explosionen. */
   private static void checks43(ServerLevel level) {
      java.util.Random r = new java.util.Random(43);
      double[] avg = new double[4];
      boolean spread = true;
      for (int d = 0; d < 4; d++) {
         int lo = 10;
         int hi = 1;
         for (int i = 0; i < 300; i++) {
            Hands h = Hands.roll(r, d);
            avg[d] += h.skill() / 300.0;
            lo = Math.min(lo, Hands.rating(h.pvp));
            hi = Math.max(hi, Hands.rating(h.pvp));
         }

         spread &= hi - lo >= 3;
      }

      check("Talente: Schwierigkeit verschiebt den Schnitt " + java.util.Arrays.toString(avg), avg[0] < avg[1] && avg[1] < avg[2] && avg[2] < avg[3]);
      check("Talente: jeder Bot anders (PvP-Spanne je Stufe >= 3)", spread);
      java.util.Set<DefenseStyle> styles = java.util.EnumSet.noneOf(DefenseStyle.class);
      int waterLo = 0;
      int waterHi = 0;
      for (int i = 0; i < 2000; i++) {
         styles.add(DefenseStyle.pick(r.nextDouble(), r));
         waterLo += DefenseStyle.pickWater(0.1, r) ? 1 : 0;
         waterHi += DefenseStyle.pickWater(0.9, r) ? 1 : 0;
      }

      check("Bauweisen: alle " + DefenseStyle.values().length + " kommen vor (" + styles.size() + ")", styles.size() == DefenseStyle.values().length);
      check("Wasser aufs Bett: gute Bauer oefter (" + waterLo + " < " + waterHi + ")", waterLo > 0 && waterLo < waterHi);
      java.util.Set<String> favs = new java.util.HashSet<>();
      for (Game.TeamState ts : Game.teams()) {
         for (BotProfile bp : ts.bots) {
            if (bp.favorite != null) {
               favs.add(bp.favorite);
            }
         }
      }

      check("Lieblings-Items verschieden " + favs, favs.size() >= 3);

      // Nachbessern: Wolle, wo Endstein hingehoert
      Game.TeamState u = Game.teams().get(3);
      BotProfile b = u.bots.get(0);
      u.defenseStyle = DefenseStyle.ENDSTEIN;
      u.defenseWater = false;
      u.builderName = b.name;
      List<Game.DefenseCell> l1 = u.defensePlan().stream().filter(c -> c.layer() == 1).toList();
      List<Game.DefenseCell> l2 = u.defensePlan().stream().filter(c -> c.layer() == 2).toList();
      net.minecraft.world.level.block.state.BlockState wool = u.team.wool.defaultBlockState();
      net.minecraft.world.level.block.state.BlockState air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
      l1.forEach(c -> level.setBlock(c.pos(), wool, 3));
      check("Nachbessern: Wolle in Schicht 1 gilt als improvisiert (" + u.improvisedInLayer(1) + "/" + l1.size() + ")",
         !l1.isEmpty() && l1.stream().allMatch(u::isImprovised) && u.improvisedInLayer(1) == l1.size());
      check("Nachbessern: Bauweise will Endstein", u.upgradeMat() == DefenseStyle.Mat.END_STONE);
      int ironBefore = b.iron;
      int endBefore = b.endStone;
      BotProfile.Task taskBefore = b.task;
      b.iron = 48;
      b.endStone = 0;
      check("Bauer will zum Haendler (Endstein)", b.wantsDefenseUpgrade());
      b.task = BotProfile.Task.FORTIFY;
      b.shop();
      check("Bauer kauft zuerst Endstein statt Schwert (" + b.endStone + " Endstein, Schwert " + b.swordTier + ")", b.endStone >= 12);
      l2.forEach(c -> level.setBlock(c.pos(), wool, 3));
      check("Nachbessern: innere Schicht wird nicht aufgerissen", l1.stream().noneMatch(c -> u.canUpgradeCell(c.pos())));
      check("Nachbessern: aeussere Schicht ist erreichbar", l2.stream().anyMatch(c -> u.canUpgradeCell(c.pos())));
      l1.forEach(c -> level.setBlock(c.pos(), air, 3));
      l2.forEach(c -> level.setBlock(c.pos(), air, 3));
      u.defenseStyle = null;
      u.builderName = null;
      b.task = taskBefore;
      b.iron = ironBefore;
      b.endStone = endBefore;

      // Wasser schluckt Explosionen: Wolle am Wasser bleibt, Wolle ohne Wasser fliegt weg
      BlockPos base = BlockPos.containing(Game.teams().get(2).island().spawn()).above(5);
      BlockPos wetWool = base;
      BlockPos dryWool = base.east(2);
      level.setBlock(wetWool, wool, 3);
      level.setBlock(dryWool, wool, 3);
      level.setBlock(base.above(), net.minecraft.world.level.block.Blocks.WATER.defaultBlockState(), 3);
      BwEntities.explode(level, Vec3.atCenterOf(base.east()), null, null, 3.0F, 0.0F, 0.0, false);
      check("Wasser schuetzt den Block daneben vor Explosionen", level.getBlockState(wetWool).is(net.minecraft.tags.BlockTags.WOOL));
      check("ohne Wasser wird gesprengt", level.getBlockState(dryWool).isAir());
      level.setBlock(base.above(), air, 3);
      level.setBlock(wetWool, air, 3);
      level.setBlock(dryWool, air, 3);
   }

   private static void check(String what, boolean ok) {
      if (ok) {
         passes++;
         System.out.println("[Selbsttest] OK   " + what);
      } else {
         fails.add(what);
         System.out.println("[Selbsttest] FEHL " + what);
      }
   }

   /** Das echte Item (nicht eine Kopie) in die Hand nehmen. */
   private static void hold(ItemStack s) {
      for (int i = 0; i < fake.getInventory().getContainerSize(); i++) {
         if (fake.getInventory().getItem(i) == s) {
            fake.getInventory().setItem(i, ItemStack.EMPTY);
         }
      }

      fake.setItemInHand(InteractionHand.MAIN_HAND, s);
   }

   private static ItemStack find(String id) {
      for (int i = 0; i < fake.getInventory().getContainerSize(); i++) {
         ItemStack s = fake.getInventory().getItem(i);
         if (id.equals(BwItems.idOf(s))) {
            return s;
         }
      }

      return ItemStack.EMPTY;
   }

   private static long count(ServerLevel level, AABB box, Class<? extends Entity> type) {
      return level.getEntitiesOfClass(type, box).size();
   }

   private static int woolAround(ServerLevel level, BlockPos c, int r) {
      int n = 0;
      for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -3, -r), c.offset(r, 8, r))) {
         if (level.getBlockState(p).is(net.minecraft.tags.BlockTags.WOOL)) {
            n++;
         }
      }

      return n;
   }

   static void tick(MinecraftServer server) {
      if (step < 0 || server.getTickCount() < at) {
         return;
      }

      ServerLevel level = (ServerLevel)fake.level();
      Arena arena = Game.arena();
      Arena.Island is = Game.teamOfPlayer(fake) == null ? null : Game.teamOfPlayer(fake).island();
      switch (step) {
         case 0 -> {
            check("Test-Spieler steht auf seiner Insel", is != null && fake.position().distanceTo(is.spawn()) < 4.0);
            // ---- Bot-Befehle (/@)
            Game.TeamState my = Game.teamOfPlayer(fake);
            check("Tab: /@ alle ka -> kaufen", BotCommands.suggest(fake, new String[]{"alle", "ka"}).contains("kaufen"));
            check("Tab: /@ alle kaufen feu -> feuerball", BotCommands.suggest(fake, new String[]{"alle", "kaufen", "feu"}).contains("feuerball"));
            check("Tab: Bot-Namen", BotCommands.suggest(fake, new String[]{""}).contains(my.bots.get(0).name.toLowerCase()));
            BotCommands.run(fake, new String[]{"alle", "verteidigen"});
            check("/@ alle verteidigen", my.bots.stream().allMatch(b -> b.task == BotProfile.Task.DEFEND));
            BotProfile first = my.bots.get(0);
            BotCommands.run(fake, new String[]{first.name.toLowerCase(), "angreifen", "blau"});
            check("/@ <bot> angreifen blau", first.taskTeam == Game.teams().get(1) && (first.task == BotProfile.Task.RAID || first.task == BotProfile.Task.SHOP));
            first.iron += 45;
            BotCommands.run(fake, new String[]{first.name.toLowerCase(), "kaufen", "feuerball"});
            int fbBefore = first.fireballs;
            first.shop();
            check("/@ <bot> kaufen feuerball (kauft mit eigenem Geld)", first.fireballs == fbBefore + 1 && first.wish == null && first.iron < 45);
            first.gold += 0;
            BotProfile second = my.bots.get(1);
            second.gold = 9;
            if (second.body != null) {
               second.body.teleportTo(fake.getX() + 1.0, fake.getY(), fake.getZ());
            }

            int goldBefore = Shop.count(fake.getInventory(), Items.GOLD_INGOT);
            BotCommands.run(fake, new String[]{second.name.toLowerCase(), "gib", "gold"});
            check("/@ <bot> gib gold", Shop.count(fake.getInventory(), Items.GOLD_INGOT) == goldBefore + 9 && second.gold == 0);
            BotCommands.run(fake, "bitte alle das bett verteidigen".split(" "));
            check("frei formuliert: bitte alle das bett verteidigen", my.bots.stream().allMatch(b -> b.task == BotProfile.Task.DEFEND));
            BotCommands.run(fake, (first.name.toLowerCase() + " greif mal gelb an").split(" "));
            check("frei formuliert: <bot> greif mal gelb an", first.taskTeam == Game.teams().get(3));
            BotCommands.run(fake, "kommt alle her".split(" "));
            check("frei formuliert: kommt alle her", my.bots.stream().allMatch(b -> b.task == BotProfile.Task.FOLLOW_PLAYER && b.taskEntity == fake));
            BotCommands.run(fake, new String[]{"alle", "frei"});
            check("/@ alle frei", my.bots.stream().allMatch(b -> b.taskLockUntil == 0));
            fake.getInventory().add(new ItemStack(Items.IRON_INGOT, 64 * 6));
            fake.getInventory().add(new ItemStack(Items.GOLD_INGOT, 64));
            fake.getInventory().add(new ItemStack(Items.EMERALD, 30));
            fake.getInventory().add(new ItemStack(Items.DIAMOND, 30));
            for (String k : List.of("wool", "popup_tower", "tnt", "bridge_egg", "fireball", "golem", "bedbug", "rescue", "milk", "tracker",
               "pickaxe1", "iron_sword", "chain_armor", "terracotta", "glass", "obsidian", "speed", "bow", "arrows", "kb_stick")) {
               check("Kauf: " + k, Shop.debugBuy(fake, k));
            }

            check("Upgrade Eisenschmiede", Shop.debugBuy(fake, "u_forge") && Game.teamOfPlayer(fake).forge == 1);
            check("Falle gekauft", Shop.debugBuy(fake, "trap_blind") && Game.teamOfPlayer(fake).traps.size() == 1);
            check("Diamanten richtig abgezogen", Shop.count(fake.getInventory(), Items.DIAMOND) == 30 - 4 - 1);
            check("Schwert ersetzt", Shop.count(fake.getInventory(), Items.IRON_SWORD) == 1 && Shop.count(fake.getInventory(), Items.WOODEN_SWORD) == 0);
            // vor den Spawn stellen, Blick zur Mitte
            Vec3 spot = is.atVec(0.0, 1.0, 1.0);
            fake.setPos(spot.x, spot.y, spot.z);
            fake.setYRot(is.forward.toYRot());
            fake.setXRot(0.0F);
            hold(find(BwItems.POPUP_TOWER));
            check("Pop-Up-Turm benutzt", BwItems.onUse(fake, InteractionHand.MAIN_HAND));
            at = server.getTickCount() + 60;
            step++;
         }
         case 1 -> {
            BlockPos c = fake.blockPosition().relative(is.forward, 3);
            int wool = woolAround(level, c, 3);
            check("Pop-Up-Turm steht (" + wool + " Wollbloecke)", wool > 60);
            // TNT auf den Boden neben den Turm
            BlockPos floor = is.at(3, 0, -2);
            hold(find(BwItems.TNT));
            check("TNT gesetzt", BwItems.onUseOnBlock(fake, InteractionHand.MAIN_HAND, floor, Direction.UP));
            check("TNT brennt", count(level, new AABB(floor).inflate(2.0), BwEntities.Tnt.class) == 1);
            at = server.getTickCount() + 70;
            step++;
         }
         case 2 -> {
            BlockPos floor = is.at(3, 0, -2);
            check("TNT ist explodiert", count(level, new AABB(floor).inflate(3.0), BwEntities.Tnt.class) == 0);
            check("Karte nach der Explosion heil", arena.isMap(floor) && !level.getBlockState(floor).isAir());
            check("Test-Spieler lebt noch", Game.humans().get(0).active() || Game.humans().get(0).respawnAt >= 0);
            hold(find(BwItems.FIREBALL));
            fake.setXRot(10.0F);
            check("Feuerball geworfen", BwItems.onUse(fake, InteractionHand.MAIN_HAND)
               && count(level, fake.getBoundingBox().inflate(6.0), BwEntities.Fireball.class) == 1);
            at = server.getTickCount() + 10;
            step++;
         }
         case 3 -> {
            // nach hinten von der Insel weg werfen (vorne steht jetzt der Turm)
            Vec3 back = is.atVec(0.0, 1.0, -5.0);
            fake.setPos(back.x, back.y, back.z);
            fake.setYRot(is.forward.getOpposite().toYRot());
            fake.setXRot(5.0F);
            hold(find(BwItems.BRIDGE_EGG));
            check("Bruecken-Ei geworfen", BwItems.onUse(fake, InteractionHand.MAIN_HAND));
            at = server.getTickCount() + 30;
            step++;
         }
         case 4 -> {
            int wool = 0;
            for (int d = 4; d < 30; d++) {
               for (int y = -5; y <= 1; y++) {
                  BlockPos p = BlockPos.containing(fake.position().add(Vec3.atLowerCornerOf(is.forward.getOpposite().getUnitVec3i()).scale(d))).above(y);
                  if (level.getBlockState(p).is(net.minecraft.tags.BlockTags.WOOL)) {
                     wool++;
                  }
               }
            }

            check("Bruecken-Ei hat eine Bruecke gebaut (" + wool + " Bloecke)", wool >= 5);
            hold(find(BwItems.GOLEM));
            check("Traumverteidiger gerufen", BwItems.onUseOnBlock(fake, InteractionHand.MAIN_HAND, is.at(-3, 0, -4), Direction.UP));
            at = server.getTickCount() + 8;
            step = 40;
         }
         case 40 -> {
            hold(find(BwItems.BEDBUG));
            fake.setXRot(60.0F);
            check("Bettwanze geworfen", BwItems.onUse(fake, InteractionHand.MAIN_HAND));
            at = server.getTickCount() + 30;
            step = 5;
         }
         case 5 -> {
            check("Traumverteidiger ist da", count(level, arena.bounds(), BwEntities.Golem.class) == 1);
            check("Bettwanze ist da", count(level, arena.bounds(), BwEntities.Bedbug.class) == 1);
            check("Golem gehoert zum Team", Game.teamOf(level.getEntitiesOfClass(BwEntities.Golem.class, arena.bounds()).get(0)) == Game.teamOfPlayer(fake).team);
            hold(find(BwItems.MAGIC_MILK));
            check("Magische Milch getrunken", BwItems.onUse(fake, InteractionHand.MAIN_HAND) && find(BwItems.MAGIC_MILK).isEmpty());
            at = server.getTickCount() + 6;
            step++;
         }
         case 6 -> {
            hold(find(BwItems.TRACKER));
            check("Tracker benutzt", BwItems.onUse(fake, InteractionHand.MAIN_HAND));
            at = server.getTickCount() + 8;
            step = 60;
         }
         case 60 -> {
            // Rettungsplattform: in die Luft ueber die Leere stellen
            Vec3 air = is.atVec(0.0, 1.0, 14.0);
            fake.setPos(air.x, air.y, air.z);
            hold(find(BwItems.RESCUE));
            check("Rettungsplattform benutzt", BwItems.onUse(fake, InteractionHand.MAIN_HAND));
            check("Schleim unter dem Spieler", level.getBlockState(fake.blockPosition().below(2)).is(net.minecraft.world.level.block.Blocks.SLIME_BLOCK));
            at = server.getTickCount() + 20;
            step = 65;
         }
         case 65 -> {
            if (!Game.humans().get(0).active()) {
               at = server.getTickCount() + 20;
               return;
            }

            // Feuerball-Springen: normale Feuerkugel, auf den Boden unter sich
            Vec3 spot = is.atVec(2.0, 1.0, -2.0);
            fake.setPos(spot.x, spot.y, spot.z);
            fake.setDeltaMovement(Vec3.ZERO);
            fake.setXRot(90.0F);
            fake.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.FIRE_CHARGE, 2));
            check("Test-Spieler lebt fuer den Sprung", Game.humans().get(0).active());
            BlockPos floor = fake.blockPosition().below();
            // der Test-Spieler steht nicht wirklich in der Welt - ein Schwein an derselben Stelle misst den Schwung
            net.minecraft.world.entity.animal.pig.Pig pig = net.minecraft.world.entity.EntityTypes.PIG.create(level, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
            pig.setPos(spot.x + 0.4, spot.y, spot.z);
            level.addFreshEntity(pig);
            check("Feuerball auf den Boden benutzt", BwItems.onUseOnBlock(fake, InteractionHand.MAIN_HAND, floor, Direction.UP));
            check("Feuerball schleudert hoch (" + String.format("%.2f", pig.getDeltaMovement().y) + ")", pig.getDeltaMovement().y > 0.6);
            pig.discard();
            boolean fire = false;
            for (BlockPos q : BlockPos.betweenClosed(floor.offset(-3, 0, -3), floor.offset(3, 3, 3))) {
               if (level.getBlockState(q).is(net.minecraft.world.level.block.Blocks.FIRE)) {
                  fire = true;
               }
            }

            check("Keine Flamme am Boden", !fire);
            at = server.getTickCount() + 10;
            step = 7;
         }
         case 7 -> {
            // Mitspieler verlaesst die Runde: Bot uebernimmt, Sachen sofort zurueck
            Game.TeamState my = Game.teamOfPlayer(fake);
            int botsBefore = my.bots.size();
            Game.leave(fake);
            check("Verlassen: Bot uebernimmt den Platz", my.bots.size() == botsBefore + 1 && !Game.isHuman(fake));
            check("Verlassen: Runde laeuft weiter? (allein: nein)", !Game.running() || Game.humans().isEmpty());
            if (Game.running()) {
               Game.stop(true);
            }

            check("Runde beendet", !Game.running());
            check("Diamanten zurueck (7)", Shop.count(fake.getInventory(), Items.DIAMOND) == 7);
            check("Fackeln zurueck (33)", Shop.count(fake.getInventory(), Items.TORCH) == 33);
            check("Keine Bedwars-Sachen mehr im Inventar", Shop.count(fake.getInventory(), Items.IRON_INGOT) == 0 && find(BwItems.TNT).isEmpty());
            check("XP zurueck (Level 5)", fake.experienceLevel == 5);
            check("Karte abgebaut", level.getBlockState(arena.center).isAir() && level.getBlockState(is.at(0, 0, 0)).isAir());
            check("Kein Loot mehr in der Arena", level.getEntitiesOfClass(ItemEntity.class, arena.bounds()).isEmpty()
               && level.getEntitiesOfClass(BwEntities.Golem.class, arena.bounds()).isEmpty());
            System.out.println("[Selbsttest] FERTIG: " + passes + " OK, " + fails.size() + " Fehler " + fails);
            step = -1;
         }
         default -> step = -1;
      }
   }
}
