package org.bukkit.event.player;
public class PlayerCommandPreprocessEvent extends PlayerEvent implements org.bukkit.event.Cancellable { public boolean isCancelled(){return false;} public void setCancelled(boolean b){} }
